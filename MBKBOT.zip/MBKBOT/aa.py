# -*- coding: utf-8 -*-
#thanks to allfams

from LineAPI.linepy import *
from LineAPI.akad.ttypes import Message
from LineAPI.akad.ttypes import ContentType as Type
from LineAPI.akad.ttypes import ChatRoomAnnouncementContents
from LineAPI.akad.ttypes import ChatRoomAnnouncement
from thrift.unverting import *
from thrift.TMultiplexedProcessor import *
from thrift.TSerialization import *
from thrift.TRecursive import *
from thrift import transport, protocol, server
from multiprocessing import Pool, Process
from datetime import datetime, timedelta
from time import sleep
from bs4 import BeautifulSoup
from humanfriendly import format_timespan, format_size, format_number, format_length
import time, random, multiprocessing, sys, json, codecs, threading, glob, re, string, os, six, requests, subprocess, six, ast, pytz, urllib, urllib3, urllib.parse, html5lib, wikipedia, atexit, timeit, pafy, youtube_dl, traceback
from gtts import gTTS
from googletrans import Translator

cl = LINE('aspm669@gmail.com','achink1')
cl.log("Auth Token : " + str(cl.authToken))

ki = LINE('say.ces14@gmail.com','paramita1')
ki.log("Auth Token : " + str(ki.authToken))

kk = LINE('rumput.bergoyan9@gmail.com','paramita1')
kk.log("Auth Token : " + str(kk.authToken))

kc = LINE('sayces24@gmail.com','paramita1')
kc.log("Auth Token : " + str(kc.authToken))

km = LINE('Mbkchink2@gmail.com','Uchink24')
km.log("Auth Token : " + str(km.authToken))

kb = LINE('mbkbot1@gmail.com','mbkbots.90')
kb.log("Auth Token : " + str(kb.authToken))

sw = LINE('achinksebastian@gmail.com','Uchink24')
sw.log("Auth Token : " + str(sw.authToken))

oepoll = OEPoll(cl)
call = cl
creator = ["u6e4534dd63e82642f29205d2c993c642"]
owner = ["u6e4534dd63e82642f29205d2c993c642"]
admin = ["u6e4534dd63e82642f29205d2c993c642"]
staff = ["u6e4534dd63e82642f29205d2c993c642"]
lineProfile = cl.getProfile()
mid = cl.getProfile().mid
Amid = ki.getProfile().mid
Bmid = kk.getProfile().mid
Cmid = kc.getProfile().mid
Dmid = km.getProfile().mid
Emid = kb.getProfile().mid
Zmid = sw.getProfile().mid
KAC = [cl,ki,kk,kc,km,kb]
ABC = [ki,kk,kc,km,kb]
Bots = [mid,Amid,Bmid,Cmid,Dmid,Emid,Zmid]
Saints = admin + owner + staff
Team = creator + owner + admin + staff + Bots
Setbot = codecs.open("setting.json","r","utf-8")
Setmain = json.load(Setbot)

protectcancel = []
welcome = []
targets = []
protectname = []
prohibitedWords = ['Asu', 'Jancuk', 'Tai', 'Kickall', 'Ratakan', 'Cleanse']
userTemp = {}
userKicked = []
msg_dict = {}
msg_dict1 = {}
temp_flood = {}
groupName = {}
groupImage = {}
list = []
ban_list = []
warmode = []
ghost = []

responsename1 = ki.getProfile().displayName
responsename2 = kk.getProfile().displayName
responsename3 = kc.getProfile().displayName
responsename4 = km.getProfile().displayName
responsename5 = kb.getProfile().displayName
responsename6 = sw.getProfile().displayName


settings = {
    "autoBlock": True,
    "autoRead": False,
    "welcome": False,
    "leave": False,
    "mid": False,
    "replySticker": False,
    "stickerOn": False,
    "checkContact": False,
    "postEndUrl": True,
    "checkPost": False,
    "setKey": False,
    "restartPoint": False,
    "checkSticker": False,
    "userMentioned": False,
    "listSticker": False,
    "messageSticker": False,
    "changeGroupPicture": [],
    "keyCommand": "",
    "AddstickerTag": {
        "sid": "",
        "spkg": "",
        "status": False
            },
    "Addsticker":{
            "name": "",
            "status":False
            },
    "stk":{},
    "selfbot":True,
    "Images":{},
    "Img":{},
    "Addimage":{
            "name": "",
            "status":False
            },
    "Videos":{},
    "Addaudio":{
            "name": "",
            "status":False
            },
    "Addvideo":{
            "name": "",
            "status":False
            },
    "myProfile": {
        "displayName": "",
        "coverId": "",
        "pictureStatus": "",
        "statusMessage": ""
    },
    "Picture":False,
    "group":{},
    "groupPicture":False,
    "changePicture":False,
    "changeProfileVideo": False,
    "ChangeVideoProfilevid":{},
    "ChangeVideoProfilePicture":{},
    "autoJoinTicket":False,
    "userAgent": [
        "Mozilla/5.0 (X11; U; Linux i586; de; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (X11; U; Linux amd64; rv:5.0) Gecko/20100101 Firefox/5.0 (Debian)",
        "Mozilla/5.0 (X11; U; Linux amd64; en-US; rv:5.0) Gecko/20110619 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 FirePHP/0.5",
        "Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; Linux ppc; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux AMD64) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; FreeBSD amd64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20110619 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; rv:6.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1.1; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.1; U; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.1; rv:2.0.1) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.0; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.0; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.200.32.99 Safari/537.36"
    ]
}

wait = {
    "limit": 2,
    "owner":{},
    "admin":{},
    "addadmin":False,
    "delladmin":False,
    "staff":{},
    "Achink":{},
    "likeOn": True,
    "addstaff":False,
    "dellstaff":False,
    "bots":{},
    "addbots":False,
    "dellbots":False,
    "blacklist":{},
    "wblacklist":False,
    "dblacklist":False,
    "Talkblacklist":{},
    "Talkwblacklist":False,
    "Talkdblacklist":False,
    "talkban":True,
    "contact":False,
    'autoJoin':False,
    'autoAdd':True,
    'autoCancel':{"on":True, "members":1},
    'autoLeave':False,
    'autoLeave1':False,
    "detectMention":False,
    "Mentionkick":False,
    "welcomeOn":False,
    "sticker":False,
    "unsend":True,
    "selfbot":True,
    "mention":"",
    "Respontag":"Tag mulu kepleeet nich",
    "welcome":"Hai",
    "comment":" ╔═════════════════════╗\n ║M.B.K BOTS AUTO COMMAND\n ╚═════════════════════╝\n ╔════╦════════════════╗\n ║ADD    ASSALAMUALAIQUM\n ╠════╩════════════════╝\n ╠☆ тrιмĸaѕιн ѕυdaн add ѕaya\n ╠☆ ѕalaм ĸenal yaн\n ╠☆ мoga ĸιтa jadι тeмan yang вaιĸ\n ╠☆ тeмan тιdaĸ aĸan daтang ѕendιrι\n ╠☆ тanpa ĸιтa мeмυlaιnya,yυĸ cнaт\n ╠════╦════════════════╗\n ╠Contact  line.me/ti/p/~achink.93\n ╚════╩════════════════╝",
    "comment1":" ╔═════════════════════╗\n ║M.B.K BOTS AUTO COMMAND\n ╚═════════════════════╝\n ╔════╦════════════════╗\n ║ADD    ASSALAMUALAIQUM\n ╠════╩════════════════╝\n ╠☆ тrιмĸaѕιн ѕυdaн add ѕaya\n ╠☆ ѕalaм ĸenal yaн\n ╠☆ мoga ĸιтa jadι тeмan yang вaιĸ\n ╠☆ тeмan тιdaĸ aĸan daтang ѕendιrι\n ╠☆ тanpa ĸιтa мeмυlaιnya,yυĸ cнaт\n ╠════╦════════════════╗\n ╠Contact  line.me/ti/p/~achink.93\n ╚════╩════════════════╝",
    "message":" ╔═════════════════════╗\n ║M.B.K BOTS AUTO COMMAND\n ╚═════════════════════╝\n ╔════╦════════════════╗\n ║ADD    ASSALAMUALAIQUM\n ╠════╩════════════════╝\n ╠☆ тrιмĸaѕιн ѕυdaн add ѕaya\n ╠☆ ѕalaм ĸenal yaн\n ╠☆ мoga ĸιтa jadι тeмan yang вaιĸ\n ╠☆ тeмan тιdaĸ aĸan daтang ѕendιrι\n ╠☆ тanpa ĸιтa мeмυlaιnya,yυĸ cнaт\n ╠════╦════════════════╗\n ╠Contact  line.me/ti/p/~achink.93\n ╚════╩════════════════╝"
}

protect = {
    "pqr":[],
    "pinv":[],
    "proall":[],
    "antijs":[],
    "protect":[]
}

read = {
    "readPoint":{},
    "readMember":{},
    "readTime":{},
    "ROM":{},
}

cctv = {
    "cyduk":{},
    "point":{},
    "sidermem":{}
}
imagesOpen = codecs.open("image.json","r","utf-8")
videosOpen = codecs.open("video.json","r","utf-8")
stickersOpen = codecs.open("sticker.json","r","utf-8")
audiosOpen = codecs.open("audio.json","r","utf-8")
images = json.load(imagesOpen)
videos = json.load(videosOpen)
stickers = json.load(stickersOpen)
audios = json.load(audiosOpen)

mulai = time.time()

tz = pytz.timezone("Asia/Jakarta")
timeNow = datetime.now(tz=tz)

def restart_program():
    python = sys.executable
    os.execl(python, python, * sys.argv)

def logError(text):
    cl.log("[ ERROR ] {}".format(str(text)))
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    timeHours = datetime.strftime(timeNow,"(%H:%M)")
    day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
    hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
    bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
    inihari = datetime.now(tz=tz)
    hr = inihari.strftime('%A')
    bln = inihari.strftime('%m')
    for i in range(len(day)):
        if hr == day[i]: hasil = hari[i]
    for k in range(0, len(bulan)):
        if bln == str(k): bln = bulan[k-1]
    time = "{}, {} - {} - {} | {}".format(str(hasil), str(inihari.strftime('%d')), str(bln), str(inihari.strftime('%Y')), str(inihari.strftime('%H:%M:%S')))
    with open("logError.txt","a") as error:
        error.write("\n[ {} ] {}".format(str(time), text))

def delete_log():
    ndt = datetime.now()
    for data in msg_dict:
        if (datetime.utcnow() - cTime_to_datetime(msg_dict[data]["createdTime"])) > timedelta(1):
            if "path" in msg_dict[data]:
                cl.deleteFile(msg_dict[data]["path"])
            del msg_dict[data]

def download_page(url):
    version = (3,0)
    cur_version = sys.version_info
    if cur_version >= version:     
        import urllib,request
        try:
            headers = {}
            headers['User-Agent'] = "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
            req = urllib,request.Request(url, headers = headers)
            resp = urllib,request.urlopen(req)
            respData = str(resp.read())
            return respData
        except Exception as e:
            print(str(e))
    else:                        
        import urllib2
        try:
            headers = {}
            headers['User-Agent'] = "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.17 (KHTML, like Gecko) Chrome/24.0.1312.27 Safari/537.17"
            req = urllib2.Request(url, headers = headers)
            response = urllib2.urlopen(req)
            page = response.read()
            return page
        except:
            return"Page Not found"

def _images_get_all_items(page):
    items = []
    while True:
        item, end_content = _images_get_next_item(page)
        if item == "no_links":
            break
        else:
            items.append(item)      
            time.sleep(0.1)        
            page = page[end_content:]
    return items
    
def restartBot():
    python = sys.executable
    os.execl(python, python, *sys.argv)

def waktu(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Hari %02d Jam %02d Menit %02d Detik' % (days, hours, mins, secs)

def runtime(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Hari %02d Jam %02d Menit %02d Detik' % (days, hours, mins, secs)
    
def sendImage(to, path, name="image"):
    try:
        if settings["server"] == "VPS":
            cl.sendImageWithURL(to, str(path))
    except Exception as error:
        logError(error)

def delExpire():
    if temp_flood != {}:
        for tmp in temp_flood:
            if temp_flood[tmp]["expire"] == True:
                if time.time() - temp_flood[tmp]["time"] >= 3*10:
                    temp_flood[tmp]["expire"] = False
                    temp_flood[tmp]["time"] = time.time()
                    try:
                        cl.sendMessage(tmp, "Bot kembali aktif")
                    except Exception as error:
                        logError(error)
                        
def changeVideoAndPictureProfile(pict, vids):
    try:
        files = {'file': open(vids, 'rb')}
        obs_params = cl.genOBSParams({'oid': mid, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
        data = {'params': obs_params}
        r_vp = cl.server.postContent('{}/talk/vp/upload.nhn'.format(str(cl.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return "Failed update profile"
        cl.updateProfilePicture(pict, 'vp')
        return "Success update profile"
    except Exception as e:
        raise Exception("Error change video and picture profile {}".format(str(e)))

def changeProfileVideo(to):
    if settings['changeProfileVideo']['picture'] == None:
        return cl.sendMessage(to, "Foto tidak ditemukan")
    elif settings['changeProfileVideo']['video'] == None:
        return cl.sendMessage(to, "Video tidak ditemukan")
    else:
        path = settings['changeProfileVideo']['video']
        files = {'file': open(path, 'rb')}
        obs_params = cl.genOBSParams({'oid': cl.getProfile().mid, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
        data = {'params': obs_params}
        r_vp = cl.server.postContent('{}/talk/vp/upload.nhn'.format(str(cl.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return cl.sendMessage(to, "Gagal update profile")
        path_p = settings['changeProfileVideo']['picture']
        settings['changeProfileVideo']['status'] = False
        cl.updateProfilePicture(path_p, 'vp')

def cloneProfile(mid):
    contact = cl.getContact(mid)
    if contact.videoProfile == None:
        cl.cloneContactProfile(mid)
    else:
        profile = cl.getProfile()
        profile.displayName, profile.statusMessage = contact.displayName, contact.statusMessage
        cl.updateProfile(profile)
        pict = cl.downloadFileURL('http://dl.profile.line-cdn.net/' + contact.pictureStatus, saveAs="tmp/pict.bin")
        vids = cl.downloadFileURL( 'http://dl.profile.line-cdn.net/' + contact.pictureStatus + '/vp', saveAs="tmp/video.bin")
        changeVideoAndPictureProfile(pict, vids)
    coverId = cl.getProfileDetail(mid)['result']['objectId']
    cl.updateProfileCoverById(coverId)

def restoreProfile():
    profile = cl.getProfile()
    profile.displayName = settings['myProfile']['displayName']
    profile.statusMessage = settings['myProfile']['statusMessage']
    if settings['myProfile']['videoProfile'] == None:
        profile.pictureStatus = settings['myProfile']['pictureStatus']
        cl.updateProfileAttribute(8, profile.pictureStatus)
        cl.updateProfile(profile)
    else:
        cl.updateProfile(profile)
        pict = cl.downloadFileURL('http://dl.profile.line-cdn.net/' + settings['myProfile']['pictureStatus'], saveAs="tmp/pict.bin")
        vids = cl.downloadFileURL( 'http://dl.profile.line-cdn.net/' + settings['myProfile']['pictureStatus'] + '/vp', saveAs="tmp/video.bin")
        changeVideoAndPictureProfile(pict, vids)
    coverId = settings['myProfile']['coverId']
    cl.updateProfileCoverById(coverId)
    
def speedtest(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours,24)
    weaks, days = divmod(days,7)
    if days == 0:
        return '%02d' % (secs)
    elif days > 0 and weaks == 0:
        return '%02d' %(secs)
    elif days > 0 and weaks > 0:
        return '%02d' %(secs)

def backupProfile():
    profile = cl.getContact(mid)
    settings['myProfile']['displayName'] = profile.displayName
    settings['myProfile']['pictureStatus'] = profile.pictureStatus
    settings['myProfile']['statusMessage'] = profile.statusMessage
    settings['myProfile']['videoProfile'] = profile.videoProfile
    coverId = cl.getProfileDetail()['result']['objectId']
    settings['myProfile']['coverId'] = str(coverId)
def mentionMembers(to, mid):
    try:
        arrData = ""
        textx = "Mention User「{}」\n\n  [ Mention ]\n1. ".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention
            if no < len(mid):
                no += 1
                textx += "%i. " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n╚══[ {} ]".format(str(cl.getGroup(to).name))
                except:
                    no = "\n╚══[ Success ]"
        cl.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def siderMembers(to, mid):
    try:
        arrData = ""
        textx = "".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention+wait["mention"]
            if no < len(mid):
                no += 1
                textx += "%i. " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n╚══[ {} ]".format(str(cl.getGroup(to).name))
                except:
                    no = "\n╚══[ Success ]"
        cl.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def welcomeMembers(to, mid):
    try:
        arrData = ""
        textx = "Haii  ".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            ginfo = cl.getGroup(to)
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention+wait["welcome"]+"\nNama grup : "+str(ginfo.name)
            if no < len(mid):
                no += 1
                textx += "%i " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n╚══[ {} ]".format(str(cl.getGroup(to).name))
                except:
                    no = "\n╚══[ Success ]"
        cl.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def sendMention(to, mid, firstmessage):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@x \n"
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        today = datetime.today()
        future = datetime(2030,11,11)
        hari = (str(future - today))
        comma = hari.find(",")
        hari = hari[:comma]
        teman = cl.getAllContactIds()
        gid = cl.getGroupIdsJoined()
        tz = pytz.timezone("Asia/Jakarta")
        timeNow = datetime.now(tz=tz)
        eltime = time.time() - mulai
        bot = runtime(eltime)
        text += mention+"\n⚜ ᴊᴀᴍ : "+datetime.strftime(timeNow,'%H:%M:%S')+" ᴡɪʙ\n⚜ ɢʀᴜᴘ : "+str(len(gid))+"\n⚜ ᴛᴇᴍᴀɴ : "+str(len(teman))+"\n⚜ ᴇxᴘᴀʏᴇʀ "+hari+"\n⚜ ᴠᴇʀsɪᴏɴ sᴇʟғ : ᴍ.ʙ.ᴋ ʙᴏᴛs ᴠ3⃣\n⚜ ᴛᴀɴɢɢᴀʟ ʟᴏɢɪɴ : "+datetime.strftime(timeNow,'%Y-%m-%d')+"\n⚜ ᴀᴋᴛɪғ : "+bot
        cl.sendMessage(to, text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def sendMention1(to, mid, firstmessage, lastmessage):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@x "
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        text += mention + str(lastmessage)
        cl.sendMessage(to, text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def command(text):
    pesan = text.lower()
    if pesan.startswith(Setmain['keyCommand']):
        cmd = pesan.replace(Setmain['keyCommand'],"")
    else:
        cmd = "command"
    return cmd

def help():
    key = Setmain["keyCommand"]
    key = key.title()
    helpMessage = "--------------------------------\n𝐌.𝐁.𝐊 𝐒𝐄𝐋𝐅 𝐂𝐎𝐌𝐌𝐀𝐍𝐃 \n--------------------------------\n" + \
                  "⚜" + key + ".me\n" + \
                  "⚜" + key + ".tag\n" + \
                  "⚜" + key + ".status\n" + \
                  "⚜" + key + ".meme\n" + \
                  "⚜" + key + ".about\n" + \
                  "⚜" + key + ".cek\n" + \
                  "⚜" + key + ".self on/off\n" + \
                  "⚜" + key + ".runtime\n" + \
                  "⚜" + key + ".creator\n" + \
                  "⚜" + key + ".sp\n" + \
                  "⚜" + key + ".sptime\n" + \
                  "⚜" + key + ".mid @\n" + \
                  "⚜" + key + ".pamit\n" + \
                  "⚜" + key + ".info @\n" + \
                  "⚜" + key + ".apk\n" + \
                  "⚜" + key + ".reject\n" + \
                  "⚜" + key + ".santai\n" + \
                  "⚜" + key + ".gift: Mid Result\n" + \
                  "⚜" + key + ".spam: Mid Result\n" + \
                  "⚜" + key  + ".searchyoutube|\n" + \
                  "⚜" + key + ".ytmp3: Judul Lagu\n" + \
                  "⚜" + key + ".ytmp4: Judul Video\n" + \
                  "⚜" + key + ".jumlah: angka\n" + \
                  "⚜" + key + ".spamtag @\n" + \
                  "⚜" + key + ".scall: jumlahnya\n" + \
                  "⚜" + key + ".scall\n" + \
                  "⚜" + key + ".sticker on/off\n" + \
                  "⚜" + key + ".unsend on/off\n" + \
                  "⚜" + key + ".respon on/off\n" + \
                  "⚜" + key + ".c on/off\n" + \
                  "⚜" + key + ".autojoin on/off\n" + \
                  "⚜" + key + ".autoadd on/off\n" + \
                  "⚜" + key + ".wc on/off\n" + \
                  "⚜" + key + ".autoleave on/off\n" + \
                  "⚜" + key + ".temanlist\n" + \
                  "⚜" + key + ".respon\n" + \
                  "⚜" + key + ".hapus chat\n" + \
                  "--------------------------------\n𝐌.𝐁.𝐊 𝐁𝐀𝐍𝐓𝐔𝐀𝐍\n--------------------------------\n" + \
                  "⚜" + key + ".jepit\n" + \
                  "⚜" + key + ".jepit marsya\n" + \
                  "⚜" + key + ".jepit dila\n" + \
                  "⚜" + key + ".jepit joker\n" + \
                  "⚜" + key + ".jepit laki\n" + \
                  "⚜" + key + ".jepit bini\n" + \
                  "⚜" + key + ".jepit mamah\n" + \
                  "--------------------------------\n𝐌.𝐁.𝐊 𝐒𝐄𝐓 𝐆𝐑𝐔𝐏\n--------------------------------\n" + \
                  "⚜" + key + ".broadcast:Text\n" + \
                  "⚜" + key + ".open\n" + \
                  "⚜" + key + ".close\n" + \
                  "⚜" + key + ".url grup\n" + \
                  "⚜" + key + ".gruplist\n" + \
                  "⚜" + key + ".infogrup angka\n" + \
                  "⚜" + key + ".infomem angka\n" + \
                  "⚜" + key + ".remove chat\n" + \
                  "⚜" + key + ".lurking on/off\n" + \
                  "⚜" + key + ".lurkers\n" + \
                  "⚜" + key + ".s on/off\n" + \
                  "⚜" + key + ".updatefoto\n" + \
                  "⚜" + key + ".updategrup\n" + \
                  "--------------------------------\n𝐌.𝐁.𝐊 𝐒𝐄𝐓 𝐁𝐎𝐓\n--------------------------------\n" + \
                  "⚜" + key + ".mbk\n" + \
                  "⚜" + key + ".come\n" + \
                  "⚜" + key + ".pulang\n" + \
                  "⚜" + key + ".cink\n" + \
                  "⚜" + key + ".skick\n" + \
                  "⚜" + key + ",cink\n" + \
                  "⚜" + key + ".myname: Nama\n" + \
                  "⚜" + key + ".cink1nm Nama\n" + \
                  "⚜" + key + ".cink2nm Nama\n" + \
                  "⚜" + key + ".cink3nm Nama\n" + \
                  "⚜" + key + ".cink4nm Nama\n" + \
                  "⚜" + key + ".cink5nm Nama\n" + \
                  "⚜" + key + ".cinknm Nama\n" + \
                  "⚜" + key + ".b1up\n" + \
                  "⚜" + key + ".b2up\n" + \
                  "⚜" + key + ".b3up\n" + \
                  "⚜" + key + ".b4up\n" + \
                  "⚜" + key + ".b5up\n" + \
                  "⚜" + key + ".cinkup\n" + \
                  "⚜" + key + ".adminadd @\n" + \
                  "⚜" + key + ".admindell @\n" + \
                  "⚜" + key + ".staffadd @\n" + \
                  "⚜" + key + ".staffdell @\n" + \
                  "⚜" + key + ".botadd @\n" + \
                  "⚜" + key + ".botdell @\n" + \
                  "⚜" + key + ".admin:on\n" + \
                  "⚜" + key + ".admin:repeat\n" + \
                  "⚜" + key + ".staff:on\n" + \
                  "⚜" + key + ".staff:repeat\n" + \
                  "⚜" + key + ".bot:on\n" + \
                  "⚜" + key + ".bot:repeat\n" + \
                  "--------------------------------\n𝐌.𝐁.𝐊 𝐂𝐎𝐌𝐌𝐀𝐍𝐃 𝐊𝐈𝐂𝐊\n--------------------------------\n" + \
                  "⚜" + key + ".culik @\n" + \
                  "⚜" + key + ".cipok @\n" + \
                  "⚜" + key + ".sapu\n" + \
                  "⚜" + key + ".tiup\n" + \
                  "--------------------------------\n𝐌.𝐁.𝐊 𝐒𝐄𝐓 𝐁𝐀𝐍𝐋𝐈𝐒𝐓\n--------------------------------\n" + \
                  "⚜" + key + ".banlist \n" + \
                  "⚜" + key + ".cban \n" + \
                  "⚜" + key + ".blc\n" + \
                  "⚜" + key + ".ban:on\n" + \
                  "⚜" + key + ".unban:on\n" + \
                  "⚜" + key + ".ban @\n" + \
                  "⚜" + key + ".unban @\n" + \
                  "⚜" + key + ".talkban @\n" + \
                  "⚜" + key + ".untalkban @\n" + \
                  "⚜" + key + ".talkban:on\n" + \
                  "⚜" + key + ".untalkban:on\n" + \
                  "⚜" + key + ".talkban on/off\n" + \
                  "⚜" + key + ".talkbanlist\n" + \
                  "--------------------------------\n𝐌.𝐁.𝐊 𝐒𝐄𝐓 𝐌𝐒𝐆\n--------------------------------\n" + \
                  "⚜" + key + ".setkey:\n" + \
                  "⚜" + key + ".mykey\n" + \
                  "⚜" + key + ".resetkey\n" + \
                  "⚜" + key + ".cek sider\n" + \
                  "⚜" + key + ".cek spam\n" + \
                  "⚜" + key + ".cek pesan\n" + \
                  "⚜" + key + ".cek respon\n" + \
                  "⚜" + key + ".cek welcome\n" + \
                  "⚜" + key + ".set sider: Text\n" + \
                  "⚜" + key + ".set spam: Text\n" + \
                  "⚜" + key + ".set pesan: Text\n" + \
                  "⚜" + key + ".set respon: Text\n" + \
                  "⚜" + key + ".set welcome: Text\n" + \
                  "--------------------------------\n𝐌.𝐁.𝐊 𝐒𝐄𝐓 𝐏𝐑𝐎\n--------------------------------\n" + \
                  "⚜" + key + ".cink on/off\n" + \
                  "⚜" + key + ".cink come\n" + \
                  "⚜" + key + ".jurig on/off\n" + \
                  "⚜" + key + ".notag on/off\n" + \
                  "⚜" + key + ".allpro on/off\n" + \
                  "⚜" + key + ".prourl on/off\n" + \
                  "⚜" + key + ".projoin on/off\n" + \
                  "⚜" + key + ".prokick on/off\n" + \
                  "⚜" + key + ".procancel on/off\n" + \
                  "⚜" + key + ".listpro\n" + \
                  "--------------------------------\n𝐁𝐘 𝐌.𝐁.𝐊 𝐁𝐎𝐓𝐒\n--------------------------------" 
    return helpMessage



def bot(op):
    global time
    global ast
    global groupParam
    try:
        if op.type == 0:
            return
        
        if op.type == 11:
            if op.param1 in protect["pqr"]:
                try:
                    if cl.getGroup(op.param1).preventedJoinByTicket == False:
                        if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                            cl.reissueGroupTicket(op.param1)
                            X = cl.getGroup(op.param1)
                            X.preventedJoinByTicket = True
                            Ticket = cl.reissueGroupTicket(op.param1)
                            sw.acceptGroupInvitationByTicket(op.param1,Ticket)
                            sw.kickoutFromGroup(op.param1,[op.param2])
                            sw.leaveGroup(op.param1)
                            cl.updateGroup(X)
                except:
                    try:
                        if ki.getGroup(op.param1).preventedJoinByTicket == False:
                            if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                                ki.reissueGroupTicket(op.param1)
                                X = ki.getGroup(op.param1)
                                X.preventedJoinByTicket = True
                                Ticket = ki.reissueGroupTicket(op.param1)
                                sw.acceptGroupInvitationByTicket(op.param1,Ticket)
                                sw.kickoutFromGroup(op.param1,[op.param2])
                                sw.leaveGroup(op.param1)
                                ki.updateGroup(X)
                    except:
                        try:
                            if kk.getGroup(op.param1).preventedJoinByTicket == False:
                                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                                    kk.reissueGroupTicket(op.param1)
                                    X = kk.getGroup(op.param1)
                                    X.preventedJoinByTicket = True
                                    Ticket = kk.reissueGroupTicket(op.param1)
                                    sw.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    sw.kickoutFromGroup(op.param1,[op.param2])
                                    kk.updateGroup(X)
                        except:
                            try:
                                if kc.getGroup(op.param1).preventedJoinByTicket == False:
                                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                                        kc.reissueGroupTicket(op.param1)
                                        X = kc.getGroup(op.param1)
                                        X.preventedJoinByTicket = True
                                        Ticket = kc.reissueGroupTicket(op.param1)
                                        sw.acceptGroupInvitationByTicket(op.param1,Ticket)
                                        sw.kickoutFromGroup(op.param1,[op.param2])
                                        kc.updateGroup(X)
                            except:
                                try:
                                    if km.getGroup(op.param1).preventedJoinByTicket == False:
                                        if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                                            km.reissueGroupTicket(op.param1)
                                            X = km.getGroup(op.param1)
                                            X.preventedJoinByTicket = True
                                            Ticket = km.reissueGroupTicket(op.param1)
                                            sw.acceptGroupInvitationByTicket(op.param1,Ticket)
                                            sw.kickoutFromGroup(op.param1,[op.param2])
                                            km.updateGroup(X)
                                except:
                                    try:
                                        if kb.getGroup(op.param1).preventedJoinByTicket == False:
                                            if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                                                kb.reissueGroupTicket(op.param1)
                                                X = kb.getGroup(op.param1)
                                                X.preventedJoinByTicket = True
                                                Ticket = kb.reissueGroupTicket(op.param1)
                                                sw.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                sw.kickoutFromGroup(op.param1,[op.param2])
                                                kb.updateGroup(X)
                                    except:
                                        pass
                      
        if op.type == 11:
            if op.param1 in warmode:
                try:
                    if cl.getGroup(op.param1).preventedJoinByTicket == False:
                        if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                            wait["blacklist"][op.param2] = True
                            try:ki.kickoutFromGroup(op.param1,[op.param2])
                            except:
                            	try:kk.kickoutFromGroup(op.param1,[op.param2])
                            	except:
                            	    try:kc.kickoutFromGroup(op.param1,[op.param2])
                            	    except:
                            	        try:sw.kickoutFromGroup(op.param1,[op.param2])
                            	        except:pass
                            warmode.remove(op.param1)
                except:pass


        if op.type == 17:
            if op.param2 in wait["blacklist"]:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                   try:ki.kickoutFromGroup(op.param1,[op.param2])
                   except:
                   	try:kk.kickoutFromGroup(op.param1,[op.param2])
                   	except:
                   	    try:kc.kickoutFromGroup(op.param1,[op.param2])
                   	    except:
                   	        try:cl.reissueGroupTicket(op.param1);X = cl.getGroup(op.param1);X.preventedJoinByTicket = True;Ticket = cl.reissueGroupTicket(op.param1);sw.acceptGroupInvitationByTicket(op.param1,Ticket);sw.kickoutFromGroup(op.param1,[op.param2])
                   	        except:pass
                   cl.reissueGroupTicket(op.param1)
                   X = cl.getGroup(op.param1)
                   X.preventedJoinByTicket = True
                   cl.updateGroup(X)
                   warmode.append(op.param1)
                else:
                   pass
#========================== PROTECTUPDATEGROUP                          
        if op.type == 13:
            if mid in op.param3:
                if wait["autoLeave"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        cl.acceptGroupInvitation(op.param1)
                        ginfo = cl.getGroup(op.param1)
                    #    cl.sendMessage(op.param1,"Sorry anda bukan admin kami\nSelamat tinggal " +str(ginfo.name))
                        cl.leaveGroup(op.param1)
                    else:
                        cl.acceptGroupInvitation(op.param1)
                        ginfo = cl.getGroup(op.param1)
                    #    cl.sendMessage(op.param1,"Im'coming " + str(ginfo.name))

        if op.type == 13:
            if mid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        cl.acceptGroupInvitation(op.param1)
                        ginfo = cl.getGroup(op.param1)
                   #     cl.sendMessage(op.param1,"I'm coming " +str(ginfo.name))
                    else:
                        cl.acceptGroupInvitation(op.param1)
                        ginfo = cl.getGroup(op.param1)
                    #    cl.sendMessage(op.param1,"I'm coming " + str(ginfo.name))
            if Amid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        ki.acceptGroupInvitation(op.param1)
                        ginfo = ki.getGroup(op.param1)
                  #      ki.sendMessage(op.param1,"Selamat Tinggal\n Group " +str(ginfo.name))
                        ki.leaveGroup(op.param1)
                    else:
                        ki.acceptGroupInvitation(op.param1)
                        ginfo = ki.getGroup(op.param1)
                    #    ki.sendMessage(op.param1,"i'm coming " + str(ginfo.name))
            if Bmid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        kk.acceptGroupInvitation(op.param1)
                        ginfo = kk.getGroup(op.param1)
                  #      kk.sendMessage(op.param1,"Selamat Tinggal\n Group " +str(ginfo.name))
                        kk.leaveGroup(op.param1)
                    else:
                        kk.acceptGroupInvitation(op.param1)
                        ginfo = kk.getGroup(op.param1)
                    #    kk.sendMessage(op.param1,"I'm coming " + str(ginfo.name))
            if Cmid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        kc.acceptGroupInvitation(op.param1)
                        ginfo = kc.getGroup(op.param1)
                     #   kc.sendMessage(op.param1,"Selamat Tinggal\n Group " +str(ginfo.name))
                        kc.leaveGroup(op.param1)
                    else:
                        kc.acceptGroupInvitation(op.param1)
                        ginfo = kc.getGroup(op.param1)
                    #    kc.sendMessage(op.param1,"I'm coming " + str(ginfo.name))
            if Dmid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        km.acceptGroupInvitation(op.param1)
                        ginfo = km.getGroup(op.param1)
                    #    km.sendMessage(op.param1,"Selamat Tinggal\n Group " +str(ginfo.name))
                        km.leaveGroup(op.param1)
                    else:
                        km.acceptGroupInvitation(op.param1)
                        ginfo = km.getGroup(op.param1)
                  #      km.sendMessage(op.param1,"I'm coming " + str(ginfo.name))
            if Emid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        kb.acceptGroupInvitation(op.param1)
                        ginfo = kb.getGroup(op.param1)
                    #    kb.sendMessage(op.param1,"Selamat Tinggal\n Group " +str(ginfo.name))
                        kb.leaveGroup(op.param1)
                    else:
                        kb.acceptGroupInvitation(op.param1)
                        ginfo = kb.getGroup(op.param1)
                       # kb.sendMessage(op.param1,"I'm coming " + str(ginfo.name))
                        
        if op.type == 5:
            if settings["autoBlock"] == True:
                cl.blockContact(op.param1)
                cl.sendMessage(to, "SORRY AUTOBLOCK BROO...!")
#____________________________________________________________________
        if op.type == 13:
            if op.param1 in protect['pinv']:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    try:
                        group = cl.getGroup(op.param1)
                        gMembMids = [contact.mid for contact in group.invitee]
                        for _mid in gMembMids:
                            random.choice(ABC).cancelGroupInvitation(op.param1,[_mid])
                    except:
                        try:
                            group = ki.getGroup(op.param1)
                            gMembMids = [contact.mid for contact in group.invitee]
                            for _mid in gMembMids:
                                random.choice(ABC).cancelGroupInvitation(op.param1,[_mid])
                        except:
                            try:
                                group = kk.getGroup(op.param1)
                                gMembMids = [contact.mid for contact in group.invitee]
                                for _mid in gMembMids:
                                    random.choice(ABC).cancelGroupInvitation(op.param1,[_mid])
                            except:
                                try:
                                    group = kc.getGroup(op.param1)
                                    gMembMids = [contact.mid for contact in group.invitee]
                                    for _mid in gMembMids:
                                        random.choice(ABC).cancelGroupInvitation(op.param1,[_mid])
                                except:
                                    pass
                        
        if op.type == 19:
            if mid in op.param3:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    try:
                        ki.kickoutFromGroup(op.param1,[op.param2])
                        ki.findAndAddContactsByMid(op.param3)
                        ki.inviteIntoGroup(op.param1,[op.param3])
                        cl.acceptGroupInvitation(op.param1)
                        kc.cancelGroupInvitation(op.param1,[op.param3])
                        wait["blacklist"][op.param2] = True
                    except:
                        try:
                            kk.kickoutFromGroup(op.param1,[op.param2])
                            kk.findAndAddContactsByMid(op.param3)
                            kk.inviteIntoGroup(op.param1,[op.param3])
                            cl.acceptGroupInvitation(op.param1)
                            ki.cancelGroupInvitation(op.param1,[op.param3])
                            wait["blacklist"][op.param2] = True
                        except:
                            try:
                                kc.kickoutFromGroup(op.param1,[op.param2])
                                kc.findAndAddContactsByMid(op.param3)
                                kc.inviteIntoGroup(op.param1,[op.param3])
                                cl.acceptGroupInvitation(op.param1)
                                kb.cancelGroupInvitation(op.param1,[op.param3])
                                wait["blacklist"][op.param2] = True
                            except:
                                try:
                                    km.kickoutFromGroup(op.param1,[op.param2])
                                    km.findAndAddContactsByMid(op.param3)
                                    km.inviteIntoGroup(op.param1,[op.param3])
                                    cl.acceptGroupInvitation(op.param1)
                                    kk.cancelGroupInvitation(op.param1,[op.param3])
                                    wait["blacklist"][op.param2] = True
                                except:
                                    try:
                                        kb.kickoutFromGroup(op.param1,[op.param2])
                                        kb.findAndAddContactsByMid(op.param3)
                                        kb.inviteIntoGroup(op.param1,[op.param3])
                                        cl.acceptGroupInvitation(op.param1)
                                        kc.cancelGroupInvitation(op.param1,[op.param3])
                                        wait["blacklist"][op.param2] = True
                                    except:
                                        try:
                                            ki.kickoutFromGroup(op.param1,[op.param2])
                                            ki.findAndAddContactsByMid(op.param3)
                                            ki.inviteIntoGroup(op.param1,[op.param3])
                                            cl.acceptGroupInvitation(op.param1)
                                            km.cancelGroupInvitation(op.param1,[op.param3])
                                            wait["blacklist"][op.param2] = True
                                        except:
                                            pass
                return

            if Amid in op.param3:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    try:
                        kk.kickoutFromGroup(op.param1,[op.param2])
                        kk.findAndAddContactsByMid(op.param3)
                        kk.inviteIntoGroup(op.param1,[op.param3])
                        ki.acceptGroupInvitation(op.param1)
                        km.cancelGroupInvitation(op.param1,[op.param3])
                        wait["blacklist"][op.param2] = True
                    except:
                        try:
                            kc.kickoutFromGroup(op.param1,[op.param2])
                            kc.findAndAddContactsByMid(op.param3)
                            kc.inviteIntoGroup(op.param1,[op.param3])
                            ki.acceptGroupInvitation(op.param1)
                            kk.cancelGroupInvitation(op.param1,[op.param3])
                            wait["blacklist"][op.param2] = True
                        except:
                            try:
                                km.kickoutFromGroup(op.param1,[op.param2])
                                km.findAndAddContactsByMid(op.param3)
                                km.inviteIntoGroup(op.param1,[op.param3])
                                ki.acceptGroupInvitation(op.param1)
                                kc.cancelGroupInvitation(op.param1,[op.param3])
                                wait["blacklist"][op.param2] = True
                            except:
                                try:
                                    kb.kickoutFromGroup(op.param1,[op.param2])
                                    kb.findAndAddContactsByMid(op.param3)
                                    kb.inviteIntoGroup(op.param1,[op.param3])
                                    ki.acceptGroupInvitation(op.param1)
                                    kk.cancelGroupInvitation(op.param1,[op.param3])
                                    wait["blacklist"][op.param2] = True
                                except:
                                    try:
                                        ki.kickoutFromGroup(op.param1,[op.param2])
                                        kk.findAndAddContactsByMid(op.param3)
                                        kk.inviteIntoGroup(op.param1,[op.param3])
                                        ki.acceptGroupInvitation(op.param1)
                                        km.cancelGroupInvitation(op.param1,[op.param3])
                                        wait["blacklist"][op.param2] = True
                                    except:
                                        try:
                                            kk.kickoutFromGroup(op.param1,[op.param2])
                                            kk.findAndAddContactsByMid(op.param3)
                                            kk.inviteIntoGroup(op.param1,[op.param3])
                                            ki.acceptGroupInvitation(op.param1)
                                            ki.cancelGroupInvitation(op.param1,[op.param3])
                                            wait["blacklist"][op.param2] = True
                                        except:
                                            pass
                return

            if Bmid in op.param3:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    try:
                        kc.kickoutFromGroup(op.param1,[op.param2])
                        kc.findAndAddContactsByMid(op.param3)
                        kc.inviteIntoGroup(op.param1,[op.param3])
                        kk.acceptGroupInvitation(op.param1)
                        kb.cancelGroupInvitation(op.param1,[op.param3])
                        wait["blacklist"][op.param2] = True
                    except:
                        try:
                            km.kickoutFromGroup(op.param1,[op.param2])
                            km.findAndAddContactsByMid(op.param3)
                            km.inviteIntoGroup(op.param1,[op.param3])
                            kk.acceptGroupInvitation(op.param1)
                            kc.cancelGroupInvitation(op.param1,[op.param3])
                            wait["blacklist"][op.param2] = True
                        except:
                            try:
                                kb.kickoutFromGroup(op.param1,[op.param2])
                                kb.findAndAddContactsByMid(op.param3)
                                kb.inviteIntoGroup(op.param1,[op.param3])
                                kk.acceptGroupInvitation(op.param1)
                                ki.cancelGroupInvitation(op.param1,[op.param3])
                                wait["blacklist"][op.param2] = True
                            except:
                                try:
                                    ki.kickoutFromGroup(op.param1,[op.param2])
                                    km.findAndAddContactsByMid(op.param3)
                                    km.inviteIntoGroup(op.param1,[op.param3])
                                    kk.acceptGroupInvitation(op.param1)
                                    kc.cancelGroupInvitation(op.param1,[op.param3])
                                    wait["blacklist"][op.param2] = True
                                except:
                                    try:
                                        ki.kickoutFromGroup(op.param1,[op.param2])
                                        ki.findAndAddContactsByMid(op.param3)
                                        ki.inviteIntoGroup(op.param1,[op.param3])
                                        kk.acceptGroupInvitation(op.param1)
                                        km.cancelGroupInvitation(op.param1,[op.param3])
                                        wait["blacklist"][op.param2] = True
                                    except:
                                        try:
                                            kc.kickoutFromGroup(op.param1,[op.param2])
                                            kc.findAndAddContactsByMid(op.param3)
                                            kc.inviteIntoGroup(op.param1,[op.param3])
                                            kk.acceptGroupInvitation(op.param1)
                                            kb.cancelGroupInvitation(op.param1,[op.param3])
                                            wait["blacklist"][op.param2] = True
                                        except:
                                            pass
                return

            if Cmid in op.param3:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    try:
                        km.kickoutFromGroup(op.param1,[op.param2])
                        km.findAndAddContactsByMid(op.param3)
                        km.inviteIntoGroup(op.param1,[op.param3])
                        kc.acceptGroupInvitation(op.param1)
                        kk.cancelGroupInvitation(op.param1,[op.param3])
                        wait["blacklist"][op.param2] = True
                    except:
                        try:
                            kb.kickoutFromGroup(op.param1,[op.param2])
                            kk.findAndAddContactsByMid(op.param3)
                            kk.inviteIntoGroup(op.param1,[op.param3])
                            kc.acceptGroupInvitation(op.param1)
                            ki.cancelGroupInvitation(op.param1,[op.param3])
                            wait["blacklist"][op.param2] = True
                        except:
                            try:
                                ki.kickoutFromGroup(op.param1,[op.param2])
                                ki.findAndAddContactsByMid(op.param3)
                                ki.inviteIntoGroup(op.param1,[op.param3])
                                kc.acceptGroupInvitation(op.param1)
                                km.cancelGroupInvitation(op.param1,[op.param3])
                                wait["blacklist"][op.param2] = True
                            except:
                                try:
                                    kk.kickoutFromGroup(op.param1,[op.param2])
                                    kk.findAndAddContactsByMid(op.param3)
                                    kk.inviteIntoGroup(op.param1,[op.param3])
                                    kc.acceptGroupInvitation(op.param1)
                                    kb.cancelGroupInvitation(op.param1,[op.param3])
                                    wait["blacklist"][op.param2] = True
                                except:
                                    try:
                                        km.kickoutFromGroup(op.param1,[op.param2])
                                        km.findAndAddContactsByMid(op.param3)
                                        km.inviteIntoGroup(op.param1,[op.param3])
                                        kc.acceptGroupInvitation(op.param1)
                                        ki.cancelGroupInvitation(op.param1,[op.param3])
                                        wait["blacklist"][op.param2] = True
                                    except:
                                        try:
                                            kb.kickoutFromGroup(op.param1,[op.param2])
                                            kb.findAndAddContactsByMid(op.param3)
                                            kb.inviteIntoGroup(op.param1,[op.param3])
                                            kc.acceptGroupInvitation(op.param1)
                                            kk.cancelGroupInvitation(op.param1,[op.param3])
                                            wait["blacklist"][op.param2] = True
                                        except:
                                            pass
                return

            if Dmid in op.param3:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    try:
                        kb.kickoutFromGroup(op.param1,[op.param2])
                        kb.findAndAddContactsByMid(op.param3)
                        kb.inviteIntoGroup(op.param1,[op.param3])
                        km.acceptGroupInvitation(op.param1)
                        kk.cancelGroupInvitation(op.param1,[op.param3])
                        wait["blacklist"][op.param2] = True
                    except:
                        try:
                            ki.kickoutFromGroup(op.param1,[op.param2])
                            kc.findAndAddContactsByMid(op.param3)
                            kc.inviteIntoGroup(op.param1,[op.param3])
                            km.acceptGroupInvitation(op.param1)
                            ki.cancelGroupInvitation(op.param1,[op.param3])
                            wait["blacklist"][op.param2] = True
                        except:
                            try:
                                ki.kickoutFromGroup(op.param1,[op.param2])
                                ki.findAndAddContactsByMid(op.param3)
                                ki.inviteIntoGroup(op.param1,[op.param3])
                                km.acceptGroupInvitation(op.param1)
                                kb.cancelGroupInvitation(op.param1,[op.param3])
                                wait["blacklist"][op.param2] = True
                            except:
                                try:
                                    kk.kickoutFromGroup(op.param1,[op.param2])
                                    kk.findAndAddContactsByMid(op.param3)
                                    kk.inviteIntoGroup(op.param1,[op.param3])
                                    km.acceptGroupInvitation(op.param1)
                                    kc.cancelGroupInvitation(op.param1,[op.param3])
                                    wait["blacklist"][op.param2] = True
                                except:
                                    try:
                                        kc.kickoutFromGroup(op.param1,[op.param2])
                                        kc.findAndAddContactsByMid(op.param3)
                                        kc.inviteIntoGroup(op.param1,[op.param3])
                                        km.acceptGroupInvitation(op.param1)
                                        kk.cancelGroupInvitation(op.param1,[op.param3])
                                        wait["blacklist"][op.param2] = True
                                    except:
                                        try:
                                            kb.kickoutFromGroup(op.param1,[op.param2])
                                            kb.findAndAddContactsByMid(op.param3)
                                            kb.inviteIntoGroup(op.param1,[op.param3])
                                            km.acceptGroupInvitation(op.param1)
                                            kc.cancelGroupInvitation(op.param1,[op.param3])
                                            wait["blacklist"][op.param2] = True
                                        except:
                                            pass
                return

            if Emid in op.param3:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    try:
                        ki.kickoutFromGroup(op.param1,[op.param2])
                        kb.findAndAddContactsByMid(op.param3)
                        kb.inviteIntoGroup(op.param1,[op.param3])
                        kb.acceptGroupInvitation(op.param1)
                        km.cancelGroupInvitation(op.param1,[op.param3])
                        wait["blacklist"][op.param2] = True
                    except:
                        try:
                            ki.kickoutFromGroup(op.param1,[op.param2])
                            ki.findAndAddContactsByMid(op.param3)
                            ki.inviteIntoGroup(op.param1,[op.param3])
                            kb.acceptGroupInvitation(op.param1)
                            kk.cancelGroupInvitation(op.param1,[op.param3])
                            wait["blacklist"][op.param2] = True
                        except:
                            try:
                                kk.kickoutFromGroup(op.param1,[op.param2])
                                km.findAndAddContactsByMid(op.param3)
                                km.inviteIntoGroup(op.param1,[op.param3])
                                kb.acceptGroupInvitation(op.param1)
                                ki.cancelGroupInvitation(op.param1,[op.param3])
                                wait["blacklist"][op.param2] = True
                            except:
                                try:
                                    kc.kickoutFromGroup(op.param1,[op.param2])
                                    kk.findAndAddContactsByMid(op.param3)
                                    kk.inviteIntoGroup(op.param1,[op.param3])
                                    kb.acceptGroupInvitation(op.param1)
                                    km.cancelGroupInvitation(op.param1,[op.param3])
                                    wait["blacklist"][op.param2] = True
                                except:
                                    try:
                                        km.kickoutFromGroup(op.param1,[op.param2])
                                        ki.findAndAddContactsByMid(op.param3)
                                        ki.inviteIntoGroup(op.param1,[op.param3])
                                        kb.acceptGroupInvitation(op.param1)
                                        kc.cancelGroupInvitation(op.param1,[op.param3])
                                        wait["blacklist"][op.param2] = True
                                    except:
                                        try:
                                            ki.kickoutFromGroup(op.param1,[op.param2])
                                            km.findAndAddContactsByMid(op.param3)
                                            km.inviteIntoGroup(op.param1,[op.param3])
                                            kb.acceptGroupInvitation(op.param1)
                                            kk.cancelGroupInvitation(op.param1,[op.param3])
                                            wait["blacklist"][op.param2] = True
                                        except:
                                            pass
                                            
        if op.type == 19:
            if mid in op.param3:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    try:
                        kb.kickoutFromGroup(op.param1,[op.param2])
                        kb.findAndAddContactsByMid(op.param3)
                        kb.inviteIntoGroup(op.param1,[op.param3])
                        cl.acceptGroupInvitation(op.param1)
                        kc.cancelGroupInvitation(op.param1,[op.param3])
                        wait["blacklist"][op.param2] = True
                    except:
                        try:
                            km.kickoutFromGroup(op.param1,[op.param2])
                            km.findAndAddContactsByMid(op.param3)
                            km.inviteIntoGroup(op.param1,[op.param3])
                            cl.acceptGroupInvitation(op.param1)
                            ki.cancelGroupInvitation(op.param1,[op.param3])
                            wait["blacklist"][op.param2] = True
                        except:
                            try:
                                kc.kickoutFromGroup(op.param1,[op.param2])
                                kc.findAndAddContactsByMid(op.param3)
                                kc.inviteIntoGroup(op.param1,[op.param3])
                                cl.acceptGroupInvitation(op.param1)
                                kb.cancelGroupInvitation(op.param1,[op.param3])
                                wait["blacklist"][op.param2] = True
                            except:
                                try:
                                    kk.kickoutFromGroup(op.param1,[op.param2])
                                    kk.findAndAddContactsByMid(op.param3)
                                    kk.inviteIntoGroup(op.param1,[op.param3])
                                    cl.acceptGroupInvitation(op.param1)
                                    km.cancelGroupInvitation(op.param1,[op.param3])
                                    wait["blacklist"][op.param2] = True
                                except:
                                    try:
                                        ki.kickoutFromGroup(op.param1,[op.param2])
                                        ki.findAndAddContactsByMid(op.param3)
                                        ki.inviteIntoGroup(op.param1,[op.param3])
                                        cl.acceptGroupInvitation(op.param1)
                                        kc.cancelGroupInvitation(op.param1,[op.param3])
                                        wait["blacklist"][op.param2] = True
                                    except:
                                        try:
                                            kb.kickoutFromGroup(op.param1,[op.param2])
                                            kb.findAndAddContactsByMid(op.param3)
                                            kb.inviteIntoGroup(op.param1,[op.param3])
                                            cl.acceptGroupInvitation(op.param1)
                                            ki.cancelGroupInvitation(op.param1,[op.param3])
                                            wait["blacklist"][op.param2] = True
                                        except:
                                            pass
                return

            if Amid in op.param3:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    try:
                        km.kickoutFromGroup(op.param1,[op.param2])
                        km.findAndAddContactsByMid(op.param3)
                        km.inviteIntoGroup(op.param1,[op.param3])
                        ki.acceptGroupInvitation(op.param1)
                        kb.cancelGroupInvitation(op.param1,[op.param3])
                        wait["blacklist"][op.param2] = True
                    except:
                        try:
                            kc.kickoutFromGroup(op.param1,[op.param2])
                            kc.findAndAddContactsByMid(op.param3)
                            kc.inviteIntoGroup(op.param1,[op.param3])
                            ki.acceptGroupInvitation(op.param1)
                            km.cancelGroupInvitation(op.param1,[op.param3])
                            wait["blacklist"][op.param2] = True
                        except:
                            try:
                                kk.kickoutFromGroup(op.param1,[op.param2])
                                kk.findAndAddContactsByMid(op.param3)
                                kk.inviteIntoGroup(op.param1,[op.param3])
                                ki.acceptGroupInvitation(op.param1)
                                ki.cancelGroupInvitation(op.param1,[op.param3])
                                wait["blacklist"][op.param2] = True
                            except:
                                try:
                                    kb.kickoutFromGroup(op.param1,[op.param2])
                                    kb.findAndAddContactsByMid(op.param3)
                                    kb.inviteIntoGroup(op.param1,[op.param3])
                                    ki.acceptGroupInvitation(op.param1)
                                    kk.cancelGroupInvitation(op.param1,[op.param3])
                                    wait["blacklist"][op.param2] = True
                                except:
                                    try:
                                        km.kickoutFromGroup(op.param1,[op.param2])
                                        km.findAndAddContactsByMid(op.param3)
                                        km.inviteIntoGroup(op.param1,[op.param3])
                                        ki.acceptGroupInvitation(op.param1)
                                        kb.cancelGroupInvitation(op.param1,[op.param3])
                                        wait["blacklist"][op.param2] = True
                                    except:
                                        try:
                                            kk.kickoutFromGroup(op.param1,[op.param2])
                                            kk.findAndAddContactsByMid(op.param3)
                                            kk.inviteIntoGroup(op.param1,[op.param3])
                                            ki.acceptGroupInvitation(op.param1)
                                            km.cancelGroupInvitation(op.param1,[op.param3])
                                            wait["blacklist"][op.param2] = True
                                        except:
                                            pass
                return

            if Bmid in op.param3:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    try:
                        km.kickoutFromGroup(op.param1,[op.param2])
                        km.findAndAddContactsByMid(op.param3)
                        km.inviteIntoGroup(op.param1,[op.param3])
                        kk.acceptGroupInvitation(op.param1)
                        kb.cancelGroupInvitation(op.param1,[op.param3])
                        wait["blacklist"][op.param2] = True
                    except:
                        try:
                            kc.kickoutFromGroup(op.param1,[op.param2])
                            kc.findAndAddContactsByMid(op.param3)
                            kc.inviteIntoGroup(op.param1,[op.param3])
                            kk.acceptGroupInvitation(op.param1)
                            km.cancelGroupInvitation(op.param1,[op.param3])
                            wait["blacklist"][op.param2] = True
                        except:
                            try:
                                ki.kickoutFromGroup(op.param1,[op.param2])
                                ki.findAndAddContactsByMid(op.param3)
                                ki.inviteIntoGroup(op.param1,[op.param3])
                                kk.acceptGroupInvitation(op.param1)
                                kc.cancelGroupInvitation(op.param1,[op.param3])
                                wait["blacklist"][op.param2] = True
                            except:
                                try:
                                    kb.kickoutFromGroup(op.param1,[op.param2])
                                    kb.findAndAddContactsByMid(op.param3)
                                    kb.inviteIntoGroup(op.param1,[op.param3])
                                    kk.acceptGroupInvitation(op.param1)
                                    ki.cancelGroupInvitation(op.param1,[op.param3])
                                    wait["blacklist"][op.param2] = True
                                except:
                                    try:
                                        km.kickoutFromGroup(op.param1,[op.param2])
                                        km.findAndAddContactsByMid(op.param3)
                                        km.inviteIntoGroup(op.param1,[op.param3])
                                        kk.acceptGroupInvitation(op.param1)
                                        kb.cancelGroupInvitation(op.param1,[op.param3])
                                        wait["blacklist"][op.param2] = True
                                    except:
                                        try:
                                            kc.kickoutFromGroup(op.param1,[op.param2])
                                            kc.findAndAddContactsByMid(op.param3)
                                            kc.inviteIntoGroup(op.param1,[op.param3])
                                            kk.acceptGroupInvitation(op.param1)
                                            km.cancelGroupInvitation(op.param1,[op.param3])
                                            wait["blacklist"][op.param2] = True
                                        except:
                                            pass
                return

            if Cmid in op.param3:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    try:
                        kk.kickoutFromGroup(op.param1,[op.param2])
                        kk.findAndAddContactsByMid(op.param3)
                        kk.inviteIntoGroup(op.param1,[op.param3])
                        kc.acceptGroupInvitation(op.param1)
                        ki.cancelGroupInvitation(op.param1,[op.param3])
                        wait["blacklist"][op.param2] = True
                    except:
                        try:
                            kb.kickoutFromGroup(op.param1,[op.param2])
                            kb.findAndAddContactsByMid(op.param3)
                            kb.inviteIntoGroup(op.param1,[op.param3])
                            kc.acceptGroupInvitation(op.param1)
                            kk.cancelGroupInvitation(op.param1,[op.param3])
                            wait["blacklist"][op.param2] = True
                        except:
                            try:
                                km.kickoutFromGroup(op.param1,[op.param2])
                                km.findAndAddContactsByMid(op.param3)
                                km.inviteIntoGroup(op.param1,[op.param3])
                                kc.acceptGroupInvitation(op.param1)
                                kb.cancelGroupInvitation(op.param1,[op.param3])
                                wait["blacklist"][op.param2] = True
                            except:
                                try:
                                    kk.kickoutFromGroup(op.param1,[op.param2])
                                    kk.findAndAddContactsByMid(op.param3)
                                    kk.inviteIntoGroup(op.param1,[op.param3])
                                    kc.acceptGroupInvitation(op.param1)
                                    km.cancelGroupInvitation(op.param1,[op.param3])
                                    wait["blacklist"][op.param2] = True
                                except:
                                    try:
                                        km.kickoutFromGroup(op.param1,[op.param2])
                                        km.findAndAddContactsByMid(op.param3)
                                        km.inviteIntoGroup(op.param1,[op.param3])
                                        kc.acceptGroupInvitation(op.param1)
                                        ki.cancelGroupInvitation(op.param1,[op.param3])
                                        wait["blacklist"][op.param2] = True
                                    except:
                                        try:
                                            ki.kickoutFromGroup(op.param1,[op.param2])
                                            ki.findAndAddContactsByMid(op.param3)
                                            ki.inviteIntoGroup(op.param1,[op.param3])
                                            kc.acceptGroupInvitation(op.param1)
                                            km.cancelGroupInvitation(op.param1,[op.param3])
                                            wait["blacklist"][op.param2] = True
                                        except:
                                            pass
                return

            if Dmid in op.param3:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    try:
                        ki.kickoutFromGroup(op.param1,[op.param2])
                        ki.findAndAddContactsByMid(op.param3)
                        ki.inviteIntoGroup(op.param1,[op.param3])
                        km.acceptGroupInvitation(op.param1)
                        kc.cancelGroupInvitation(op.param1,[op.param3])
                        wait["blacklist"][op.param2] = True
                    except:
                        try:
                            kc.kickoutFromGroup(op.param1,[op.param2])
                            kc.findAndAddContactsByMid(op.param3)
                            kc.inviteIntoGroup(op.param1,[op.param3])
                            km.acceptGroupInvitation(op.param1)
                            kk.cancelGroupInvitation(op.param1,[op.param3])
                            wait["blacklist"][op.param2] = True
                        except:
                            try:
                                kb.kickoutFromGroup(op.param1,[op.param2])
                                kb.findAndAddContactsByMid(op.param3)
                                kb.inviteIntoGroup(op.param1,[op.param3])
                                km.acceptGroupInvitation(op.param1)
                                ki.cancelGroupInvitation(op.param1,[op.param3])
                                wait["blacklist"][op.param2] = True
                            except:
                                try:
                                    kk.kickoutFromGroup(op.param1,[op.param2])
                                    kk.findAndAddContactsByMid(op.param3)
                                    kk.inviteIntoGroup(op.param1,[op.param3])
                                    km.acceptGroupInvitation(op.param1)
                                    kb.cancelGroupInvitation(op.param1,[op.param3])
                                    wait["blacklist"][op.param2] = True
                                except:
                                    try:
                                        kc.kickoutFromGroup(op.param1,[op.param2])
                                        kc.findAndAddContactsByMid(op.param3)
                                        kc.inviteIntoGroup(op.param1,[op.param3])
                                        km.acceptGroupInvitation(op.param1)
                                        ki.cancelGroupInvitation(op.param1,[op.param3])
                                        wait["blacklist"][op.param2] = True
                                    except:
                                        try:
                                            kb.kickoutFromGroup(op.param1,[op.param2])
                                            kb.findAndAddContactsByMid(op.param3)
                                            kb.inviteIntoGroup(op.param1,[op.param3])
                                            km.acceptGroupInvitation(op.param1)
                                            kc.cancelGroupInvitation(op.param1,[op.param3])
                                            wait["blacklist"][op.param2] = True
                                        except:
                                            pass
                return

            if Emid in op.param3:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    try:
                        ki.kickoutFromGroup(op.param1,[op.param2])
                        ki.findAndAddContactsByMid(op.param3)
                        ki.inviteIntoGroup(op.param1,[op.param3])
                        kb.acceptGroupInvitation(op.param1)
                        kk.cancelGroupInvitation(op.param1,[op.param3])
                        wait["blacklist"][op.param2] = True
                    except:
                        try:
                            kc.kickoutFromGroup(op.param1,[op.param2])
                            kc.findAndAddContactsByMid(op.param3)
                            kv.inviteIntoGroup(op.param1,[op.param3])
                            kb.acceptGroupInvitation(op.param1)
                            km.cancelGroupInvitation(op.param1,[op.param3])
                            wait["blacklist"][op.param2] = True
                        except:
                            try:
                                kk.kickoutFromGroup(op.param1,[op.param2])
                                kk.findAndAddContactsByMid(op.param3)
                                kk.inviteIntoGroup(op.param1,[op.param3])
                                kb.acceptGroupInvitation(op.param1)
                                km.cancelGroupInvitation(op.param1,[op.param3])
                                wait["blacklist"][op.param2] = True
                            except:
                                try:
                                    ki.kickoutFromGroup(op.param1,[op.param2])
                                    ki.findAndAddContactsByMid(op.param3)
                                    ki.inviteIntoGroup(op.param1,[op.param3])
                                    kb.acceptGroupInvitation(op.param1)
                                    kc.cancelGroupInvitation(op.param1,[op.param3])
                                    wait["blacklist"][op.param2] = True
                                except:
                                    try:
                                        kc.kickoutFromGroup(op.param1,[op.param2])
                                        kc.findAndAddContactsByMid(op.param3)
                                        kc.inviteIntoGroup(op.param1,[op.param3])
                                        kb.acceptGroupInvitation(op.param1)
                                        kk.cancelGroupInvitation(op.param1,[op.param3])
                                        wait["blacklist"][op.param2] = True
                                    except:
                                        try:
                                            km.kickoutFromGroup(op.param1,[op.param2])
                                            km.findAndAddContactsByMid(op.param3)
                                            km.inviteIntoGroup(op.param1,[op.param3])
                                            kb.acceptGroupInvitation(op.param1)
                                            ki.cancelGroupInvitation(op.param1,[op.param3])
                                            wait["blacklist"][op.param2] = True
                                        except:
                                            pass
                return
#____________________________________________________________________
        if op.type == 17:
            if op.param1 in welcome:
                if op.param2 in Bots:
                    pass
                ginfo = cl.getGroup(op.param1)
                contact = cl.getContact(op.param2).picturePath
                image = 'http://dl.profile.line.naver.jp'+contact
                welcomeMembers(op.param1, [op.param2])
                cl.sendImageWithURL(op.param1, image)
                
        if op.type == 13:
            if op.param2 in wait["blacklist"]:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                if op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        ki.cancelGroupInvitation(op.param1,[op.param2])
                    except:
                        try:
                            kk.cancelGroupInvitation(op.param1,[op.param2])
                        except:
                            try:
                                kc.cancelGroupInvitation(op.param1,[op.param2])
                            except:
                                try:
                                    km.cancelGroupInvitation(op.param1,[op.param2])
                                except:
                                    try:
                                    	kb.cancelGroupInvitation(op.param1,[op.param2])
                                    except:
                                    	pass
                                    	    
                return
#__________________________________ 
        if op.type == 17:
            if op.param2 in wait["blacklist"]:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                if op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        ki.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            kk.kickoutFromGroup(op.param1,[op.param2])
                        except:
                            try:
                                kc.kickoutFromGroup(op.param1,[op.param2])
                            except:
                                try:
                                    km.kickoutFromGroup(op.param1,[op.param2])
                                except:
                                    try:
                                    	kb.kickoutFromGroup(op.param1,[op.param2])
                                    except:
                                    	pass
                                    	    
                return
#__________________________________
#____________________________________________________________________               
        if op.type == 19:
            if op.param2 in wait["blacklist"]:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                if op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        ki.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            kk.kickoutFromGroup(op.param1,[op.param2])
                        except:
                            try:
                                kc.kickoutFromGroup(op.param1,[op.param2])
                            except:
                                try:
                                    km.kickoutFromGroup(op.param1,[op.param2])
                                except:
                                    try:
                                    	kb.kickoutFromGroup(op.param1,[op.param2])
                                    except:
                                    	pass
                                    	    
                return
#____________________________________________________________________
        if op.type == 0:
            return
        if op.type == 5:
            if wait["autoAdd"] == True:
                if op.param2 not in Bots and op.param2 not in owner:
                    if (wait["message"] in [" "," ","\n",None]):
                        pass
                    else:
                        cl.sendMessage(op.param1, wait["message"])

        if op.type == 32:
            if op.param1 in protectcancel:
                if op.param3 in Bots:
                    if op.param2 not in Bots and op.param2 not in Team:
                        wait["blacklist"][op.param2] = True
                        try:
                            if op.param3 not in wait["blacklist"]:
                                ki.findAndAddContactsByMid(op.param1,[Dmid])
                                ki.kickoutFromGroup(op.param1,[op.param2])
                                ki.inviteIntoGroup(op.param1,[Dmid])
                        except:
                            pass

        if op.type == 32:
            if op.param3 in Dmid:
                if op.param2 not in Bots or op.param2 not in owner or op.param2 not in admin or op.param2 not in staff:
                     wait["blacklist"][op.param2] = True
                     try:
                         cl.inviteIntoGroup(op.param1,[op.param3])
                         ki.kickoutFromGroup(op.param1,[op.param2])
                        # cl.sendMessage(op.param1, "➲➢Main cancle w cipok⎌༓༓༓▸")
                     except:
                         pass
#___________________________________________________________________
        if op.type == 19:
            if op.param1 in protect["proall"]:
                if op.param2 in Bots:
                    pass
                elif op.param2 in Bots:
                    pass
                elif op.param2 in owner:
                    pass
                elif op.param2 in admin:
                    pass
                elif op.param2 in staff:
                    pass
                else:
                    cl.kickoutFromGroup(op.param1,[op.param2])
                    if op.param3 in wait["blacklist"]:
                        pass
                    else:
                        cl.findAndAddContactsByMid(op.param3)
                        cl.inviteIntoGroup(op.param1,[op.param3])
                        wait["blacklist"][op.param2] = True

            if op.param1 in protect["protect"]:
                if op.param2 in Bots:
                    pass
                elif op.param2 in owner:
                    pass
                elif op.param2 in admin:
                    pass
                elif op.param2 in staff:
                    pass
                elif op.param2 in Bots:
                    pass
                else:
                    cl.kickoutFromGroup(op.param1,[op.param2])
                    wait["blacklist"][op.param2] = True

            if op.param1 in protect["antijs"]:
                if op.param3 in mid:
                    if op.param2 in Bots:
                        pass
                    elif op.param2 in Bots:
                        pass
                    elif op.param2 in owner:
                        pass
                    elif op.param2 in admin:
                        pass
                    elif op.param2 in staff:
                        pass
                    else:
                        sw.acceptGroupInvitation(op.param1)
                        G = sw.getGroup(op.param1)
                        G.preventedJoinByTicket = False
                        sw.updateGroup(G)
                        Ticket = sw.reissueGroupTicket(op.param1)
                        cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                        ki.acceptGroupInvitationByTicket(op.param1,Ticket)
                        kk.acceptGroupInvitationByTicket(op.param1,Ticket)
                        kc.acceptGroupInvitationByTicket(op.param1,Ticket)
                        km.acceptGroupInvitationByTicket(op.param1,Ticket)
                        kb.acceptGroupInvitationByTicket(op.param1,Ticket)
                        ki.kickoutFromGroup(op.param1,[op.param2])
                        G.preventedJoinByTicket = True
                        wait["blacklist"][op.param2] = True

            try:
                if op.param3 in owner:
                    if op.param2 in Bots:
                        cl.findAndAddContactsByMid(op.param3)
                        cl.inviteIntoGroup(op.param1,[op.param3])
                    elif op.param2 in owner:
                        cl.findAndAddContactsByMid(op.param3)
                        cl.inviteIntoGroup(op.param1,[op.param3])
                    elif op.param2 in admin:
                        pass
                    else:
                        cl.kickoutFromGroup(op.param1,[op.param2])
                        cl.findAndAddContactsByMid(op.param3)
                        cl.inviteIntoGroup(op.param1,[op.param3])
                        if op.param2 in Bots:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True

                if op.param3 in admin:
                    if op.param2 in Bots:
                        cl.findAndAddContactsByMid(op.param3)
                        cl.inviteIntoGroup(op.param1,[op.param3])
                    elif op.param2 in owner:
                        pass
                    elif op.param2 in admin:
                        pass
                    elif op.param2 in Bots:
                        pass
                    else:
                        cl.kickoutFromGroup(op.param1,[op.param2])
                        cl.findAndAddContactsByMid(op.param3)
                        cl.inviteIntoGroup(op.param1,[op.param3])
                        if op.param2 in Bots:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True

                if op.param3 in staff:
                    if op.param2 in Bots:
                        cl.findAndAddContactsByMid(op.param3)
                        cl.inviteIntoGroup(op.param1,[op.param3])
                    elif op.param2 in staff:
                        cl.findAndAddContactsByMid(op.param3)
                        cl.inviteIntoGroup(op.param1,[op.param3])
                    elif op.param2 in owner:
                        pass
                    elif op.param2 in admin:
                        pass
                    elif op.param2 in staff:
                        pass
                    elif op.param2 in Bots:
                        pass
                    else:
                        cl.kickoutFromGroup(op.param1,[op.param2])
                        cl.findAndAddContactsByMid(op.param3)
                        cl.inviteIntoGroup(op.param1,[op.param3])
                        if op.param2 in Bots:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True              
            except:
                pass
                
        if op.type in [25, 26]:           
            msg = op.message
            text = str(msg.text)
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            cmd = command(text)
            isValid = True
            setKey = settings["keyCommand"].title()
            if settings["setKey"] == False: setKey = ''
            if isValid != False:
                if msg.toType == 0 and sender != mid: to = sender
                else: to = receiver
                if receiver in temp_flood:
                    if temp_flood[receiver]["expire"] == True:
                        if cmd == "open" and sender == mid:
                            temp_flood[receiver]["expire"] = False
                            temp_flood[receiver]["time"] = time.time()
                            cl.sendMessage(to, "ᴏɴ ʙʀᴏᴏ")
                        return
                    elif time.time() - temp_flood[receiver]["time"] <= 5:
                        temp_flood[receiver]["flood"] += 1
                        if temp_flood[receiver]["flood"] >= 20:
                            temp_flood[receiver]["flood"] = 0
                            temp_flood[receiver]["expire"] = True
                            ret_ = "ʜᴇʟᴇʜ sᴜᴋᴀ ʙᴀɴɢᴇᴛ ɴʏᴇᴘᴀᴍ..!!!😠 ".format(setKey)
                            cl.sendMessage(to, str(ret_))
                    else:
                         temp_flood[receiver]["flood"] = 0
                         temp_flood[receiver]["time"] = time.time()
                else:
                    temp_flood[receiver] = {
    	                "time": time.time(),
    	                "flood": 0,
    	                "expire": False
                    }
                            
                if msg.toType == 0 and settings["autoReply"] and sender != mid:
                    contact = cl.getContact(sender)
                    rjct = ["auto", "ngetag"]
                    validating = [a for a in rjct if a.lower() in text.lower()]
                    if validating != []: return
                    if contact.attributes != 32:
                        msgSticker = settings["messageSticker"]["listSticker"]["replySticker"]
                        if msgSticker != None:
                            sid = msgSticker["STKID"]
                            spkg = msgSticker["STKPKGID"]
                            sver = msgSticker["STKVER"]
                            sendSticker(to, sver, spkg, sid)
                        if "@!" in settings["replyPesan"]:
                            msg_ = settings["replyPesan"].split("@!")
                            sendMention(to, sender, "[ Auto Reply ]\n" + msg_[0], msg_[1])
                        sendMention(to, sender, "[ Auto Reply ]\nHalo", settings["replyPesan"])
                if msg.contentType == 0 and sender not in mid and msg.toType == 2:
                    if 'MENTION' in msg.contentMetadata.keys()!= None:
                        names = re.findall(r'@(\w+)', text)
                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = mention['MENTIONEES']
                        lists = []
                        gInfo = cl.getGroup(receiver)
                        members = gInfo.members
                        if len(members) == len(mentionees): return
                        elif "list user" in text.lower(): return
                        elif len(mentionees) >= 50: return
                        for mention in mentionees:
                            if mid in mention["M"]:
                                rjct = ["auto", "ngetag"]
                                validating = [a for a in rjct if a.lower() in text.lower()]
                                if validating != []: return
                                if to not in settings["userMentioned"]:
                                    settings["userMentioned"][to] = {}
                                if sender not in settings["userMentioned"][to]:
                                    settings["userMentioned"][to][sender] = 1
                                else:
                                    settings["userMentioned"][to][sender] = settings["userMentioned"][to][sender] + 1
                                if settings["detectMention"] == True:
                                    msgSticker = settings["messageSticker"]["listSticker"]["mentionSticker"]
                                    if msgSticker != None:
                                        sid = msgSticker["STKID"]
                                        spkg = msgSticker["STKPKGID"]
                                        sver = msgSticker["STKVER"]
                                        sendSticker(to, sver, spkg, sid)
                                    if "@!" in settings["mentionPesan"]:
                                        msg_ = settings["mentionPesan"].split("@!")
                                        return sendMention(to, sender, "[ Auto Respond ]\n" + msg_[0], msg_[1])
                                    sendMention(receiver, sender, "[ Auto Respond ]\nOi", "{}".format(str(settings['mentionPesan'])))
                                break  

#____________________________________________________________________                
        if op.type == 55:
            if op.param2 in wait["blacklist"]:
                random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
            else:
                pass

        if op.type == 55:
            try:
                if op.param1 in Setmain["RAreadPoint"]:
                   if op.param2 in Setmain["RAreadMember"][op.param1]:
                       pass
                   else:
                       Setmain["RAreadMember"][op.param1][op.param2] = True
                else:
                   pass
            except:
                pass
        
            if cctv['cyduk'][op.param1]==True:
                if op.param1 in cctv['point']:
                    Name = cl.getContact(op.param2).displayName
                    if Name in cctv['sidermem'][op.param1]:
                        pass
                    else:
                        cctv['sidermem'][op.param1] += "\n~ " + Name
                        siderMembers(op.param1, [op.param2])
                        contact = cl.getContact(op.param2)
                        image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                    #    cl.sendImageWithURL(op.param1, image)
                        cl.sendMessage(op.param1, None, contentMetadata={"STKID":"13162615","STKPKGID":"1326453","STKVER":"1"}, contentType=7)
        
        if op.type == 65:
            if settings["unsendMessage"] == True:
                try:
                    at = op.param1
                    msg_id = op.param2
                    if msg_id in msg_dict:
                        if msg_dict[msg_id]["from"]:
                           if msg_dict[msg_id]["text"] == 'Gambarnya dibawah':
                                ginfo = cl.getGroup(at)
                                Achink = cl.getContact(msg_dict[msg_id]["from"])
                                zx = ""
                                zxc = ""
                                zx2 = []
                                xpesan =  "Gambar Dihapus\nPengirim : "
                                ret_ = "Nama Grup : {}".format(str(ginfo.name))
                                ret_ += "\nWaktu Ngirim : {}".format(dt_to_str(cTime_to_datetime(msg_dict[msg_id]["createdTime"])))
                                ry = str(dhenza.displayName)
                                pesan = ''
                                pesan2 = pesan+"@x \n"
                                xlen = str(len(zxc)+len(xpesan))
                                xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                zx = {'S':xlen, 'E':xlen2, 'M':nadyatj.mid}
                                zx2.append(zx)
                                zxc += pesan2
                                text = xpesan + zxc + ret_ + ""
                                cl.sendMessage(at, text, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)
                                cl.sendImage(at, msg_dict[msg_id]["data"])
                           else:
                                ginfo = cl.getGroup(at)
                                Achink = cl.getContact(msg_dict[msg_id]["from"])
                                ret_ =  "Pesan Dihapus\n"
                                ret_ += "Pengirim : {}".format(str(dhenza.displayName))
                                ret_ += "\nNama Grup : {}".format(str(ginfo.name))
                                ret_ += "\nWaktu Ngirim : {}".format(dt_to_str(cTime_to_datetime(msg_dict[msg_id]["createdTime"])))
                                ret_ += "\nPesannya : {}".format(str(msg_dict[msg_id]["text"]))
                                cl.sendMessage(at, str(ret_))
                        del msg_dict[msg_id]
                except Exception as e:
                    print(e)

        if op.type == 65:
            if settings["unsendMessage"] == True:
                try:
                    at = op.param1
                    msg_id = op.param2
                    if msg_id in msg_dict1:
                        if msg_dict1[msg_id]["from"]:
                                ginfo = cl.getGroup(at)
                                Achink = cl.getContact(msg_dict1[msg_id]["from"])
                                ret_ =  "Sticker Dihapus\n"
                                ret_ += "Pengirim : {}".format(str(dhenza.displayName))
                                ret_ += "\nNama Grup : {}".format(str(ginfo.name))
                                ret_ += "\nWaktu Ngirim : {}".format(dt_to_str(cTime_to_datetime(msg_dict1[msg_id]["createdTime"])))
                                ret_ += "{}".format(str(msg_dict1[msg_id]["text"]))
                                cl.sendMessage(at, str(ret_))
                                cl.sendImage(at, msg_dict1[msg_id]["data"])
                        del msg_dict1[msg_id]
                except Exception as e:
                    print(e)

        if op.type == 26:
           if wait["selfbot"] == True:
               msg = op.message
               if msg._from not in Bots:
                 if wait["talkban"] == True:
                   if msg._from in wait["Talkblacklist"]:
                      try:
                          cl.kickoutFromGroup(msg.to, [msg._from])
                      except:
                          try:
                              ki.kickoutFromGroup(msg.to, [msg._from])
                          except:
                              try:
                                  kk.kickoutFromGroup(msg.to, [msg._from])
                              except:
                                  try:
                                  	kc.kickoutFromGroup(msg.to, [msg._from])
                                  except:
                                      pass
               if 'MENTION' in msg.contentMetadata.keys() != None:
                if msg._from not in Bots:
                 if wait["detectMention"] == True:
                   name = re.findall(r'@(\w+)', msg.text)
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   for mention in mentionees:
                        if mention ['M'] in Bots:
                           saints = cl.getContact(msg._from)
                           sendMention1(msg.to, saints.mid, "", wait["Respontag"])
                           cl.sendMessage(op.param1, None, contentMetadata={"STKID":"13162615","STKPKGID":"1326453","STKVER":"1"}, contentType=7)
                           break
               if 'MENTION' in msg.contentMetadata.keys() != None:
                if msg._from not in Bots:
                 if wait["Mentionkick"] == True:
                   name = re.findall(r'@(\w+)', msg.text)
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   for mention in mentionees:
                        if mention ['M'] in Bots:
                           cl.mentiontag(msg.to,[msg._from])
                           cl.sendMessage(msg.to, "No tag me....")
                           cl.kickoutFromGroup(msg.to, [msg._from])
                           break
               if msg.contentType == 7:
                 if wait["sticker"] == True:
                    msg.contentType = 0
                    cl.sendMessage(msg.to,"Cek ID Sticker\n\nSTKID : " + msg.contentMetadata["STKID"] + "\nSTKPKGID : " + msg.contentMetadata["STKPKGID"] + "\nSTKVER : " + msg.contentMetadata["STKVER"]+ "\n\n「Link Sticker」" + "\nline://shop/detail/" + msg.contentMetadata["STKPKGID"])
               if msg.contentType == 13:
                 if wait["contact"] == True:
                    msg.contentType = 0
                    cl.sendMessage(msg.to,msg.contentMetadata["mid"])
                    if 'displayName' in msg.contentMetadata:
                        contact = cl.getContact(msg.contentMetadata["mid"])
                        path = cl.getContact(msg.contentMetadata["mid"]).picturePath
                        image = 'http://dl.profile.line.naver.jp'+path
                        cl.sendMessage(msg.to,"Nama : " + msg.contentMetadata["displayName"] + "\nMID : " + msg.contentMetadata["mid"] + "\nStatus Msg : " + contact.statusMessage + "\nPicture URL : http://dl.profile.line-cdn.net/" + contact.pictureStatus)
                        cl.sendImageWithURL(msg.to, image)
#=======================================================================
        if op.type == 25 or op.type == 26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0 or msg.toType == 2:
               if msg.toType == 0:
                    to = receiver
               elif msg.toType == 2:
                    to = receiver
               if msg.contentType == 7:
                 if wait["sticker"] == True:
                    msg.contentType = 0
                    cl.sendMessage(msg.to,"STKID : " + msg.contentMetadata["STKID"] + "\nSTKPKGID : " + msg.contentMetadata["STKPKGID"] + "\nSTKVER : " + msg.contentMetadata["STKVER"]+ "\n\n「Link Sticker」" + "\nline://shop/detail/" + msg.contentMetadata["STKPKGID"])
               if msg.contentType == 13:
                 if wait["contact"] == True:
                    msg.contentType = 0
                    cl.sendMessage(msg.to,msg.contentMetadata["mid"])
                    if 'displayName' in msg.contentMetadata:
                        contact = cl.getContact(msg.contentMetadata["mid"])
                        path = cl.getContact(msg.contentMetadata["mid"]).picturePath
                        image = 'http://dl.profile.line.naver.jp'+path
                        cl.sendMessage(msg.to,"Nama : " + msg.contentMetadata["displayName"] + "\nMID : " + msg.contentMetadata["mid"] + "\nStatus Msg : " + contact.statusMessage + "\nPicture URL : http://dl.profile.line-cdn.net/" + contact.pictureStatus)
                        cl.sendImageWithURL(msg.to, image)
#ADD Bots&media
               if msg.contentType == 7:
                  if msg._from in mid:
                     if settings["AddstickerTag"]["status"] == True:
                         settings["AddstickerTag"]["sid"] = msg.contentMetadata["STKID"]
                         settings["AddstickerTag"]["spkg"] = msg.contentMetadata["STKPKGID"]
                         cl.sendMessage(msg.to, "Sticker respon hasben changed")
                         settings["AddstickerTag"]["status"] = False
                         
               if msg.contentType == 1:
                   if msg._from in admin:
                       if msg._from in settings["ChangeVideoProfilePicture"]:
                            del settings["ChangeVideoProfilePicture"][msg._from]
                            cl.downloadObjectMsg(msg_id,'path','image.jpg')
                            cl.dhenzaPurnama('video.mp4','image.jpg')
                            cl.sendMessage(msg.to,"Change Video Profile Success!!!")
                            
               if msg.contentType == 1:
                  if msg._from in mid:
                     if settings["Addimage"]["status"] == True:
                         path = cl.downloadObjectMsg(msg.id)
                         images[settings["Addimage"]["name"]] = str(path)
                         f = codecs.open("image.json","w","utf-8")
                         json.dump(images, f, sort_keys=True, indent=4, ensure_ascii=False)
                         cl.sendMessage(msg.to, "Berhasil menambahkan gambar {}".format(str(settings["Addimage"]["name"])))
                         settings["Addimage"]["status"] = False
                         settings["Addimage"]["name"] = ""
               if msg.contentType == 2:
                  if msg._from in mid:
                     if settings["Addvideo"]["status"] == True:
                         path = cl.downloadObjectMsg(msg.id)
                         videos[settings["Addvideo"]["name"]] = str(path)
                         f = codecs.open("video.json","w","utf-8")
                         json.dump(videos, f, sort_keys=True, indent=4, ensure_ascii=False)
                         cl.sendMessage(msg.to, "Berhasil menambahkan video {}".format(str(settings["Addvideo"]["name"])))
                         settings["Addvideo"]["status"] = False
                         settings["Addvideo"]["name"] = ""
               if msg.contentType == 7:
                  if msg._from in mid:
                     if settings["Addsticker"]["status"] == True:
                         stickers[settings["Addsticker"]["name"]] = {"STKID":msg.contentMetadata["STKID"],"STKPKGID":msg.contentMetadata["STKPKGID"]}
                         f = codecs.open("sticker.json","w","utf-8")
                         json.dump(stickers, f, sort_keys=True, indent=4, ensure_ascii=False)
                         cl.sendMessage(msg.to, "Berhasil menambahkan sticker {}".format(str(settings["Addsticker"]["name"])))
                         settings["Addsticker"]["status"] = False
                         settings["Addsticker"]["name"] = ""
               if msg.contentType == 3:
                  if msg._from in mid:
                     if settings["Addaudio"]["status"] == True:
                         path = cl.downloadObjectMsg(msg.id)
                         audios[settings["Addaudio"]["name"]] = str(path)
                         f = codecs.open("audio.json","w","utf-8")
                         json.dump(audios, f, sort_keys=True, indent=4, ensure_ascii=False)
                         cl.sendMessage(msg.to, "Berhasil menambahkan mp3 {}".format(str(settings["Addaudio"]["name"])))
                         settings["Addaudio"]["status"] = False
                         settings["Addaudio"]["name"] = ""
               if msg.contentType == 0:
                  if settings["autoRead"] == True:
                      cl.sendChatChecked(msg.to, msg_id)
                      print ("Read")
                  if text is None:
                      return
                  else:
                         for sticker in stickers:
                          if msg._from in mid:
                            if text.lower() == sticker:
                               sid = stickers[text.lower()]["STKID"]
                               spkg = stickers[text.lower()]["STKPKGID"]
                               cl.sendSticker(to, spkg, sid)
                         for image in images:
                          if msg._from in mid:
                            if text.lower() == image:
                               cl.sendImage(msg.to, images[image])
                         for audio in audios:
                          if msg._from in mid:
                            if text.lower() == audio:
                               cl.sendAudio(msg.to, audios[audio])
                         for video in videos:
                          if msg._from in mid:
                            if text.lower() == video:
                               cl.sendVideo(msg.to, videos[video])
               if msg.contentType == 13:
                 if msg._from in owner:
                  if wait["addbots"] == True:
                    if msg.contentMetadata["mid"] in Bots:
                        cl.sendMessage(msg.to,"Already in bot")
                        wait["addbots"] = True
                    else:
                        Bots.append(msg.contentMetadata["mid"])
                        wait["addbots"] = True
                        cl.sendMessage(msg.to,"Succes add bot")
                 if wait["dellbots"] == True:
                    if msg.contentMetadata["mid"] in Bots:
                        Bots.remove(msg.contentMetadata["mid"])
                        cl.sendMessage(msg.to,"Succes delete bot")
                    else:
                        wait["dellbots"] = True
                        cl.sendMessage(msg.to,"Nothing in bot")
#ADD STAFF
                 if msg._from in owner or msg._from in admin:
                  if wait["addstaff"] == True:
                    if msg.contentMetadata["mid"] in staff:
                        cl.sendMessage(msg.to,"Already in stafflist")
                        wait["addstaff"] = True
                    else:
                        staff.append(msg.contentMetadata["mid"])
                        wait["addstaff"] = True
                        cl.sendMessage(msg.to,"Succes add to staff")
                 if wait["dellstaff"] == True:
                    if msg.contentMetadata["mid"] in staff:
                        staff.remove(msg.contentMetadata["mid"])
                        cl.sendMessage(msg.to,"Succes expel to staff")
                        wait["dellstaff"] = True
                    else:
                        wait["dellstaff"] = True
                        cl.sendMessage(msg.to,"Nothing in staff")
#ADD ADMIN
                 if msg._from in owner:
                  if wait["addadmin"] == True:
                    if msg.contentMetadata["mid"] in admin:
                        cl.sendMessage(msg.to,"Already in Admin")
                        wait["addadmin"] = True
                    else:
                        admin.append(msg.contentMetadata["mid"])
                        wait["addadmin"] = True
                        cl.sendMessage(msg.to,"Succes Add to Admin")
                 if wait["delladmin"] == True:
                    if msg.contentMetadata["mid"] in admin:
                        admin.remove(msg.contentMetadata["mid"])
                        cl.sendMessage(msg.to,"Succes to expel admin")
                    else:
                        wait["delladmin"] = True
                        cl.sendMessage(msg.to,"Contact itu bukan admin")
#ADD BLACKLIST
                 if msg._from in owner:
                  if wait["wblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["blacklist"]:
                        cl.sendMessage(msg.to,"Already in blacklist")
                        wait["wblacklist"] = True
                    else:
                        wait["blacklist"][msg.contentMetadata["mid"]] = True
                        wait["wblacklist"] = True
                        cl.sendMessage(msg.to,"Succes add to blacklist")
                  if wait["dblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["blacklist"]:
                        del wait["blacklist"][msg.contentMetadata["mid"]]
                        cl.sendMessage(msg.to,"Succes delete blacklist")
                    else:
                        wait["dblacklist"] = True
                        cl.sendMessage(msg.to,"Nothing in blacklist")
#TALKBAN
                 if msg._from in owner:
                  if wait["Talkwblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["Talkblacklist"]:
                        cl.sendMessage(msg.to,"Already in Talkban")
                        wait["Talkwblacklist"] = True
                    else:
                        wait["Talkblacklist"][msg.contentMetadata["mid"]] = True
                        wait["Talkwblacklist"] = True
                        cl.sendMessage(msg.to,"Succes add to Talkban")
                  if wait["Talkdblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["Talkblacklist"]:
                        del wait["Talkblacklist"][msg.contentMetadata["mid"]]
                        cl.sendMessage(msg.to,"Succes delete Talkban")
                    else:
                        wait["Talkdblacklist"] = True
                        cl.sendMessage(msg.to,"Nothing in Talkban")
#UPDATE FOTO
               if msg.contentType == 1:
                 if msg._from in admin:
                    if Setmain["Addimage"] == True:
                        msgid = msg.id
                        fotoo = "https://obs.line-apps.com/talk/m/download.nhn?oid="+msgid
                        headers = cl.Talk.Headers
                        r = requests.get(fotoo, headers=headers, stream=True)
                        if r.status_code == 200:
                            path = os.path.join(os.path.dirname(__file__), 'dataPhotos/%s.jpg' % Setmain["Img"])
                            with open(path, 'wb') as fp:
                                shutil.copyfileobj(r.raw, fp)
                            cl.sendMessage(msg.to, "Berhasil menambahkan gambar")
                        Setmain["Img"] = {}
                        Setmain["Addimage"] = False

               if msg.toType == 2:
                 if msg._from in admin:
                   if settings["groupPicture"] == True:
                     path = cl.downloadObjectMsg(msg_id)
                     settings["groupPicture"] = False
                     cl.updateGroupPicture(msg.to, path)
                     cl.sendMessage(msg.to, "Berhasil mengubah foto group")

               if msg.contentType == 1:
                   if msg._from in admin:
                       if mid in Setmain["RAfoto"]:
                            path = cl.downloadObjectMsg(msg_id)
                            del Setmain["RAfoto"][mid]
                            cl.updateProfilePicture(path)
                            cl.sendMessage(msg.to,"Foto berhasil dirubah")

               if msg.contentType == 1:
                 if msg._from in admin:
                        if Amid in Setmain["RAfoto"]:
                            path = ki.downloadObjectMsg(msg_id)
                            del Setmain["RAfoto"][Amid]
                            ki.updateProfilePicture(path)
                            ki.sendMessage(msg.to,"Foto berhasil dirubah")
                        elif Bmid in Setmain["RAfoto"]:
                            path = kk.downloadObjectMsg(msg_id)
                            del Setmain["RAfoto"][Bmid]
                            kk.updateProfilePicture(path)
                            kk.sendMessage(msg.to,"Foto berhasil dirubah")
                        elif Cmid in Setmain["RAfoto"]:
                            path = kc.downloadObjectMsg(msg_id)
                            del Setmain["RAfoto"][Cmid]
                            kc.updateProfilePicture(path)
                            kc.sendMessage(msg.to,"Foto berhasil dirubah")
                        elif Dmid in Setmain["RAfoto"]:
                            path = km.downloadObjectMsg(msg_id)
                            del Setmain["RAfoto"][Dmid]
                            km.updateProfilePicture(path)
                            km.sendMessage(msg.to,"Foto berhasil dirubah")
                        elif Emid in Setmain["RAfoto"]:
                            path = kb.downloadObjectMsg(msg_id)
                            del Setmain["RAfoto"][Emid]
                            kb.updateProfilePicture(path)
                            kb.sendMessage(msg.to,"Foto berhasil dirubah")
                        elif Zmid in Setmain["RAfoto"]:
                            path = sw.downloadObjectMsg(msg_id)
                            del Setmain["RAfoto"][Zmid]
                            sw.updateProfilePicture(path)
                            sw.sendMessage(msg.to,"Foto berhasil dirubah")

               if msg.contentType == 1:
                 if msg._from in admin:
                   if settings["changePicture"] == True:
                     path1 = ki.downloadObjectMsg(msg_id)
                     path2 = kk.downloadObjectMsg(msg_id)
                     path3 = kc.downloadObjectMsg(msg_id)
                     path4 = km.downloadObjectMsg(msg_id)
                     path5 = kb.downloadObjectMsg(msg_id)
                     settings["changePicture"] = False
                     ki.updateProfilePicture(path1)
                     ki.sendMessage(msg.to, "Berhasil mengubah foto profile bot")
                     kk.updateProfilePicture(path2)
                     kk.sendMessage(msg.to, "Berhasil mengubah foto profile bot")
                     kc.updateProfilePicture(path3)
                     kc.sendMessage(msg.to, "Berhasil mengubah foto profile bot")
                     km.updateProfilePicture(path4)
                     km.sendMessage(msg.to, "Berhasil mengubah foto profile bot")
                     kb.updateProfilePicture(path5)
                     kb.sendMessage(msg.to, "Berhasil mengubah foto profile bot")

               if msg.contentType == 0:
                    if Setmain["autoRead"] == True:
                        cl.sendChatChecked(msg.to, msg_id)
                    if text is None:
                        return
                    else:
                        cmd = command(text)
                        if cmd == ".help":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               helpMessage = help()
                            #   cl.sendMessage(msg.to, str(helpMessage))
                               cl.sendReplyMessage(msg.id, to, str(helpMessage), contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName).format(cl.getContact(sender).pictureStatus)}, contentType=0)
                                                                                       
                        if cmd == ".self on":
                            if msg._from in owner or msg._from in admin or msg._from in staff:
                                wait["selfbot"] = True
                              #  cl.sendMessage(msg.to, "Bot telah di aktifkan")
                                cl.sendReplyMessage(msg.id, to, "sᴇʟғ ᴅɪ ᴀᴋᴛɪᴘᴋᴀɴ", contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName).format(cl.getContact(sender).pictureStatus)}, contentType=0)
                                
                        elif cmd == ".self off":
                            if msg._from in owner or msg._from in admin:
                                wait["selfbot"] = False
                               # cl.sendMessage(msg.to, "Bot off smentara waktu")
                                cl.sendReplyMessage(msg.id, to, "sᴇʟғ ᴅɪ ɴᴏɴ ᴀᴋᴛɪᴘᴋᴀɴ", contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName).format(cl.getContact(sender).pictureStatus)}, contentType=0)
                                
                        elif cmd == '.vp':
                        	if msg._from in owner or msg._from in admin:
                                 me = cl.getContact(mid)
                                 cl.sendVideoWithURL(msg.to,"http://dl.profile.line-cdn.net/" + me.pictureStatus + "/vp")
                                            
                        elif cmd == "":
                          if wait["selfbot"] == True:
                            if msg._from in owner or msg._from in admin or msg._from in staff:
                               helpMessage2 = helpbot()
                               cl.sendMessage(msg.to, str(helpMessage2))

                        elif cmd == ".set":
                          if wait["selfbot"] == True:
                            if msg._from in owner or msg._from in admin:
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)
                                md = "⚜ 𝐌.𝐁.𝐊 𝐒𝐄𝐓 ⚜\n\n"
                                if wait["sticker"] == True: md+="⚜ On Sticker\n"
                                else: md+="⚜ Off Sticker\n"
                                if wait["contact"] == True: md+="⚜ On Contact\n"
                                else: md+="⚜ Off Contact\n"
                                if wait["detectMention"] == True: md+="⚜ On Respon\n"
                                else: md+="⚜ Off Respon\n"
                                if wait["autoJoin"] == True: md+="⚜ On Autojoin\n"
                                else: md+="⚜ Off Autojoin\n"
                                if settings["autoJoinTicket"] == True: md+="⚜ On Jointicket\n"
                                else: md+="⚜ Off Jointicket\n"
                                if wait["autoAdd"] == True: md+="⚜ On Autoadd\n"
                                else: md+="⚜ Off Autoadd\n"
                                if msg.to in welcome: md+="⚜ On Welcome\n"
                                else: md+="⚜ Off Welcome\n"
                                if wait["autoLeave"] == True: md+="⚜ On Autoleave\n"
                                else: md+="⚜ Off Autoleave\n"
                                if msg.to in protect["pqr"]: md+="⚜ On Proqrl\n"
                                else: md+="⚜ Off Proqr\n"
                                if msg.to in protect["proall"]: md+="⚜ On Allpro\n"
                                else: md+="⚜ Off Allpro\n"
                                if msg.to in protect["protect"]: md+="⚜a On Pro\n"
                                else: md+="⚜ Off Pro\n"
                                if msg.to in protect["pinv"]: md+="⚜ On Proinvite\n"
                                else: md+="⚜ Off Proinvite\n"
                                if msg.to in protect["antijs"]: md+="⚜ On AntiJs\n"
                                else: md+="⚜ Off AntiJs\n"
                                if msg.to in protectcancel: md+="⚜ On Procancel\n"
                                else: md+="⚜ Off Procancel\n"
                             #   cl.sendMessage(msg.to, md+"\nDate : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nTime  "+ datetime.strftime(timeNow,'%H:%M:%S')+" ")
                                cl.sendReplyMessage(msg.id, to, md+"\nDate : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nTime  "+ datetime.strftime(timeNow,'%H:%M:%S'), contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName).format(cl.getContact(sender).pictureStatus)}, contentType=0)                              
                                
                        elif cmd == ".creator" or text.lower() == '.creator':
                            if msg._from in owner or msg._from in admin or msg._from in staff:
                                cl.sendText(msg.to,"ᴍ.ʙ.ᴋ ᴄʀᴇᴀᴛᴏʀᴇ")
                                ma = ""
                                for i in creator:
                                    ma = cl.getContact(i)
                                    cl.sendReplyMessage(msg.id, to, None, contentMetadata={'mid': i}, contentType=13)

                        elif cmd == ".about" or cmd == "informasi":
                          if wait["selfbot"] == True:
                            if msg._from in owner or msg._from in admin:
                               sendMention(msg.to, sender, "⚜ ᴍ.ʙ.ᴋ ʟɪsᴇɴᴄᴇ\n")
                               cl.sendReplyMessage(msg.id, to, None, contentMetadata={'mid': mid}, contentType=13)

                        if cmd == ".me" or text.lower() =='.aing':
                         if wait["selfbot"] == True:
                           if msg._from in admin:
                              cl.sendReplyMessage(msg.id, to, text, contentMetadata={'previewUrl': 'http://dl.profile.line-cdn.net/'+cl.getContact(sender).pictureStatus,'i-installUrl': 'https://line.me/ti/p/~achink.93', 'type': 'mt', 'subText': "M.B.K BOTS™", 'a-installUrl': 'https://line.me/ti/p/~achink.93', 'a-installUrl': ' https://line.me/ti/p/~achink.93', 'a-packageName': 'com.spotify.music', 'countryCode': 'ID', 'a-linkUri': 'https://line.me/ti/p/~achink.93', 'i-linkUri': 'https://line.me/ti/p/~achink.93', 'id': 'mt000000000a6b79f9', 'text': 'Khie', 'linkUri': 'https://line.me/ti/p/~achink.93'}, contentType=19)

                        elif (".id " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in owner or msg._from in admin or msg._from in staff:
                               key = eval(msg.contentMetadata["MENTION"])
                               key1 = key["MENTIONEES"][0]["M"]
                               mi = cl.getContact(key1)
                               cl.sendMessage(msg.to, "Nama : "+str(mi.displayName)+"\nMID : " +key1)
                               cl.sendMessage(msg.to, None, contentMetadata={'mid': key1}, contentType=13)

                        elif (".info " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in owner or msg._from in admin or msg._from in staff:
                               key = eval(msg.contentMetadata["MENTION"])
                               key1 = key["MENTIONEES"][0]["M"]
                               mi = cl.getContact(key1)
                               cl.sendReplyMessage(msg.id, to, "Nama : "+str(mi.displayName)+"\nMid : " +key1+"\nStatus Msg"+str(mi.statusMessage))
                               cl.sendReplyMessage(msg.id, to, None, contentMetadata={'mid': key1}, contentType=13)
                               if "videoProfile='{" in str(cl.getContact(key1)):
                                   cl.sendVideoWithURL(msg.to, 'http://dl.profile.line.naver.jp'+str(mi.picturePath)+'/vp.small')
                               else:
                                   cl.sendImageWithURL(msg.to, 'http://dl.profile.line.naver.jp'+str(mi.picturePath))

                        elif cmd == ".bot":
                          if wait["selfbot"] == True:
                            if msg._from in owner or msg._from in admin or msg._from in staff:
                               msg.contentType = 13
                               msg.contentMetadata = {'mid': mid}
                               cl.sendReplyMessage(msg.id, to, None, contentMetadata={'mid': mid}, contentType=13)
                               msg.contentMetadata = {'mid': Amid}
                               cl.sendReplyMessage(msg.id, to, None, contentMetadata={'mid': Amid}, contentType=13)
                               msg.contentMetadata = {'mid': Bmid}
                               cl.sendReplyMessage(msg.id, to, None, contentMetadata={'mid': Bmid}, contentType=13)
                               msg.contentMetadata = {'mid': Cmid}
                               cl.sendReplyMessage(msg.id, to, None, contentMetadata={'mid': Cmid}, contentType=13)
                               msg.contentMetadata = {'mid': Dmid}
                               cl.sendReplyMessage(msg.id, to, None, contentMetadata={'mid': Cmid}, contentType=13)
                               msg.contentMetadata = {'mid': Emid}
                               cl.sendReplyMessage(msg.id, to, None, contentMetadata={'mid': Cmid}, contentType=13)
                               msg.contentMetadata = {'mid': Zmid}
                               cl.sendReplyMessage(msg.id, to, None, contentMetadata={'mid': Cmid}, contentType=13)
                               
                        elif cmd  == ".mbk":
                          if msg._from in admin:
                              cl.sendReplyMessage(msg.id, to,mid)
                              ki.sendReplyMessage(msg.id, to,Amid)
                              kk.sendReplyMessage(msg.id, to,Bmid)
                              kc.sendReplyMessage(msg.id, to,Cmid)
                              km.sendReplyMessage(msg.id, to,Dmid)
                              kb.sendReplyMessage(msg.id, to,Emid)
                              sw.sendReplyMessage(msg.id, to,Zmid)
                              
                        elif text.lower() == "mid":
                              # cl.sendMessage(msg.to, msg._from)
                               cl.sendReplyMessage(msg.id, to, msg._from, contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName),"MSG_SENDER_ICON": "http://dl.profile.line-cdn.net/{}".format(cl.getContact(sender).pictureStatus)}, contentType=0)
                               
                        elif msg.text in ["Bah","Bahh","Bahhh","Bahhhh"]:
                            text = ("Aku ngomong apa yah..!")
                            cl.sendReplyMessage(msg.id, to, text, contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName),"MSG_SENDER_ICON": "http://dl.profile.line-cdn.net/{}".format(cl.getContact(sender).pictureStatus)}, contentType=0)
                            
                        elif msg.text in ["Achink","Acink","Cink","Cing"]:
                            text = ("lama gak liat,nambah keceh ajah kamu")
                            cl.sendReplyMessage(msg.id, to, text, contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName),"MSG_SENDER_ICON": "http://dl.profile.line-cdn.net/{}".format(cl.getContact(sender).pictureStatus)}, contentType=0)
                            
                        elif msg.text in ["Iya","Aku","Iyaa","iyya"]:
                            text = ("Aku left yah..")
                            cl.sendReplyMessage(msg.id, to, text, contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName),"MSG_SENDER_ICON": "http://dl.profile.line-cdn.net/{}".format(cl.getContact(sender).pictureStatus)}, contentType=0)
                            
                        elif msg.text in ["Nyabun","Ngocok","Coli","Nyabuun"]:
                            text = ("Kerjaan qw tuh di kamar mandi tiap hari keren kan😂")
                            cl.sendReplyMessage(msg.id, to, text, contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName),"MSG_SENDER_ICON": "http://dl.profile.line-cdn.net/{}".format(cl.getContact(sender).pictureStatus)}, contentType=0)
                            
                        elif msg.text in ["Nah","Nahh","Nahhh","Nahhhh"]:
                            text = ("Gw kenapa yah..")
                            cl.sendReplyMessage(msg.id, to, text, contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName),"MSG_SENDER_ICON": "http://dl.profile.line-cdn.net/{}".format(cl.getContact(sender).pictureStatus)}, contentType=0)
                            
                        elif msg.text in ["Asem","Aseem","Asemm","Asm"]:
                            text = ("Pantes aku blom mandi dua hari")
                            cl.sendReplyMessage(msg.id, to, text, contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName),"MSG_SENDER_ICON": "http://dl.profile.line-cdn.net/{}".format(cl.getContact(sender).pictureStatus)}, contentType=0)
                            
                        elif msg.text in ["Sepi","Sepii","Seepi","Sepi amat"]:
                            text = ("Perkosa qw ke biar rame😂😂😂")
                            cl.sendReplyMessage(msg.id, to, text, contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName),"MSG_SENDER_ICON": "http://dl.profile.line-cdn.net/{}".format(cl.getContact(sender).pictureStatus)}, contentType=0)
                               
                        elif text.lower() == "sue":
                               cl.sendReplyMessage(msg.id, to,'Loe yang sue kak,qw mah gak')
                               
                        elif text.lower() == "tidur":
                               cl.sendReplyMessage(msg.id, to,'udah tidur jah sono,ribet loe kalo masih melek')
                               
                        elif text.lower() == "respon":
                               cl.sendMessage(to, None, contentMetadata={"STKID":"8244079","STKPKGID":"1202910","STKVER":"1"}, contentType=7)
                               
                        elif text.lower() == "apa":
                               cl.sendMessage(to, None, contentMetadata={"STKID":"65768464","STKPKGID":"4157210","STKVER":"1"}, contentType=7)
                               
                        elif text.lower() == "wkwkwk":
                               cl.sendMessage(to, None, contentMetadata={"STKID":"65768465","STKPKGID":"4157210","STKVER":"1"}, contentType=7)
                               
                        elif text.lower() == "baper":
                               cl.sendMessage(to, None, contentMetadata={"STKID":"65768468","STKPKGID":"4157210","STKVER":"1"}, contentType=7)
                               
                        elif text.lower() == "heleh":
                               cl.sendMessage(to, None, contentMetadata={"STKID":"8244085","STKPKGID":"1202910","STKVER":"1"}, contentType=7)
                               
                        elif text.lower() == "hbd":
                               cl.sendMessage(to, None, contentMetadata={"STKID":"8244073","STKPKGID":"1202910","STKVER":"1"}, contentType=7)
                               
                               
                        elif text.lower() == "bodo":
                               cl.sendMessage(to, None, contentMetadata={"STKID":"9681799","STKPKGID":"1238608","STKVER":"1"}, contentType=7)       
                               
                        elif text.lower() == "go":
                               cl.sendMessage(to, None, contentMetadata={"STKID":"56021040","STKPKGID":"3865357","STKVER":"1"}, contentType=7)
                               
                        elif text.lower() == "tagall":
                               cl.sendReplyMessage(msg.id, to,'Tag ajh sendiri')
                               
                        elif text.lower() == "aa":
                               cl.sendReplyMessage(msg.id, to,'naon nyi iteung, gageroan bae')
                               
                        elif text.lower() == "bot":
                               cl.sendReplyMessage(msg.id, to,'apa kak..')
                               
                        elif text.lower() == "mantan":
                               cl.sendReplyMessage(msg.id, to,'Bukan nya mantan enak ya di buat kolek...!')
                               
                        elif text.lower() == "keluar":
                               cl.sendReplyMessage(msg.id, to,'keluar bu ekooo..!')
                               
                        elif text.lower() == "pekok":
                               cl.sendReplyMessage(msg.id, to,'loe kak yang pekok qw mah bot')
                               
                        elif text.lower() == "njirr":
                               cl.sendReplyMessage(msg.id, to,'Napa kak...?')
                               
                        elif text.lower() == "naik":
                               cl.sendReplyMessage(msg.id, to,'Jangan kak,paling dia mau minya Gift')
                               
                        elif text.lower() == "masuk":
                               cl.sendReplyMessage(msg.id, to,'Masuk pak ekooo..!')
                               
                        elif text.lower() == "bah":
                               cl.sendReplyMessage(msg.id, to,'Bahwan enak tuh kak')
                               
                        elif text.lower() == "sore":
                               cl.sendReplyMessage(msg.id, to,'Kata siapa malam cs')
                               
                        elif text.lower() == "assalamualaikum":
                               cl.sendReplyMessage(msg.id, to,'walikum salam')
                               
                        elif text.lower() == "me":
                               cl.sendReplyMessage(msg.id, to,'Merindu itu emng berat kak')
                               
                        elif text.lower() == "minta":
                               cl.sendReplyMessage(msg.id, to,'Heleh dasar jembut minta mele')
                               
                        elif text.lower() == "sayang":
                               cl.sendReplyMessage(msg.id, to,'Iya sayg apa kabar')
                               
                        elif text.lower() == "halo":
                               cl.sendReplyMessage(msg.id, to,'iya halo juqa bro,')
                                
                        elif cmd == ".reject":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              ginvited = cl.getGroupIdsInvited()
                              if ginvited != [] and ginvited != None:
                                  for gid in ginvited:
                                      cl.rejectGroupInvitation(gid)
                                  cl.sendReplyMessage(msg.id, to, "𝙱𝚎𝚛𝚑𝚊𝚜𝚒𝚕 𝚝𝚘𝚕𝚊𝚔 {} 𝚞𝚗𝚍𝚊𝚗𝚐𝚊𝚗 𝚐𝚛𝚞𝚙".format(str(len(ginvited))))
                              else:
                                  cl.sendReplyMessage(msg.id, to, "𝚃𝚒𝚍𝚊𝚔 𝚊𝚍𝚊 𝚞𝚗𝚍𝚊𝚗𝚐𝚊𝚗 𝚢𝚊𝚗𝚐 𝚝𝚎𝚛𝚝𝚞𝚗𝚍𝚊")

                        elif text.lower() == ".hapus":
                          if wait["selfbot"] == True:
                            if msg._from in owner:
                               try:
                                   cl.removeAllMessages(op.param2)
                                   ki.removeAllMessages(op.param2)
                                   kk.removeAllMessages(op.param2)
                                   kc.removeAllMessages(op.param2)
                                   km.removeAllMessages(op.param2)
                                   kb.removeAllMessages(op.param2)
                                   cl.sendReplyMessage(msg.id, to,"𝚂𝚞𝚍𝚊𝚑 𝚋𝚎𝚛𝚜𝚒𝚑")
                                   ki.sendReplyMessage(msg.id, to,"𝚂𝚞𝚍𝚊𝚑 𝚋𝚎𝚛𝚜𝚒𝚑")
                                   kk.sendReplyMessage(msg.id, to,"𝚂𝚞𝚍𝚊𝚑 𝚋𝚎𝚛𝚜𝚒𝚑")
                                   kc.sendReplyMessage(msg.id, to,"𝚂𝚞𝚍𝚊𝚑 𝚋𝚎𝚛𝚜𝚒𝚑")
                                   km.sendReplyMessage(msg.id, to,"𝚂𝚞𝚍𝚊𝚑 𝚋𝚎𝚛𝚜𝚒𝚑")
                                   kb.sendReplyMessage(msg.id, to,"𝚂𝚞𝚍𝚊𝚑 𝚋𝚎𝚛𝚜𝚒𝚑")
                               except:
                                   pass
                                   
                        elif cmd == ".jepit":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                try:
                                    anggota = [Bmid,Cmid,Amid,Dmid,Emid,Zmid]
                                    cl.inviteIntoGroup(msg.to, anggota)
                                    kk.acceptGroupInvitation(msg.to)
                                    kc.acceptGroupInvitation(msg.to)
                                    ki.acceptGroupInvitation(msg.to)
                                    km.acceptGroupInvitation(msg.to)
                                    kb.acceptGroupInvitation(msg.to)
                                except:
                                    pass
                                    
                        elif cmd == ".jepit dila":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                try:
                                    anggota = ["u25bffa9c631a7a318c008f252c1fe34e","u475f5fb63c4b295e43cddc0a9b7c806a","uf1aa46ce1796e3c941c77ad32796a07a","u26aee7f0e39c0705dc130e020e1592c0","u97975fd67ee5b2399bade29dd85bc7c8","u89f205dbf012f113773cfe356c957184","ub3132514505582b5a9c8ec30d8e38223"]
                                    cl.inviteIntoGroup(msg.to, anggota) 
                                except:
                                    pass
                                    
                        elif cmd == ".jepit marsya":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                try:
                                    anggota = ["u46dba14744f7175de6cfc1cfe3f0826a"]
                                    cl.inviteIntoGroup(msg.to, anggota) 
                                except:
                                    pass
                                    
                        elif cmd == ".jepit mamah":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                try:
                                    anggota = ["ua2f2242b2c3ad3cfe229c022215424dc"]
                                    cl.inviteIntoGroup(msg.to, anggota) 
                                except:
                                    pass
                                    
                        elif cmd == ".jepit bini":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                try:
                                    anggota = ["u7272587eaec0c324c883a86a3f3d6b5c"]
                                    cl.inviteIntoGroup(msg.to, anggota) 
                                except:
                                    pass
                                    
                        elif cmd == ".jepit laki":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                try:
                                    anggota = ["u6e4534dd63e82642f29205d2c993c642"]
                                    cl.inviteIntoGroup(msg.to, anggota) 
                                except:
                                    pass
                                    
                        elif cmd == ".jepit joker":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                try:
                                    anggota = ["u471d2458faa61b0c31a8dd1c3dd21cd6","u62305da04174205c9436d8a72da7261a","u204ccb4abc1d21e79c9138488e81d323","u4c1be06c71d010e6e234500e1509da67","ufbdabeb89d6282cc5a360adfaeff9b2f","u206298823b12db8781f707dda6154a60","ua891c4835e91235309f4c28ad20f6e5e"]
                                    cl.inviteIntoGroup(msg.to, anggota) 
                                except:
                                    pass

                        elif cmd.startswith(".bc "):
                          if wait["selfbot"] == True:
                            if msg._from in owner:
                               sep = text.split(" ")
                               pesan = text.replace(sep[0] + " ","")
                               saya = cl.getGroupIdsJoined()
                               for group in saya:
                                   cl.sendMessage(group,"⚜ ʙʀᴏᴀᴅᴄᴀsᴛ \n\n" + str(pesan))

                        elif text.lower() == ".mykey":
                          if wait["selfbot"] == True:
                            if msg._from in owner or msg._from in admin:
                               cl.sendReplyMessage(msg.id, to, "⚜ ᴍ.ʙ.ᴋ ᴋᴇʏᴍᴜ \n\n" + str(Setmain["keyCommand"]) + " ")
                               
                        elif cmd.startswith(".setkey "):
                          if wait["selfbot"] == True:
                            if msg._from in owner:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   cl.sendMessage(msg.to, "key berhasil di set")
                               else:
                                   Setmain["keyCommand"] = str(key).lower()
                                   cl.sendReplyMessage(msg.id, to, "⚜ ᴍ.ʙ.ᴋ sᴇᴛᴋᴇʏ\n\n⚜ ᴋᴇʏ ʙᴇʀʜᴀsɪʟ ᴅɪ ɢᴀɴᴛɪ ᴍᴇɴᴊᴀᴅɪ {}".format(str(key).lower()))

                        elif text.lower() == ".resetkey":
                          if wait["selfbot"] == True:
                            if msg._from in owner:
                               Setmain["keyCommand"] = ""
                               cl.sendReplyMessage(msg.id, to, "ᴋᴇʏ ᴋᴇᴍʙᴀʟɪ ᴋᴇ sᴇᴍᴜʟᴀ ")

                        elif cmd == ".cek":
                          if wait["selfbot"] == True:
                            if msg._from in owner:
                               cl.sendReplyMessage(msg.id, to, ".me")
                               Setmain["restartPoint"] = msg.to
                               restartBot()
                            #   cl.sendMessage(msg.to, "Done...")
                            
                        elif cmd == ".waktu":
                          if wait["selfbot"] == True:
                            if msg._from in owner or msg._from in admin:
                               eltime = time.time() - mulai
                               bot = "Active " +waktu(eltime)
                               cl.sendReplyMessage(msg.id, to,bot)
                            
                        elif cmd == ".ginfo":
                          if msg._from in owner or msg._from in admin or msg._from in staff:
                            try:
                                G = cl.getGroup(msg.to)
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "Tertutup"
                                    gTicket = "Tidak ada"
                                else:
                                    gQr = "Terbuka"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(cl.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                cl.sendReplyMessage(msg.id, to, "⚜ ᴍ.ʙ.ᴋ ɢʀᴜᴘ ɪɴғᴏ\n\n⚜ ɴᴀᴍᴀ ɢʀᴜᴘ : {}".format(G.name)+ "\n⚜ ɪᴅ ɢʀᴜᴘ : {}".format(G.id)+ "\n⚜ ᴘᴇᴍʙᴜᴀᴛ ɢʀᴜᴘ : {}".format(G.creator.displayName)+ "\n⚜ ᴡᴀᴋᴛᴜ ᴅɪ ʙᴜᴀᴛ : {}".format(str(timeCreated))+ "\n⚜ ᴊᴜᴍʟᴀʜ ᴍᴇᴍʙᴇʀ : {}".format(str(len(G.members)))+ "\n⚜ ᴊᴜᴍʟᴀʜ ᴘᴇɴᴅɪɴɢᴀɴ : {}".format(gPending)+ "\n⚜ ᴋᴏᴅᴇ ϙʀ : {}".format(gQr)+ "\n⚜ ɢʀᴜᴘ ᴛɪᴄᴋᴇᴛ : {}".format(gTicket))
                                cl.sendReplyMessage(msg.id, to, None, contentMetadata={'mid': G.creator.mid}, contentType=13)
                                cl.sendImageWithURL(msg.to, 'http://dl.profile.line-cdn.net/'+G.pictureStatus)
                            except Exception as e:
                                cl.sendReplyMessage(msg.id, to, str(e))

                        elif cmd.startswith(".ingrup"):
                          if msg._from in owner or msg._from in admin:
                            separate = text.split(" ")
                            number = text.replace(separate[0] + " ","")
                            groups = cl.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = cl.getGroup(group)
                                try:
                                    gCreator = G.creator.displayName
                                except:
                                    gCreator = "Tidak ditemukan"
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "Tertutup"
                                    gTicket = "Tidak ada"
                                else:
                                    gQr = "Terbuka"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(cl.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                ret_ += "⚜ ᴍ.ʙ.ᴋ ɢʀᴜᴘ ɪɴғᴏ\n"
                                ret_ += "\n⚜ ɴᴀᴍᴀ ɢʀᴜᴘ : {}".format(G.name)
                                ret_ += "\n⚜ ɪᴅ ɢʀᴜᴘ : {}".format(G.id)
                                ret_ += "\n⚜ ᴘᴇᴍʙᴜᴀᴛ ɢʀᴜᴘ : {}".format(gCreator)
                                ret_ += "\n⚜ ᴡᴀᴋᴛᴜ ᴅɪ ʙᴜᴀᴛ : {}".format(str(timeCreated))
                                ret_ += "\n⚜ᴊᴜᴍʟᴀʜ ᴍᴇᴍʙᴇʀ : {}".format(str(len(G.members)))
                                ret_ += "\n⚜ ᴊᴜᴍʟᴀʜ ᴘᴇɴᴅɪɴɢᴀɴ : {}".format(gPending)
                                ret_ += "\n⚜ᴋᴏᴅᴇ ϙʀ : {}".format(gQr)
                                ret_ += "\n⚜ ɢʀᴜᴘ ᴛɪᴄᴋᴇᴛ : {}".format(gTicket)
                                ret_ += ""
                                cl.sendMessage(to, str(ret_))
                            except:
                                pass

                        elif cmd.startswith(".anggota"):
                          if msg._from in owner or msg._from in admin:
                            separate = msg.text.split(" ")
                            number = msg.text.replace(separate[0] + " ","")
                            groups = cl.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = cl.getGroup(group)
                                no = 0
                                ret_ = ""
                                for mem in G.members:
                                    no += 1
                                    ret_ += "\n " ""+ str(no) + ". " + mem.displayName
                                cl.sendReplyMessage(msg.id, to,"⚜ ɴᴀᴍᴀ ɢʀᴜᴘ : " + str(G.name) + " \n\n⚜ ʟɪsᴛ ᴀɴɢɢᴏᴛᴀ  \n" + ret_ + "\n\n⚜ ᴛᴏᴛᴀʟ %i ᴀɴɢɢᴏᴛᴀ" % len(G.members))
                            except: 
                                pass

                        elif cmd.startswith(".leave "):
                          if msg._from in owner or msg._from in admin:
                            separate = msg.text.split(" ")
                            number = msg.text.replace(separate[0] + " ","")
                            groups = cl.getGroupIdsJoined()
                            group = groups[int(number)-1]
                            for i in group:
                                ginfo = cl.getGroup(i)
                                if ginfo == group:
                                    cl.leaveGroup(i)
                                    cl.sendMessage(msg.to,"Leave in groups " +str(ginfo.name))

                        elif cmd == ".lteman":
                          if wait["selfbot"] == True:
                            if msg._from in owner:
                               ma = ""
                               a = 0
                               gid = cl.getAllContactIds()
                               for i in gid:
                                   G = cl.getContact(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "" + str(a) + ". " +G.displayName+ "\n"
                               cl.sendReplyMessage(msg.id, to,"⚜ ᴍ.ʙ.ᴋ ʟɪᴛs ᴛᴇᴍᴀɴ\n\n"+ma+"\n⚜ ᴛᴏᴛᴀʟ "+str(len(gid))+" ᴛᴇᴍᴀɴ")

                        elif cmd == ".glist":
                          if wait["selfbot"] == True:
                            if msg._from in owner:
                               ma = ""
                               a = 0
                               gid = cl.getGroupIdsJoined()
                               for i in gid:
                                   G = cl.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "" + str(a) + ". " +G.name+ "\n"
                               cl.sendReplyMessage(msg.id, to,"⚜ ᴍ.ʙ.ᴋ ʟɪsᴛ ɢʀᴜᴘ\n\n"+ma+"\n⚜ ᴛᴏᴛᴀʟ "+str(len(gid))+" ɢʀᴜᴘ")
                               
                        elif cmd == ".glist1":
                          if wait["selfbot"] == True:
                            if msg._from in owner:
                               ma = ""
                               a = 0
                               gid = ki.getGroupIdsJoined()
                               for i in gid:
                                   G = ki.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "" + str(a) + ". " +G.name+ "\n"
                               ki.sendReplyMessage(msg.id, to,"⚜ ᴍ.ʙ.ᴋ ʟɪsᴛ ɢʀᴜᴘ\n\n"+ma+"\n⚜ ᴛᴏᴛᴀʟ "+str(len(gid))+" ɢʀᴜᴘ")
                               
                        elif cmd == ".glist2":
                          if wait["selfbot"] == True:
                            if msg._from in owner:
                               ma = ""
                               a = 0
                               gid = kk.getGroupIdsJoined()
                               for i in gid:
                                   G = kk.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "" + str(a) + ". " +G.name+ "\n"
                               kk.sendReplyMessage(msg.id, to,"⚜ ᴍ.ʙ.ᴋ ʟɪsᴛ ɢʀᴜᴘ\n\n"+ma+"\n⚜ ᴛᴏᴛᴀʟ "+str(len(gid))+" ɢʀᴜᴘ")
                               
                        elif cmd == ".glist3":
                          if wait["selfbot"] == True:
                            if msg._from in owner:
                               ma = ""
                               a = 0
                               gid = kc.getGroupIdsJoined()
                               for i in gid:
                                   G = kc.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "" + str(a) + ". " +G.name+ "\n"
                               kc.sendReplyMessage(msg.id, to,"⚜ ᴍ.ʙ.ᴋ ʟɪsᴛ ɢʀᴜᴘ\n\n"+ma+"\n⚜ ᴛᴏᴛᴀʟ "+str(len(gid))+" ɢʀᴜᴘ")
                               
                        elif cmd == ".glist4":
                          if wait["selfbot"] == True:
                            if msg._from in owner:
                               ma = ""
                               a = 0
                               gid = km.getGroupIdsJoined()
                               for i in gid:
                                   G = km.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "" + str(a) + ". " +G.name+ "\n"
                               km.sendReplyMessage(msg.id, to,"⚜ ᴍ.ʙ.ᴋ ʟɪsᴛ ɢʀᴜᴘ\n\n"+ma+"\n⚜ ᴛᴏᴛᴀʟ "+str(len(gid))+" ɢʀᴜᴘ")
                               
                        elif cmd == ".glist5":
                          if wait["selfbot"] == True:
                            if msg._from in owner:
                               ma = ""
                               a = 0
                               gid = kb.getGroupIdsJoined()
                               for i in gid:
                                   G = kb.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "" + str(a) + ". " +G.name+ "\n"
                               kb.sendReplyMessage(msg.id, to,"⚜ ᴍ.ʙ.ᴋ ʟɪsᴛ ɢʀᴜᴘ\n\n"+ma+"\n⚜ ᴛᴏᴛᴀʟ "+str(len(gid))+" ɢʀᴜᴘ")
                               
                        elif cmd == ".glist6":
                          if wait["selfbot"] == True:
                            if msg._from in owner:
                               ma = ""
                               a = 0
                               gid = sw.getGroupIdsJoined()
                               for i in gid:
                                   G = sw.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "" + str(a) + ". " +G.name+ "\n"
                               sw.sendReplyMessage(msg.id, to,"⚜ ᴍ.ʙ.ᴋ ʟɪsᴛ ɢʀᴜᴘ\n\n"+ma+"\n⚜ ᴛᴏᴛᴀʟ "+str(len(gid))+" ɢʀᴜᴘ")

                        elif cmd == ".tutup":
                          if wait["selfbot"] == True:
                            if msg._from in owner or msg._from in admin:
                                if msg.toType == 2:
                                   X = cl.getGroup(msg.to)
                                   X.preventedJoinByTicket = True
                                   cl.updateGroup(X)
                                   cl.sendReplyMessage(msg.id, to, "ᴄᴏᴅᴇ ϙʀ ᴜᴅᴀʜ ᴅɪ ᴛᴜᴛᴜᴘ")
                                   
                        elif text.lower() == '.tag':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              group = cl.getGroup(msg.to)
                              nama = [contact.mid for contact in group.members]
                              k = len(nama)//20
                              for a in range(k+1):
                                  txt = u''
                                  s=0
                                  b=[]
                                  for i in group.members[a*20 : (a+1)*20]:
                                      b.append({"S":str(s), "E" :str(s+6), "M":i.mid})
                                      s += 7
                                      txt += u'@Alin \n'
                                  cl.sendReplyMessage(msg.id, to, text=txt, contentMetadata={u'MENTION': json.dumps({'MENTIONEES':b})}, contentType=0)

                        elif cmd == ".url":
                          if wait["selfbot"] == True:
                            if msg._from in owner or msg._from in admin:
                                if msg.toType == 2:
                                   x = cl.getGroup(msg.to)
                                   if x.preventedJoinByTicket == True:
                                      x.preventedJoinByTicket = False
                                      cl.updateGroup(x)
                                   gurl = cl.reissueGroupTicket(msg.to)
                                   cl.sendReplyMessage(msg.id, to, "⚜ ᴍ.ʙ.ᴋ ɢʀᴜᴘ ᴛɪᴄᴋᴇᴛ\n\n⚜ ɴᴀᴍᴀ ɢʀᴜᴘ : "+str(x.name)+ "\n⚜ ᴛɪᴄᴋᴇᴛ ɢʀᴜᴘ : http://line.me/R/ti/g/"+gurl)

#===========BOT UPDATE============#
                        elif cmd == ".updategrup":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if msg.toType == 2:
                                settings["groupPicture"] = True
                                cl.sendReplyMessage(msg.id, to,"Kirim potonya kak...!")

                        elif cmd == ".updatebot":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                settings["changePicture"] = True
                                cl.sendReplyMessage(msg.id, to,o,"Kirim potonya kak...!")
                                
                        elif cmd == ".updatefoto":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                Setmain["RAfoto"][mid] = True
                                cl.sendReplyMessage(msg.id, to,"Kirim potonya kak...!")
                                
                        elif cmd == ".b1up":
                            if msg._from in admin:
                                Setmain["RAfoto"][Amid] = True
                                ki.sendReplyMessage(msg.id, to,"Kirim potonya kak...!")
                                
                        elif cmd == ".b2up":
                            if msg._from in admin:
                                Setmain["RAfoto"][Bmid] = True
                                kk.sendReplyMessage(msg.id, to,"Kirim potonya kak...!")
                                
                        elif cmd == ".b3up":
                            if msg._from in admin:
                                Setmain["RAfoto"][Cmid] = True
                                kc.sendReplyMessage(msg.id, to,"Kirim potonya kak...!")
                                
                        elif cmd == ".b4up":
                            if msg._from in admin:
                                Setmain["RAfoto"][Dmid] = True
                                km.sendReplyMessage(msg.id, to,"Kirim potonya kak...!")
                                
                        elif cmd == ".b5up":
                            if msg._from in admin:
                                Setmain["RAfoto"][Emid] = True
                                kb.sendReplyMessage(msg.id, to,"Kirim potonya kak...!")
                                
                        elif cmd == ".cinkup":
                            if msg._from in admin:
                                Setmain["RAfoto"][Zmid] = True
                                sw.sendReplyMessage(msg.id, to,"Kirim potonya kak...!")

                        elif cmd.startswith(".myname:"):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = cl.getProfile()
                                profile.displayName = string
                                cl.updateProfile(profile)
                                cl.sendReplyMessage(msg.id, to,"Nama diganti jadi " + string + "")

                        elif cmd.startswith(".cink1nm "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = ki.getProfile()
                                profile.displayName = string
                                ki.updateProfile(profile)
                                ki.sendReplyMessage(msg.id, to,"Nama diganti jadi " + string + "")

                        elif cmd.startswith(".cink2nm "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = kk.getProfile()
                                profile.displayName = string
                                kk.updateProfile(profile)
                                kk.sendReplyMessage(msg.id, to,"Nama diganti jadi " + string + "")

                        elif cmd.startswith(".cink3nm "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = kc.getProfile()
                                profile.displayName = string
                                kc.updateProfile(profile)
                                kc.sendReplyMessage(msg.id, to,"Nama diganti jadi " + string + "")
                                
                        elif cmd.startswith(".cink4nm "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = km.getProfile()
                                profile.displayName = string
                                km.updateProfile(profile)
                                km.sendReplyMessage(msg.id, to,"Nama diganti jadi " + string + "")
                                
                        elif cmd.startswith(".cink5nm "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = kb.getProfile()
                                profile.displayName = string
                                kb.updateProfile(profile)
                                kb.sendReplyMessage(msg.id, to,"Nama diganti jadi " + string + "")

                        elif cmd.startswith(".cinknm "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = sw.getProfile()
                                profile.displayName = string
                                sw.updateProfile(profile)
                                sw.sendReplyMessage(msg.id, to,"Nama diganti jadi " + string + "")

#===========BOT UPDATE============#
                        

                        elif cmd == ".lbot":
                          if wait["selfbot"] == True:
                            if msg._from in owner or msg._from in admin or msg._from in staff:
                                ma = ""
                                a = 0
                                for m_id in Bots:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +cl.getContact(m_id).displayName + "\n"
                              #  cl.sendMessage(msg.to,"⚜ ʟɪsᴛ ʙᴏᴛ \n\n\n"+ma+"\n%s ʙᴏᴛ" %(str(len(Bots))))
                                cl.sendReplyMessage(msg.id, to,"⚜ ʟɪsᴛ ʙᴏᴛ \n\n\n"+ma+"\n%s ʙᴏᴛ" %(str(len(Bots))))

                        elif cmd == ".cink come":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                try:
                                    ginfo = cl.getGroup(msg.to)
                                    cl.inviteIntoGroup(msg.to, [Zmid])
                                #    cl.sendMessage(msg.to,"Redy stay "+str(ginfo.name)+" Siap Backup")
                                except:
                                    pass

                        elif cmd == ".staff":
                          if wait["selfbot"] == True:
                            if msg._from in owner or msg._from in admin or msg._from in staff:
                                ma = ""
                                mb = ""
                                mc = ""
                                a = 0
                                b = 0
                                c = 0
                                for m_id in owner:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +cl.getContact(m_id).displayName + "\n"
                                for m_id in admin:
                                    b = b + 1
                                    end = '\n'
                                    mb += str(b) + ". " +cl.getContact(m_id).displayName + "\n"
                                for m_id in staff:
                                    c = c + 1
                                    end = '\n'
                                    mc += str(c) + ". " +cl.getContact(m_id).displayName + "\n"
                                cl.sendReplyMessage(msg.id, to,"⚜ ᴍ.ʙ.ᴋ ᴍᴏᴅᴇʀᴀᴛᴏʀ\n\n⚜ ᴏᴡɴᴇʀ\n"+ma+"\n⚜ ᴀᴅᴍɪɴ\n"+mb+"\n⚜sᴛᴀғғ\n"+mc+"\n%s ᴍᴏᴅᴇʀᴀᴛᴏʀ" %(str(len(owner)+len(admin)+len(staff))))

                        elif cmd == ".lpro":
                          if wait["selfbot"] == True:
                            if msg._from in owner or msg._from in admin:
                                ma = ""
                                mb = ""
                                mc = ""
                                md = ""
                                mg = ""
                                mf = ""
                                a = 0
                                b = 0
                                c = 0
                                d = 0
                                g = 0
                                f = 0
                                gid = protect["pqr"]
                                for group in gid:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +cl.getGroup(group).name + "\n"
                                gid = protect["protect"]
                                for group in gid:
                                    b = b + 1
                                    end = '\n'
                                    mb += str(b) + ". " +cl.getGroup(group).name + "\n"
                                gid = protect["proall"]
                                for group in gid:
                                    d = d + 1
                                    end = '\n'
                                    md += str(d) + ". " +cl.getGroup(group).name + "\n"
                                gid = protectcancel
                                for group in gid:
                                    c = c + 1
                                    end = '\n'
                                    mc += str(c) + ". " +cl.getGroup(group).name + "\n"
                                gid = protect["pinv"]
                                for group in gid:
                                    f = f + 1
                                    end = '\n'
                                    mf += str(f) + ". " +cl.getGroup(group).name + "\n"
                                gid = protect["antijs"]
                                for group in gid:
                                    g = g + 1
                                    end = '\n'
                                    mg += str(g) + ". " +cl.getGroup(group).name + "\n"
                                cl.sendReplyMessage(msg.id, to,"⚜ ᴍ.ʙ.ᴋ ʟɪsᴛ ᴘʀᴏᴛᴇᴄᴛɪᴏɴ\n\n⚜ ᴘʀᴏ ᴜʀʟ\n"+ma+"\n⚜ ᴀʟʟ ᴘʀᴏ\n"+mb+"\n⚜ ᴘʀᴏᴛᴇᴄᴛ\n"+mf+"\n⚜ ᴘʀᴏ ᴄᴀɴᴄᴇʟ\n"+mc+"\n⚜ ᴘʀᴏ ɪɴᴠɪᴛᴇ\n"+md+"\n⚜ ᴘʀᴏ sɪᴀɢᴀ\n"+mg+"\n⚜ ᴘʀᴏʟɪsᴛ %s ʏᴀɴɢ ᴀᴋᴛɪғ" %(str(len(protect["pqr"])+len(protect["protect"])+len(protect["antijs"])+len(protect["proall"])+len(protectcancel)+len(protect["pinv"]))))
                              #  cl.sendReplyMessage(msg.id, to, "⚜ ᴍ.ʙ.ᴋ ʟɪsᴛ ᴘʀᴏᴛᴇᴄᴛɪᴏɴ\n\n⚜ ᴘʀᴏ ᴜʀʟ\n"+ma+"\n⚜ ᴀʟʟ ᴘʀᴏ\n"+mb+"\n⚜ ᴘʀᴏᴛᴇᴄᴛ\n"+mf+"\n⚜ ᴘʀᴏ ᴄᴀɴᴄᴇʟ\n"+mc+"\n⚜ ᴘʀᴏ ɪɴᴠɪᴛᴇ\n"+md+"\n⚜ ᴘʀᴏ sɪᴀɢᴀ\n"+mg+"\n⚜ ᴘʀᴏʟɪsᴛ %s ʏᴀɴɢ ᴀᴋᴛɪғ" %(str(len(protect["pqr"])+len(protect["protect"])+len(protect["antijs"])+len(protect["proall"])+len(protectcancel)+len(protect["pinv"], contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName).format(cl.getContact(sender).pictureStatus)}, contentType=0),

                        elif cmd == ".respon":
                          if wait["selfbot"] == True:
                            if msg._from in owner or msg._from in admin or msg._from in staff:
                               # ki.sendMessage(msg.to,responsename1)
                                ki.sendReplyMessage(msg.id, to, responsename1, contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(ki.getContact(sender).displayName).format(ki.getContact(sender).pictureStatus)}, contentType=0)
                             #   kk.sendMessage(msg.to,responsename2)
                                kk.sendReplyMessage(msg.id, to, responsename2, contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(kk.getContact(sender).displayName).format(kk.getContact(sender).pictureStatus)}, contentType=0)
                             #   kc.sendMessage(msg.to,responsename3)
                                kc.sendReplyMessage(msg.id, to, responsename3, contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(kc.getContact(sender).displayName).format(kc.getContact(sender).pictureStatus)}, contentType=0)
                          #      km.sendMessage(msg.to,responsename4)
                                km.sendReplyMessage(msg.id, to, responsename4, contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(km.getContact(sender).displayName).format(km.getContact(sender).pictureStatus)}, contentType=0)
                            #    kb.sendMessage(msg.to,responsename5)
                                kb.sendReplyMessage(msg.id, to, responsename5, contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(kb.getContact(sender).displayName).format(kb.getContact(sender).pictureStatus)}, contentType=0)
                          #      sw.sendMessage(msg.to,responsename6)
                                sw.sendReplyMessage(msg.id, to, responsename6, contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(sw.getContact(sender).displayName).format(sw.getContact(sender).pictureStatus)}, contentType=0)
                                
                                
                        elif cmd == ".come":
                         if msg._from in admin:
                           if msg.toType == 2:
                               group = cl.getGroup(to)
                               group.preventedJoinByTicket = False
                               cl.updateGroup(group)
                               invsend = 0
                               ticket = cl.reissueGroupTicket(to)
                               ki.acceptGroupInvitationByTicket(to,format(str(ticket)))
                               time.sleep(0.01)
                               kk.acceptGroupInvitationByTicket(to,format(str(ticket)))
                               time.sleep(0.01)
                               kc.acceptGroupInvitationByTicket(to,format(str(ticket)))
                               time.sleep(0.01)
                               km.acceptGroupInvitationByTicket(to,format(str(ticket)))
                               time.sleep(0.01)
                               kb.acceptGroupInvitationByTicket(to,format(str(ticket)))
                               time.sleep(0.01)
                               
                        elif cmd.startswith(".saudio "):
                          if msg._from in admin:
                                    try:
                                    	sep = msg.text.split(" ")
                                    	dancoeg = msg.text.replace(sep[0] + " ","")
                                    	r = requests.get("https://api.eater.pw/smule?link={}".format(dancoeg))
                                    	data = r.text
                                    	data = json.loads(data)
                                    	cl.sendImageWithURL(to, str(data["result"][0]["thumb"]))
                                    	cl.sendAudioWithURL(to, str(data["result"][0]["video"]))
                                    except:
                                    	cl.sendMention(to, sender, "「", "」\nWaiting")
                                    	cl.sendAudioWithURL(to, str(data["result"][0]["video"]))
                                    
                        elif cmd.startswith(".carismule "):
                          if msg._from in admin:
                            cl.sendMessage(to, "Waiting...")
                            sep = text.split(" ")
                            search = text.replace(sep[0] + " ","")
                            params = {"search_query": search}
                            with requests.session() as web:
                                web.headers["User-Agent"] = random.choice(settings["userAgent"])
                                r = web.get("https://www.smule.com/results", params = params)
                                soup = BeautifulSoup(r.content, "html5lib")
                                ret_ = "╭━━━━━[ list smule di tampilkan ]━"
                                datas = []
                                for data in soup.select(".yt-lockup-title > a[title]"):
                                    if "&lists" not in data["href"]:
                                        datas.append(data)
                                for data in datas:
                                    ret_ += "\n┣[ {} ]".format(str(data["title"]))
                                    ret_ += "\n┣━ https://www.smule.com{}".format(str(data["href"]))
                                ret_ += "\n╰━━━━━━━━[ Total {} id]━━━━━".format(len(datas))
                                cl.sendMessage(to, str(ret_))
                                
                        elif cmd.startswith(".fb "):
                          if msg._from in admin:
                            cl.sendReplyMessage(msg.id, to, "Waiting...")
                            sep = text.split(" ")
                            facebook = text.replace(sep[0] + " ","")
                            with requests.session() as web:
                                web.headers["user-agent"] = random.choice(settings["userAgent"])
                                html = web.get("https://www.facebook.com/" + facebook + "/")
                                soup = BeautifulSoup(html.text, 'html5lib')
                                data = soup.find_all('meta', attrs={'property':'og:description'})
                                text = data[0].get('content').split()
                                data1 = soup.find_all('meta', attrs={'property':'og:image'})
                                text1 = data1[0].get('content').split()
                                user = "Name: " + text[-2] + "\n"
                                user1 = "Username: " + text[-1] + "\n"
                                followers = "Followers: " + text[0] + "\n"
                                following = "Following: " + text[2] + "\n"
                                post = "Post: " + text[4] + "\n"
                                link = "Link: " + "https://facebook.com/" + facebook
                                cl.sendImageWithURL(msg.to, text1[0])
                                cl.sendMessage(to, user + user1 + followers + following + post + link)
                                    
                        elif cmd.startswith(".psmule "):
                          if msg._from in admin:    
                            try:
                                separate = msg.text.split(" ")
                                smule = msg.text.replace(separate[0] + " ","")
                                links = ("https://smule.com/"+smule)
                                ss = ("http://api2.ntcorp.us/screenshot/shot?url={}".format(urllib.parse.quote(links)))
                                cl.sendMessage(msg.to, "Sedang Mencari...")
                                time.sleep(2)
                                cl.sendMessage(to, "ID Smule : "+smule+"\nLink : "+links)
                                cl.sendImageWithURL(msg.to, ss)
                            except Exception as error:
                                pass
                                
                        elif cmd.startswith(".apk "):
                          if msg._from in admin:
                            sep = msg.text.split(" ")
                            query = msg.text.replace(sep[0] + " ","")
                            cond = query.split("|")
                            search = str(cond[0])
                            with requests.session() as s:
                                s.headers['user-agent'] = random.choice(settings["userAgent"])
                                r = s.get("https://apkpure.com/id/search?q={}".format(str(search)))
                                soup = BeautifulSoup(r.content, 'html5lib')
                                data = soup.findAll('dl', attrs={'class':'search-dl'})
                                if len(cond) == 1:
                                    num = 0
                                    ret_ = "Pencarian Aplikasi\n"
                                    for apk in data:
                                        num += 1
                                        link = "https://apkpure.com"+apk.find('a')['href']
                                        title = apk.find('a')['title']
                                        ret_ += "\n {}. {}".format(str(num), str(title))
                                    ret_ += "\n\n Total {} Result".format(str(len(data)))
                                    ret = "Selanjutnya ketik:\n.apk {} | angka".format(str(search))
                                    cl.sendReplyMessage(msg.id, to, str(ret_))
                                    cl.sendReplyMessage(msg.id, to, str(ret))
                                elif len(cond) == 2:
                                    num = int(cond[1])
                                    if num <= len(data):
                                        apk = data[num - 1]
                                        with requests.session() as s:
                                            s.headers['user-agent'] = random.choice(settings["userAgent"])
                                            r = s.get("https://apkpure.com{}/download?from=details".format(str(apk.find('a')['href'])))
                                            soup = BeautifulSoup(r.content, 'html5lib')
                                            data = soup.findAll('div', attrs={'class':'fast-download-box'})
                                            for down in data:
                                                load = down.select("a[href*=https://download.apkpure.com/]")[0]
                                                file = load['href']
                                                ret_ = "File info :\n"+down.find('span', attrs={'class':'file'}).text
                                                with requests.session() as web:
                                                    web.headers["user-agent"] = "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
                                                    r = web.get("https://api-ssl.bitly.com/v3/shorten?access_token=497e74afd44780116ed281ea35c7317285694bf1&longUrl={}".format(urllib.parse.quote(file)))
                                                    data = r.text
                                                    data = json.loads(data)
                                                    ret_ += "\nLink Download :\n"+data["data"]["url"]
                                              #  cl.sendMessage(to, str(ret_))
                                                cl.sendReplyMessage(msg.id, to, str(ret_))
                                                
                        elif cmd == ".buka":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   X = cl.getGroup(msg.to)
                                   X.preventedJoinByTicket = False
                                   cl.updateGroup(X)
                                #30   cl.sendMessage(msg.to, "Udah di buka sayang...!")
                                   cl.sendReplyMessage(msg.id, to,"ᴜᴅᴀʜ ᴅɪ ʙᴜᴋᴀ sᴀʏᴀɴɢ..!")
                               
                        elif cmd == ".woy":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               ki.sendMessage(msg.to, "𝖬.𝖡.𝖪 𝖡𝖮𝖳𝖲 𝖳𝖧𝖤𝖠")
                               kk.sendMessage(msg.to, "𝖬.𝖡.𝖪 𝖡𝖮𝖳𝖲 𝖳𝖧𝖤𝖠")
                               kc.sendMessage(msg.to, "𝖬.𝖡.𝖪 𝖡𝖮𝖳𝖲 𝖳𝖧𝖤𝖠")
                               km.sendMessage(msg.to, "𝖬.𝖡.𝖪 𝖡𝖮𝖳𝖲 𝖳𝖧𝖤𝖠")
                               kb.sendMessage(msg.to, "𝖬.𝖡.𝖪 𝖡𝖮𝖳𝖲 𝖳𝖧𝖤𝖠")
                 
                        elif cmd == ".pamit":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                G = cl.getGroup(msg.to)
                                cl.sendReplyMessage(msg.id, to, "Gw balik yah,Assalamualaiqum "+str(G.name))
                                cl.leaveGroup(msg.to)
                                
                        elif cmd == ",cink":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                G = cl.getGroup(msg.to)
                               # kk.sendMessage(msg.to, "Pulang dulu "+str(G.name))
                                sw.leaveGroup(msg.to)
                                
                        elif cmd == ".cink":
                          if msg._from in admin:
                           if msg.toType == 2:
                               group = cl.getGroup(to)
                               group.preventedJoinByTicket = False
                               cl.updateGroup(group)
                               invsend = 0
                               ticket = cl.reissueGroupTicket(to)
                               sw.acceptGroupInvitationByTicket(to,format(str(ticket)))
                               time.sleep(0.01)
                          

                        elif cmd == ".bye":
                          if wait["selfbot"] == True:
                            if msg._from in owner or msg._from in admin:
                                G = cl.getGroup(msg.to)
                                ki.sendMessage(msg.to, "Makasih sudah invit\nketemu lain waktu... "+str(G.name))
                                ki.leaveGroup(msg.to)
                                
                        elif cmd == ".pulang":
                           if wait["selfbot"] == True:
                            if msg._from in admin:
                               G = cl.getGroup(msg.to)
                               cl.sendReplyMessage(msg.id, to, "Gw Balikin anak dulu "+str(G.name))
                               ki.leaveGroup(msg.to)
                               kk.leaveGroup(msg.to)
                               kc.leaveGroup(msg.to)
                               km.leaveGroup(msg.to)
                               kb.leaveGroup(msg.to)
                               

                        elif cmd.startswith("leave "):
                            if msg._from in admin or msg._from in owner:
                                proses = text.split(" ")
                                ng = text.replace(proses[0] + " ","")
                                gid = cl.getGroupIdsJoined()
                                for i in gid:
                                    h = cl.getGroup(i).name
                                    if h == ng:
                                        cl.sendMessage(i, " Silahkan invite Ownernya ")
                                        cl.leaveGroup(i)
                                        cl.sendMessage(to,"Succes leave group " +h)

                        elif cmd == ".sprespon":
                          if wait["selfbot"] == True:
                            if msg._from in owner or msg._from in admin or msg._from in staff:
                                get_profile_time_start = time.time()
                                get_profile = cl.getProfile()
                                get_profile_time = time.time() - get_profile_time_start
                                get_group_time_start = time.time()
                                get_group = cl.getGroupIdsJoined()
                                get_group_time = time.time() - get_group_time_start
                                get_contact_time_start = time.time()
                                get_contact = cl.getContact(mid)
                                get_contact_time = time.time() - get_contact_time_start
                               # cl.sendMessage(msg.to, "⚜Time Respon⚜\n\n ●Get Profile\n   %.10f\n ●Get Contact\n   %.10f\n ●Get Group\n   %.10f" % (get_profile_time/3,get_contact_time/3,get_group_time/3))
                                cl.sendReplyMessage(msg.id, to, "⚜ ᴍ.ʙ.ᴋ sᴘᴇᴇᴅ ʀᴇsᴘᴏɴ\n\n ⚜ ɢᴇᴛ ᴘʀᴏғɪʟ\n   %.10f\n ⚜ ɢᴇᴛ ᴄᴏɴᴛᴀᴄᴛ\n   %.10f\n ⚜ ɢᴇᴛ ɢʀᴜᴘ\n   %.10f" % (get_profile_time/3,get_contact_time/3,get_group_time/3))

                        elif cmd == ".speed" or cmd == ".sp":
                          if wait["selfbot"] == True:
                            if msg._from in owner or msg._from in admin:
                               start = time.time()                               
                               cl.sendMessage(msg.to, "lemah")                               
                               elapsed_time = time.time() - start
                           #    cl.sendMessage(msg.to, "{}".format(str(elapsed_time)))
                               cl.sendReplyMessage(msg.id, to, "{}".format(str(elapsed_time)))
                               
                        elif cmd == "lurk:on":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                 tz = pytz.timezone("Asia/Jakarta")
                                 timeNow = datetime.now(tz=tz)
                                 Setmain['RAreadPoint'][msg.to] = msg_id
                                 Setmain['RAreadMember'][msg.to] = {}
                                 cl.sendMessage(msg.to, "Lurking berhasil diaktifkan\n\nTanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nJam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]")
                            
                        elif cmd == "lurk:off":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                 tz = pytz.timezone("Asia/Jakarta")
                                 timeNow = datetime.now(tz=tz)
                                 del Setmain['RAreadPoint'][msg.to]
                                 del Setmain['RAreadMember'][msg.to]
                                 cl.sendMessage(msg.to, "Lurking berhasil dinoaktifkan\n\nTanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nJam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]")
                            
                        elif cmd == "lurkers":
                          if msg._from in admin:
                            if msg.to in Setmain['RAreadPoint']:
                                if Setmain['RAreadMember'][msg.to] != {}:
                                    aa = []
                                    for x in Setmain['RAreadMember'][msg.to]:
                                        aa.append(x)
                                    try:
                                        arrData = ""
                                        textx = "  [ Result {} member ]    \n\n  [ Lurkers ]\n1. ".format(str(len(aa)))
                                        arr = []
                                        no = 1
                                        b = 1
                                        for i in aa:
                                            b = b + 1
                                            end = "\n"
                                            mention = "@x\n"
                                            slen = str(len(textx))
                                            elen = str(len(textx) + len(mention) - 1)
                                            arrData = {'S':slen, 'E':elen, 'M':i}
                                            arr.append(arrData)
                                            tz = pytz.timezone("Asia/Jakarta")
                                            timeNow = datetime.now(tz=tz)
                                            textx += mention
                                            if no < len(aa):
                                                no += 1
                                                textx += str(b) + ". "
                                            else:
                                                try:
                                                    no = "[ {} ]".format(str(cl.getGroup(msg.to).name))
                                                except:
                                                    no = "  "
                                        msg.to = msg.to
                                        msg.text = textx+"\nTanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nJam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]"
                                        msg.contentMetadata = {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}
                                        msg.contentType = 0
                                        cl.sendMessage1(msg)
                                    except:
                                        pass
                                    try:
                                        del Setmain['RAreadPoint'][msg.to]
                                        del Setmain['RAreadMember'][msg.to]
                                    except:
                                        pass
                                    Setmain['RAreadPoint'][msg.to] = msg.id
                                    Setmain['RAreadMember'][msg.to] = {}
                                else:
                                    cl.sendMessage(msg.to, "User kosong...")
                            else:
                                cl.sendMessage(msg.to, "Ketik lurking on dulu")

                        elif cmd == ".sider on":
                          if wait["selfbot"] == True:
                           if msg._from in owner or msg._from in admin or msg._from in staff:
                              try:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                #  cl.sendMessage(msg.to, "Cek sider diaktifkan\n\nDate "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nTime  "+ datetime.strftime(timeNow,'%H:%M:%S')+" ")
                                  cl.sendReplyMessage(msg.id, to, "Cek sider diaktifkan\n\nDate "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nTime  "+ datetime.strftime(timeNow,'%H:%M:%S'), contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName),"MSG_SENDER_ICON": "http://dl.profile.line-cdn.net/{}".format(cl.getContact(sender).pictureStatus)}, contentType=0)
                                  del cctv['point'][msg.to]
                                  del cctv['sidermem'][msg.to]
                                  del cctv['cyduk'][msg.to]
                              except:
                                  pass
                              cctv['point'][msg.to] = msg.id
                              cctv['sidermem'][msg.to] = ""
                              cctv['cyduk'][msg.to]=True

                        elif cmd == ".sider off":
                          if wait["selfbot"] == True:
                           if msg._from in owner or msg._from in admin or msg._from in staff:
                              if msg.to in cctv['point']:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  cctv['cyduk'][msg.to]=False
                                #  cl.sendMessage(msg.to, "Cek sider dinonaktifkan\n\nDate "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nTime  "+ datetime.strftime(timeNow,'%H:%M:%S')+" ")
                                  cl.sendReplyMessage(msg.id, to, "Cek sider dinonaktifkan\n\nDate "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nTime  "+ datetime.strftime(timeNow,'%H:%M:%S'), contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName),"MSG_SENDER_ICON": "http://dl.profile.line-cdn.net/{}".format(cl.getContact(sender).pictureStatus)}, contentType=0)
                              else:
                               #   cl.sendMessage(msg.to, "Sudak tidak aktif")
                                  cl.sendReplyMessage(msg.id, to, "Sudak tidak aktif", contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName),"MSG_SENDER_ICON": "http://dl.profile.line-cdn.net/{}".format(cl.getContact(sender).pictureStatus)}, contentType=0)

#===========add img============#
                        elif cmd == ".cvp":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                settings["ChangeVideoProfilevid"][msg._from] = True
                                cl.sendReplyMessage(msg.id, to,"𝐒𝐞𝐧𝐝 𝐕𝐢𝐝𝐞𝐨𝐧𝐲𝐚...")
                                
                        elif cmd.startswith(".addpoto "):
                                sep = text.split(" ")
                                name = text.replace(sep[0] + " ","")
                                name = name.lower()
                                if name not in images:
                                    settings["Addimage"]["status"] = True
                                    settings["Addimage"]["name"] = str(name.lower())
                                    images[str(name.lower())] = ""
                                    f = codecs.open("image.json","w","utf-8")
                                    json.dump(images, f, sort_keys=True, indent=4, ensure_ascii=False)
                                    cl.sendReplyMessage(msg.id, to, "𝐒𝐢𝐥𝐚𝐡𝐤𝐚𝐧 𝐤𝐢𝐫𝐢𝐦 𝐟𝐨𝐭𝐨𝐧𝐲𝐚...")
                                else:
                                    cl.sendReplyMessage(msg.id, to, "𝐅𝐨𝐭𝐨 𝐢𝐭𝐮 𝐬𝐮𝐝𝐚𝐡 𝐝𝐚𝐥𝐚𝐦 𝐥𝐢𝐬𝐭")
                        elif cmd.startswith(".dellpoto "):
                               sep = text.split(" ")
                               name = text.replace(sep[0] + " ","")
                               name = name.lower()
                               if name in images:
                                   cl.deleteFile(images[str(name.lower())])
                                   del images[str(name.lower())]
                                   f = codecs.open("image.json","w","utf-8")
                                   json.dump(images, f, sort_keys=True, indent=4, ensure_ascii=False)
                                   cl.sendReplyMessage(msg.id, to, "𝐁𝐞𝐫𝐡𝐚𝐬𝐢𝐥 𝐦𝐞𝐧𝐠𝐡𝐚𝐩𝐮𝐬 {}".format( str(name.lower())))
                               else:
                                   cl.sendReplyMessage(msg.id, to, "𝐅𝐨𝐭𝐨 𝐢𝐭𝐮 𝐭𝐢𝐝𝐚𝐤 𝐚𝐝𝐚 𝐝𝐚𝐥𝐚𝐦 𝐥𝐢𝐬𝐭")

                        elif cmd == ".lpoto":
                                no = 0
                                ret_ = "𝐃𝐀𝐅𝐓𝐀𝐑 𝐏𝐎𝐓𝐎\n\n"
                                for image in images:
                                    no += 1
                                    ret_ += str(no) + ". " + image.title() + "\n"
                                ret_ += "\n𝐓𝐎𝐓𝐀𝐋 {} 𝐏𝐎𝐓𝐎".format(str(len(images)))
                                cl.sendReplyMessage(msg.id, to, ret_)
#==============add video==========================================================================
                        elif cmd.startswith(".addvidio "):
                                sep = text.split(" ")
                                name = text.replace(sep[0] + " ","")
                                name = name.lower()
                                if name not in images:
                                    settings["Addvideo"]["status"] = True
                                    settings["Addvideo"]["name"] = str(name.lower())
                                    images[str(name.lower())] = ""
                                    f = codecs.open("video.json","w","utf-8")
                                    json.dump(images, f, sort_keys=True, indent=4, ensure_ascii=False)
                                    cl.sendReplyMessage(msg.id, to, "𝐒𝐢𝐥𝐚𝐡𝐤𝐚𝐧 𝐤𝐢𝐫𝐢𝐦 𝐯𝐢𝐝𝐞𝐨 𝐧𝐲𝐚...")
                                else:
                                    cl.sendReplyMessage(msg.id, to, "𝐯𝐢𝐝𝐞𝐨 𝐢𝐭𝐮 𝐬𝐮𝐝𝐚𝐡 𝐝𝐚𝐥𝐚𝐦 𝐥𝐢𝐬𝐭")
                        elif cmd.startswith(".dellvidio "):
                               sep = text.split(" ")
                               name = text.replace(sep[0] + " ","")
                               name = name.lower()
                               if name in images:
                                   cl.deleteFile(images[str(name.lower())])
                                   del images[str(name.lower())]
                                   f = codecs.open("video.json","w","utf-8")
                                   json.dump(images, f, sort_keys=True, indent=4, ensure_ascii=False)
                                   cl.sendReplyMessage(msg.id, to, "𝐁𝐞𝐫𝐡𝐚𝐬𝐢𝐥 𝐦𝐞𝐧𝐠𝐡𝐚𝐩𝐮𝐬 {}".format( str(name.lower())))
                               else:
                                   cl.sendReplyMessage(msg.id, to, "𝐯𝐢𝐝𝐞𝐨 𝐢𝐭𝐮 𝐭𝐢𝐝𝐚𝐤 𝐚𝐝𝐚 𝐝𝐚𝐥𝐚𝐦 𝐥𝐢𝐬𝐭")

                        elif cmd == ".lvidio":
                                no = 0
                                ret_ = "𝐃𝐀𝐅𝐓𝐀𝐑 𝐕𝐈𝐃𝐈𝐎\n\n"
                                for image in images:
                                    no += 1
                                    ret_ += str(no) + ". " + image.title() + "\n"
                                ret_ += "\n𝐓𝐎𝐓𝐀𝐋 {} 𝐕𝐈𝐃𝐈𝐎".format(str(len(images)))
                                cl.sendReplyMessage(msg.id, to, ret_)
#=========== [ Add Audio] ============#
                        elif cmd.startswith(".addmp3 "):
                                sep = text.split(" ")
                                name = text.replace(sep[0] + " ","")
                                name = name.lower()
                                if name not in audios:
                                    settings["Addaudio"]["status"] = True
                                    settings["Addaudio"]["name"] = str(name.lower())
                                    audios[str(name.lower())] = ""
                                    f = codecs.open("audio.json","w","utf-8")
                                    json.dump(audios, f, sort_keys=True, indent=4, ensure_ascii=False)
                                    cl.sendReplyMessage(msg.id, to, "𝐒𝐢𝐥𝐚𝐡𝐤𝐚𝐧 𝐤𝐢𝐫𝐢𝐦 𝐦𝐩3⃣ 𝐧𝐲𝐚...") 
                                else:
                                    cl.sendReplyMessage(msg.id, to, "𝐌𝐩3⃣ 𝐢𝐭𝐮 𝐬𝐮𝐝𝐚𝐡 𝐝𝐚𝐥𝐚𝐦 𝐥𝐢𝐬𝐭") 
                                
                        elif cmd.startswith(".dellmp3 "):
                                sep = text.split(" ")
                                name = text.replace(sep[0] + " ","")
                                name = name.lower()
                                if name in audios:
                                    cl.deleteFile(audios[str(name.lower())])
                                    del audios[str(name.lower())]
                                    f = codecs.open("audio.json","w","utf-8")
                                    json.dump(audios, f, sort_keys=True, indent=4, ensure_ascii=False)
                                    cl.sendReplyMessage(msg.id, to, "𝐁𝐞𝐫𝐡𝐚𝐬𝐢𝐥 𝐦𝐞𝐧𝐠𝐡𝐚𝐩𝐮𝐬 𝐦𝐩3⃣ {}".format( str(name.lower())))
                                else:
                                    cl.sendReplyMessage(msg.id, to, "𝐌𝐩3⃣ 𝐢𝐭𝐮 𝐭𝐢𝐝𝐚𝐤 𝐚𝐝𝐚 𝐝𝐚𝐥𝐚𝐦 𝐥𝐢𝐬𝐭") 
                                 
                        elif cmd == ".lmp3":
                                no = 0
                                ret_ = "𝐃𝐀𝐅𝐓𝐀𝐑 𝐌𝐏3⃣\n\n"
                                for audio in audios:
                                    no += 1
                                    ret_ += str(no) + ". " + audio.title() + "\n"
                                ret_ += "\n𝐓𝐎𝐓𝐀𝐋 {} 𝐌𝐏3⃣".format(str(len(audios)))
                                cl.sendReplyMessage(msg.id, to, ret_)
 #=========== [ Add sticker] ============#                   
                        elif cmd.startswith(".addtikel "):
                                sep = text.split(" ")
                                name = text.replace(sep[0] + " ","")
                                name = name.lower()
                                if name not in stickers:
                                    settings["Addsticker"]["status"] = True
                                    settings["Addsticker"]["name"] = str(name.lower())
                                    stickers[str(name.lower())] = ""
                                    f = codecs.open("sticker.json","w","utf-8")
                                    json.dump(stickers, f, sort_keys=True, indent=4, ensure_ascii=False)
                                    cl.sendReplyMessage(msg.id, to, "𝐒𝐢𝐥𝐚𝐡𝐤𝐚𝐧 𝐤𝐢𝐫𝐢𝐦 𝐬𝐭𝐢𝐜𝐤𝐞𝐫𝐧𝐲𝐚...") 
                                else:
                                    cl.sendReplyMessage(msg.id, to, "𝐒𝐭𝐢𝐜𝐤𝐞𝐫 𝐢𝐭𝐮 𝐬𝐮𝐝𝐚𝐡 𝐝𝐚𝐥𝐚𝐦 𝐥𝐢𝐬𝐭") 
                                
                        elif cmd.startswith(".delltikel "):
                                sep = text.split(" ")
                                name = text.replace(sep[0] + " ","")
                                name = name.lower()
                                if name in stickers:
                                    del stickers[str(name.lower())]
                                    f = codecs.open("sticker.json","w","utf-8")
                                    json.dump(stickers, f, sort_keys=True, indent=4, ensure_ascii=False)
                                    cl.sendReplyMessage(msg.id, to, "𝐁𝐞𝐫𝐡𝐚𝐬𝐢𝐥 𝐦𝐞𝐧𝐠𝐡𝐚𝐩𝐮𝐬 𝐬𝐭𝐢𝐜𝐤𝐞𝐫 {}".format( str(name.lower())))
                                else:
                                    cl.sendReplyMessage(msg.id, to, "𝐒𝐭𝐢𝐜𝐤𝐞𝐫 𝐢𝐭𝐮 𝐭𝐢𝐝𝐚𝐤 𝐚𝐝𝐚 𝐝𝐚𝐥𝐚𝐦 𝐥𝐢𝐬𝐭") 
                                                   
                        elif cmd == ".ltikel":
                                no = 0
                                ret_ = " 𝐃𝐀𝐅𝐓𝐀𝐑 𝐓𝐈𝐊𝐄𝐋 \n\n"
                                for sticker in stickers:
                                    no += 1
                                    ret_ += str(no) + ". " + sticker.title() + "\n"
                                ret_ += "\n𝐓𝐎𝐓𝐀𝐋 {} 𝐓𝐈𝐊𝐄𝐋".format(str(len(stickers)))
                                cl.sendReplyMessage(msg.id, to, ret_)
#=========== [ Hiburan] ============#                        
                        elif text.lower().startswith("!music "):
                            try:
                                search = text.lower().replace("!music ","")
                                r = requests.get("https://rest.farzain.com/api/joox.php?apikey=rambu&id={}".format(urllib.parse.quote(search)))
                                data = r.text
                                data = json.loads(data)
                                info = data["info"]
                                audio = data["audio"]
                                hasil = "「 Hasil Musik 」\n"
                                hasil += "\nPenyanyi : {}".format(str(info["penyanyi"]))
                                hasil += "\nJudul : {}".format(str(info["judul"]))
                                hasil += "\nAlbum : {}".format(str(info["album"]))
                                hasil += "\n\nLink : \n1. Image : {}".format(str(data["gambar"]))
                                hasil += "\n\nLink : \n2. MP3 : {}".format(str(audio["mp3"]))
                                cl.sendImageWithURL(msg.to, str(data["gambar"]))
                                cl.sendMessage(msg.to, str(hasil))
                                cl.sendAudioWithURL(msg.to, str(audio["mp3"]))
                                cl.sendMessage(msg.to, "Searching mp3 done..")
                            except Exception as error:
                            	cl.sendMessage(msg.to, "「 Result Error 」\n" + str(error))
                            
                        elif cmd.startswith("musik: "):
                           if msg._from in admin:
                              sep = msg.text.split(" ")
                              search = msg.text.replace(sep[0] + " ","")
                              params = {'songname': search}
                              with requests.session() as web:
                                  web.headers["User-Agent"] = random.choice(settings["userAgent"])
                                  r = web.get("https://rest.farzain.com/api/joox.php?apikey=rambu&id={}".format(urllib.parse.urlencode(params)))
                                  try:
                                      data = json.loads(r.text)
                                      for song in data:
                                          ret_ = "╔══[ Music ]"
                                          ret_ += "\n╠ Nama lagu : {}".format(str(song[0]))
                                          ret_ += "\n╠ Durasi : {}".format(str(song[1]))
                                          ret_ += "\n╠ Link : {}".format(str(song[3]))
                                          ret_ += "\n╚══[ Waiting Audio ]"
                                      cl.sendMessage(msg.to, str(ret_))
                                      cl.sendMessage(msg.to, "Mohon bersabar musicnya lagi di upload")
                                      cl.sendAudioWithURL(msg.to, song[3])
                                  except:
                                      cl.sendMessage(to, "Musik tidak ditemukan")                      

                        elif cmd.startswith(".vidio "):
                          if msg._from in owner or msg._from in admin or msg._from in staff:
                            try:
                                sep = msg.text.split(" ")
                                textToSearch = msg.text.replace(sep[0] + " ","")
                                query = urllib.parse.quote(textToSearch)
                                search_url="https://www.youtube.com/results?search_query="
                                mozhdr = {'User-Agent': 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'}
                                sb_url = search_url + query
                                sb_get = requests.get(sb_url, headers = mozhdr)
                                soupeddata = BeautifulSoup(sb_get.content, "html.parser")
                                yt_links = soupeddata.find_all("a", class_ = "yt-uix-tile-link")
                                x = (yt_links[1])
                                yt_href =  x.get("href")
                                yt_href = yt_href.replace("watch?v=", "")
                                qx = "https://youtu.be" + str(yt_href)
                                vid = pafy.new(qx)
                                stream = vid.streams
                                best = vid.getbest()
                                best.resolution, best.extension
                                for s in stream:
                                    me = best.url
                                    hasil = ""
                                    title = "Judul [ " + vid.title + " ]"
                                    author = '\n\nAuthor : ' + str(vid.author)
                                    durasi = '\nDuration : ' + str(vid.duration)
                                    suka = '\nLikes : ' + str(vid.likes)
                                    rating = '\nRating : ' + str(vid.rating)
                                    deskripsi = '\nDeskripsi : ' + str(vid.description)
                                cl.sendVideoWithURL(msg.to, me)
                              #  cl.sendReplyMessage(msg.id, to,title+ author+ durasi+ suka+ rating+ deskripsi)
                            except Exception as e:
                                cl.sendReplyMessage(msg.id, to,str(e))
                        
                        elif cmd.startswith(".lahir "):
                          if msg._from in admin:
                            sep = msg.text.split(" ")
                            tanggal = msg.text.replace(sep[0] + " ","")
                            r=requests.get('https://script.google.com/macros/exec?service=AKfycbw7gKzP-WYV2F5mc9RaR7yE3Ve1yN91Tjs91hp_jHSE02dSv9w&nama=ervan&tanggal='+tanggal)
                            data=r.text
                            data=json.loads(data)
                            lahir = data["data"]["lahir"]
                            usia = data["data"]["usia"]
                            ultah = data["data"]["ultah"]
                            zodiak = data["data"]["zodiak"]
                            cl.sendReplyMessage(msg.id, to,"Informasi™\n\n"+"Date Of Birth : "+lahir+"\nAge : "+usia+"\nUltah : "+ultah+"\nZodiak : "+zodiak)

                        elif cmd.startswith(".clone "):
                           if msg._from in admin:
                             if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                for mention in mentionees:
                                    contact = mention["M"]
                                    break
                                try:
                                    cl.cloneContactProfile(contact)
                                    ryan = cl.getContact(contact)
                                    zx = ""
                                    zxc = ""
                                    zx2 = []
                                    xpesan =  "「 Clone Profile 」\nTarget nya "
                                    ret_ = "Berhasil clone profile target"
                                    ry = str(ryan.displayName)
                                    pesan = ''
                                    pesan2 = pesan+"@x \n"
                                    xlen = str(len(zxc)+len(xpesan))
                                    xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                    zx = {'S':xlen, 'E':xlen2, 'M':ryan.mid}
                                    zx2.append(zx)
                                    zxc += pesan2
                                    text = xpesan + zxc + ret_ + ""
                                    cl.sendReplyMessage(msg.id, to, text, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)
                                except:
                                    cl.sendReplyMessage(msg.id, to, "Gagal clone profile")
                            
                        elif text.lower() == 'restore':
                           if msg._from in admin:
                              try:
                                  lineProfile.displayName = str(myProfile["displayName"])
                                  lineProfile.statusMessage = str(myProfile["statusMessage"])
                                  lineProfile.pictureStatus = str(myProfile["pictureStatus"])
                                  cl.updateProfileAttribute(8, lineProfile.pictureStatus)
                                  cl.updateProfile(lineProfile)
                                  sendMention(msg.to, sender, "「 Restore Profile 」\nNama ", " \nBerhasil restore profile")
                              except:
                                  cl.sendReplyMessage(msg.id, to, "Gagal restore profile")

                        elif cmd.startswith(".jumlah: "):
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                                proses = text.split(":")
                                strnum = text.replace(proses[0] + ":","")
                                num =  int(strnum)
                                wait["RAlimit"] = num
                                cl.sendReplyMessage(msg.id, to,"Spamtag change to " +strnum)

                        elif cmd.startswith(".scall: "):
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                                proses = text.split(":")
                                strnum = text.replace(proses[0] + ":","")
                                num =  int(strnum)
                                wait["limit"] = num
                                cl.sendReplyMessage(msg.id, to,"ᴛᴏᴛᴀʟ ᴜɴᴅᴀɴɢᴀɴ ᴅɪ ᴜʙᴀʜ ᴍᴇɴᴊᴀᴅɪ " +strnum)

                        elif cmd.startswith(".spamtag "):
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                                if 'MENTION' in msg.contentMetadata.keys()!=None:
                                    key = eval(msg.contentMetadata["MENTION"])
                                    key1 = key["MENTIONEES"][0]["M"]
                                    zx = ""
                                    zxc = " "
                                    zx2 = []
                                    pesan2 = "@a"" "
                                    xlen = str(len(zxc))
                                    xlen2 = str(len(zxc)+len(pesan2)-1)
                                    zx = {'S':xlen, 'E':xlen2, 'M':key1}
                                    zx2.append(zx)
                                    zxc += pesan2
                                    msg.contentType = 0
                                    msg.text = zxc
                                    lol = {'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}
                                    msg.contentMetadata = lol
                                    jmlh = int(wait["RAlimit"])
                                    if jmlh <= 1000:
                                        for x in range(jmlh):
                                            try:
                                                cl.sendMessage(msg)
                                            except Exception as e:
                                                cl.sendMessage(msg.to,str(e))
                                    else:
                                        cl.sendMessage(msg.to,"Jumlah melebihi 1000")
                                        
                        elif cmd.startswith(".spamtag "):
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                                if 'MENTION' in msg.contentMetadata.keys()!=None:
                                    key = eval(msg.contentMetadata["MENTION"])
                                    key1 = key["MENTIONEES"][0]["M"]
                                    zx = ""
                                    zxc = " "
                                    zx2 = []
                                    pesan2 = "@a"" "
                                    xlen = str(len(zxc))
                                    xlen2 = str(len(zxc)+len(pesan2)-1)
                                    zx = {'S':xlen, 'E':xlen2, 'M':key1}
                                    zx2.append(zx)
                                    zxc += pesan2
                                    msg.contentType = 0
                                    msg.text = zxc
                                    lol = {'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}
                                    msg.contentMetadata = lol
                                    jmlh = int(key1)
                                    if jmlh <= 1000:
                                        for x in range(jmlh):
                                            try:
                                                cl.sendMessage(msg)
                                            except Exception as e:
                                                cl.sendReplyMessage(msg.id, to,str(e))

                        elif cmd == "spamcall":
                          if wait["selfbot"] == True:
                           if msg._from in owner:
                             if msg.toType == 2:
                                group = cl.getGroup(to)
                                members = [mem.mid for mem in group.members]
                                cl.sendMessage(msg.to, "Berhasil mengundang {} undangan Call Grup".format(str(wait["limit"])))
                                call.acquireGroupCallRoute(to)
                                call.inviteIntoGroupCall(to, contactIds=members)
                                        
                        elif cmd == ".scall":
                          if wait["selfbot"] == True:
                           if msg._from in owner:
                             if msg.toType == 2:
                                group = cl.getGroup(to)
                                members = [mem.mid for mem in group.members]
                                jmlh = int(wait["limit"])
                               # cl.sendMessage(msg.to, "ʙᴇʀʜᴀsɪʟ ᴍᴇɴɢᴜɴᴅᴀɴɢ {} ᴜɴᴅᴀɴɢᴀɴ ᴄᴀʟʟ ɢʀᴜᴘ".format(str(wait["limit"])))
                                cl.sendReplyMessage(msg.id, to, "ʙᴇʀʜᴀsɪʟ ᴍᴇɴɢᴜɴᴅᴀɴɢ {} ᴜɴᴅᴀɴɢᴀɴ ᴄᴀʟʟ ɢʀᴜᴘ".format(str(wait["limit"])))
                                if jmlh <= 1000:
                                  for x in range(jmlh):
                                     try:
                                        call.acquireGroupCallRoute(to)
                                        call.inviteIntoGroupCall(to, contactIds=members)
                                     except Exception as e:
                                        cl.sendMessage(msg.to,str(e))
                                else:
                                    cl.sendMessage(msg.to,"ᴍᴇʟᴇʙɪʜɪ ʙᴀᴛᴀs ʙʀᴏ")
                                    
                        elif cmd.startswith("spaminvid"):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if 'MENTION' in msg.contentMetadata.keys()!=None:
                                    dan = text.split("|")
                                    userid = dan[1]
                                    namagrup = dan[2]
                                    jumlah = int(dan[3])
                                    grups = cl.groups
                                    tgb = cl.findContactsByUserid(userid)
                                    cl.findAndAddContactsByUserid(userid)
                                    if jumlah <= 1000:
                                        for var in range(0,jumlah):
                                            try:
                                                cl.createGroup(str(namagrup), [tgb.mid])
                                                for i in grups:
                                                	grup = cl.getGroup(i)
                                                	if grup.name == namagrup:
                                                	    cl.inviteIntoGroup(grup.id, [tgb.mid])
                                                	    cl.leaveGroup(grup.id)
                                                	    cl.sendText(to,"@! sukses spam grup!\n\nkorban: @!\njumlah: {}\nnama grup: {}".format(jumlah, str(namagrup)), [sender, tgb.mid])
                                            except Exception as e:
                                                cl.sendText(msg.to,str(e))

                        elif '.gift ' in msg.text:
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              korban = msg.text.replace('.gift ','')
                              korban2 = korban.split()
                              midd = korban2[0]
                              jumlah = int(korban2[1])
                              if jumlah <= 1000:
                                  for var in range(0,jumlah):
                                      cl.sendMessage(midd, None, contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58', 'PRDTYPE': 'THEME', 'MSGTPL': '6'}, contentType=9)

                        elif '.spam ' in msg.text:
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              korban = msg.text.replace('.spam ','')
                              korban2 = korban.split()
                              midd = korban2[0]
                              jumlah = int(korban2[1])
                              if jumlah <= 1000:
                                  for var in range(0,jumlah):
                                      cl.sendMessage(midd, str(Setmain["RAmessage1"]))

                        elif '.id ' in msg.text:
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              msgs = msg.text.replace('.id ','')
                              conn = cl.findContactsByUserid(msgs)
                              if True:
                                  cl.sendReplyMessage(msg.id, to, "http://line.me/ti/p/~" + msgs)
                                  cl.sendReplyMessage(msg.id, to, None, contentMetadata={'mid': conn.mid}, contentType=13)

#===========Protection============#
                        elif '.wc ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('.wc ','')
                              if spl == 'on':
                                  if msg.to in welcome:
                                       msgs = "ᴡᴇʟᴄᴏᴍᴇ ᴍᴇssᴀɢᴇ ᴀᴋᴛɪᴘᴋᴀɴ"
                                  else:
                                       welcome.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "ᴡᴇʟᴄᴏᴍᴇ ᴍᴇssᴀɢᴇ ᴅɪ ᴀᴋᴛɪᴘᴋᴀɴ ᴅɪ ɢʀᴜᴘ : " +str(ginfo.name)
                                 # cl.sendMessage(msg.to, "「Diaktifkan」\n" + msgs)
                                  cl.sendReplyMessage(msg.id, to, msgs, contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName).format(cl.getContact(sender).pictureStatus)}, contentType=0)
                              elif spl == 'off':
                                    if msg.to in welcome:
                                         welcome.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "ᴡᴇʟᴄᴏᴍᴇ ɴᴏɴ ᴀᴋᴛɪᴋᴀᴘᴋᴀɴ"
                                    else:
                                         msgs = "ᴡᴇʟᴄᴏᴍᴇ ᴍᴇssᴀɢᴇ ᴅɪ ɴᴏɴ ᴀᴋᴛɪᴋᴀᴘᴋᴀɴ ᴅɪ ɢʀᴜᴘ : " +str(ginfo.name)
                              #      cl.sendMessage(msg.to, "「Dinonaktifkan」\n" + msgs)
                                    cl.sendReplyMessage(msg.id, to, msgs, contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName).format(cl.getContact(sender).pictureStatus)}, contentType=0)

                        elif '.pqr ' in msg.text:
                           if msg._from in owner or msg._from in admin:
                              spl = msg.text.replace('.pqr ','')
                              if spl == 'on':
                                  if msg.to in protect["pqr"]:
                                       msgs = "ᴘʀᴏᴛᴇᴄᴛ ϙʀ sᴜᴅᴀʜ ᴀᴋᴛɪғ"
                                  else:
                                       protect["pqr"].append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "ᴘʀᴏᴛᴇᴄᴛ ϙʀ ᴅɪ ᴀᴋᴛɪғᴋᴀɴ ᴅɪ ɢʀᴜᴘ : " +str(ginfo.name)
                                  cl.sendReplyMessage(msg.id, to, msgs, contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName).format(cl.getContact(sender).pictureStatus)}, contentType=0)
                              elif spl == 'off':
                                    if msg.to in protect["pqr"]:
                                         protect["pqr"].remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "ᴘʀᴏᴛᴇᴄᴛ ϙʀ ᴅɪ ɴᴏɴ ᴀᴋᴛɪғᴋᴀɴ : " +str(ginfo.name)
                                    else:
                                         msgs = "ᴘʀᴏᴛᴇᴄᴛ ϙʀ sᴜᴅᴀʜ ᴛɪᴅᴀᴋ ᴀᴋᴛɪғ"
                                    cl.sendReplyMessage(msg.id, to, msgs, contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName).format(cl.getContact(sender).pictureStatus)}, contentType=0)

                        elif '.pro ' in msg.text:
                           if msg._from in owner or msg._from in admin:
                              spl = msg.text.replace('.pro ','')
                              if spl == 'on':
                                  if msg.to in protect["protect"]:
                                       msgs = "ᴘʀᴏᴛᴇᴄᴛ sᴜᴅᴀʜ ᴅɪ ᴀᴋᴛɪᴘᴋᴀɴ "
                                  else:
                                       protect["protect"].append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "ᴘʀᴏᴛᴇᴄᴛ ᴅɪ ᴀᴋᴛɪᴘᴋᴀɴ ᴅɪ ɢʀᴜᴘ : " +str(ginfo.name)
                                  cl.sendReplyMessage(msg.id, to, msgs, contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName).format(cl.getContact(sender).pictureStatus)}, contentType=0)
                              elif spl == 'off':
                                    if msg.to in protect["protect"]:
                                         protect["protect"].remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "ᴘʀᴏᴛᴇᴄᴛ ᴅɪ ɴᴏɴ ᴀᴋᴛɪᴘᴋᴀɴ ᴅɪ ɢʀᴜᴘ : " +str(ginfo.name)
                                    else:
                                         msgs = "ᴘʀᴏᴛᴇᴄᴛ sᴜᴅᴀʜ ᴅɪ ɴᴏɴ ᴀᴋᴛɪᴘᴋᴀɴ "
                                    cl.sendReplyMessage(msg.id, to, msgs, contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName).format(cl.getContact(sender).pictureStatus)}, contentType=0)

                        elif '.pinvite ' in msg.text:
                           if msg._from in owner or msg._from in admin:
                              spl = msg.text.replace('.pinvite ','')
                              if spl == 'on':
                                  if msg.to in protect["proall"]:
                                       msgs = "ᴘʀᴏᴛᴇᴄᴛ ɪɴᴠɪᴛᴇ sᴜᴅᴀʜ ᴀᴋᴛɪᴘᴋᴀɴ"
                                  else:
                                       protect["proall"].append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "ᴘʀᴏᴛᴇᴄᴛ ɪɴᴠɪᴛᴇ ᴅɪ ᴀᴋᴛɪᴘᴋᴀɴ ᴅɪ ɢʀᴜᴘ : " +str(ginfo.name)
                                  cl.sendReplyMessage(msg.id, to, msgs, contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName).format(cl.getContact(sender).pictureStatus)}, contentType=0)
                              elif spl == 'off':
                                    if msg.to in protect["proall"]:
                                         protect["proall"].remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "ᴘʀᴏᴛᴇᴄᴛ ɪɴᴠɪᴛᴇ ᴅɪ ɴᴏɴ ᴀᴋᴛɪᴘᴋᴀɴ ᴅɪ ɢʀᴜᴘ : " +str(ginfo.name)
                                    else:
                                         msgs = "ᴘʀᴏᴛᴇᴄᴛ ɪɴᴠɪᴛᴇ sᴜᴅᴀʜ ᴅɪ ɴᴏɴ ᴀᴋᴛɪᴘᴋᴀɴ"
                                    cl.sendReplyMessage(msg.id, to, msgs, contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName).format(cl.getContact(sender).pictureStatus)}, contentType=0)

                        elif '.pcancel ' in msg.text:
                           if msg._from in owner or msg._from in admin:
                              spl = msg.text.replace('.pcancel ','')
                              if spl == 'on':
                                  if msg.to in protectcancel:
                                       msgs = "ᴘʀᴏᴛᴇᴄᴛ ᴄᴀɴᴄᴇʟ sᴜᴅᴀʜ ᴀᴋᴛɪᴘ "
                                  else:
                                       protectcancel.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "ᴘʀᴏᴛᴇᴄᴛ ᴄᴀɴᴄᴇʟ ᴅɪ ᴀᴋᴛɪᴘᴋᴀɴ ᴅɪ ɢʀᴜᴘ : " +str(ginfo.name)
                                  cl.sendReplyMessage(msg.id, to, msgs, contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName).format(cl.getContact(sender).pictureStatus)}, contentType=0)
                              elif spl == 'off':
                                    if msg.to in protectcancel:
                                         protectcancel.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "ᴘʀᴏᴛᴇᴄᴛ ᴄᴀɴᴄᴇʟ ᴅɪ ɴᴏɴ ᴀᴋᴛɪᴘᴋᴀɴ ᴅɪ ɢʀᴜᴘ : " +str(ginfo.name)
                                    else:
                                         msgs = "ᴘʀᴏᴛᴇᴄᴛ ᴄᴀɴᴄᴇʟ sᴜᴅᴀʜ ᴅɪ ɴᴏɴ ᴀᴋᴛɪᴘᴋᴀɴ"
                                    cl.sendReplyMessage(msg.id, to, msgs, contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName).format(cl.getContact(sender).pictureStatus)}, contentType=0)

                        elif '.pkick ' in msg.text:
                           if msg._from in owner or msg._from in admin:
                              spl = msg.text.replace('.pkick ','')
                              if spl == 'on':
                                  if msg.to in protect["pinv"]:
                                       msgs = "ᴘʀᴏᴛᴇᴄᴛ ᴋɪᴄᴋ sᴜᴅᴀʜ ᴀᴋᴛɪᴘᴋᴀɴ"
                                  else:
                                       protect["pinv"].append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "ᴘʀᴏᴛᴇᴄᴛ ᴋɪᴄᴋ ᴅɪ ᴀᴋᴛɪᴘᴋᴀɴ ᴅɪ ɢʀᴜᴘ : " +str(ginfo.name)
                                  cl.sendReplyMessage(msg.id, to, msgs, contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName).format(cl.getContact(sender).pictureStatus)}, contentType=0)
                              elif spl == 'off':
                                    if msg.to in protect["pinv"]:
                                         protect["pinv"].remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "ᴘʀᴏᴛᴇᴄᴛ ᴋɪᴄᴋ ᴅɪ ɴᴏɴ ᴀᴋᴛɪᴘᴋᴀɴ ᴅɪ ɢʀᴜᴘ : " +str(ginfo.name)
                                    else:
                                         msgs = "ᴘʀᴏᴛᴇᴄᴛ ᴋɪᴄᴋ sᴜᴅᴀʜ ᴅɪ ɴᴏɴ ᴀᴋᴛɪᴘᴋᴀɴ"
                                    cl.sendReplyMessage(msg.id, to, msgs, contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName).format(cl.getContact(sender).pictureStatus)}, contentType=0)

                        elif '.siaga ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('.siaga ','')
                              if spl == 'on':
                                  if msg.to in protect["antijs"]:
                                       msgs = "ᴍᴏᴅᴇ sɪᴀɢᴀ sᴜᴅᴀʜ ᴀᴋᴛɪᴘ"
                                  else:
                                       protect["antijs"].append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "ᴍᴏᴅᴇ sɪᴀɢᴀ ᴅɪ ᴀᴋᴛɪᴘᴋᴀɴ ᴅɪ ɢʀᴜᴘ : " +str(ginfo.name)
                                  cl.sendReplyMessage(msg.id, to, msgs, contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName).format(cl.getContact(sender).pictureStatus)}, contentType=0)
                              elif spl == 'off':
                                    if msg.to in protect["antijs"]:
                                         protect["antijs"].remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "ᴍᴏᴅᴇ sɪᴀɢᴀ ᴅɪ ɴᴏɴᴀᴋᴛɪᴘᴋᴀɴ ᴅɪ ɢʀᴜᴘ : " +str(ginfo.name)
                                    else:
                                         msgs = "ᴍᴏᴅᴇ sɪᴀɢᴀ sᴜᴅᴀʜ ᴅɪ ɴᴏɴᴀᴋᴛɪᴘᴋᴀɴ "
                                    cl.sendReplyMessage(msg.id, to, msgs, contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName).format(cl.getContact(sender).pictureStatus)}, contentType=0)

                        elif '.allpro ' in msg.text:
                           if msg._from in owner or msg._from in admin:
                              spl = msg.text.replace('.allpro ','')
                              if spl == 'on':
                                  if msg.to in protect["pqr"]:
                                       msgs = ""
                                  else:
                                       protect["pqr"].append(msg.to)
                                  if msg.to in protect["protect"]:
                                      msgs = ""
                                  else:
                                      protect["protect"].append(msg.to)
                                  if msg.to in protect["pinv"]:
                                      msgs = ""
                                  else:
                                      protect["pinv"].append(msg.to)
                                  if msg.to in protect["antijs"]:
                                      msgs = ""
                                  else:
                                      protect["antijs"].append(msg.to)
                                  if msg.to in protect["proall"]:
                                      msgs = ""
                                  else:
                                      protect["proall"].append(msg.to)
                                  if msg.to in protectcancel:
                                      ginfo = cl.getGroup(msg.to)
                                      msgs = "ᴀʟʟᴘʀᴏ ᴀᴋᴛɪᴘ : " +str(ginfo.name)
                                  else:
                                      protectcancel.append(msg.to)
                                      ginfo = cl.getGroup(msg.to)
                                      msgs = "ᴀʟʟᴘʀᴏ ᴅɪ ᴀᴋᴛɪᴘᴋᴀɴ ᴅɪ ɢʀᴜᴘ: " +str(ginfo.name)
                                  cl.sendReplyMessage(msg.id, to, msgs, contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName).format(cl.getContact(sender).pictureStatus)}, contentType=0)
                              elif spl == 'off':
                                    if msg.to in protect["pqr"]:
                                         protect["pqr"].remove(msg.to)
                                    else:
                                         msgs = ""
                                    if msg.to in protect["protect"]:
                                         protect["protect"].remove(msg.to)
                                    else:
                                         msgs = ""
                                    if msg.to in protect["pinv"]:
                                         protect["pinv"].remove(msg.to)
                                    else:
                                         msgs = ""
                                    if msg.to in protect["antijs"]:
                                         protect["antijs"].remove(msg.to)
                                    else:
                                         msgs = ""
                                    if msg.to in protect["proall"]:
                                         protect["proall"].remove(msg.to)
                                    else:
                                         msgs = ""
                                    if msg.to in protectcancel:
                                         protectcancel.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "ᴀʟʟᴘʀᴏ  ɴᴏɴ ᴀᴋᴛɪᴘ : " +str(ginfo.name)
                                    else:
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "ᴀʟʟᴘʀᴏ ᴅɪ ɴᴏɴ ᴀᴋᴛɪᴘᴋᴀɴ ᴅɪ ɢʀᴜᴘ : " +str(ginfo.name)
                                    cl.sendReplyMessage(msg.id, to, msgs, contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName).format(cl.getContact(sender).pictureStatus)}, contentType=0)

#===========KICKOUT============#       
                        elif (".cipok " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Bots:
                                       try:
                                           random.choice(ABC).kickoutFromGroup(msg.to, [target])
                                       except:
                                           pass
                                           
                        elif (".culik " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Bots:
                                       try:
                                           G = cl.getGroup(msg.to)
                                           G.preventedJoinByTicket = False
                                           cl.updateGroup(G)
                                           invsend = 0
                                           Ticket = cl.reissueGroupTicket(msg.to)
                                           sw.acceptGroupInvitationByTicket(msg.to,Ticket)
                                           sw.kickoutFromGroup(msg.to, [target])
                                           sw.leaveGroup(msg.to)
                                           X = cl.getGroup(msg.to)
                                           X.preventedJoinByTicket = True
                                           cl.updateGroup(X)
                                       except:
                                           pass
                                           
                        elif (".sapu" in msg.text):
                            if msg._from in admin:
                             if msg.toType == 2:
                                 print ("[ 19 ] KICK ALL MEMBER")
                                 _name = msg.text.replace(".sapu","")
                                 gs = cl.getGroup(msg.to)
                                 gs = ki.getGroup(msg.to)
                                 gs = kk.getGroup(msg.to)
                                 gs = kc.getGroup(msg.to)
                                 gs = km.getGroup(msg.to)
                                 gs = kb.getGroup(msg.to)
                             #    cl.sendMessage(msg.to,"「 Papay Sayang 😚😚😚」")
                             #    cl.sendMessage(msg.to,"「 Sorry r̸o̸o̸m̸ n̸y̸a̸ k̸a̸m̸i̸ s̸i̸t̸a̸ s̸e̸e̸ y̸o̸u̸ s̸l̸a̸m̸ d̸a̸r̸i̸ TΣΔM SILΣΠT βΩT」")
                                 targets = []
                                 for g in gs.members:
                                     if _name in g.displayName:
                                         targets.append(g.mid)
                                 if targets == []:
                                     cl.sendMessage(msg.to,"Capek...!")
                                 else:
                                     for target in targets:
                                       if not target in Bots:
                                          if not target in admin:
                                             if not target in staff:
                                               try:
                                                   klis = [ki,kk,kc,km,kb]
                                                   kicker=random.choice(klist)
                                                   kicker.kickoutFromGroup(msg.to,[target])
                                                   print (msg.to,[g.mid])
                                               except:
                                                   pass

                        elif text.lower() == '.tiup':
                           if msg._from in owner or msg._from in admin or msg._from in staff:
                           	if msg.toType == 2:
                                  ginfo = cl.getGroup(msg.to)
                                #  cl.sendMessage(msg.to, "SUKSES TIUP MEMBER")
                                  cl.sendMessage(msg.to, "ᴍ.ʙ.ᴋ ʙᴏᴛ\nᴘᴇɴᴅᴜᴅᴜᴋ : " +str(len(ginfo.members)) + " \n.Emuachhhhhhhhhh😂🤣😅")
                                  G = cl.getGroup(msg.to)
                                  G.preventedJoinByTicket = False
                                  cl.updateGroup(G)
                                  Ticket = cl.reissueGroupTicket(msg.to)
                                  ki.acceptGroupInvitationByTicket(msg.to,Ticket)
                                  kk.acceptGroupInvitationByTicket(msg.to,Ticket)
                                  kc.acceptGroupInvitationByTicket(msg.to,Ticket)
                                  km.acceptGroupInvitationByTicket(msg.to,Ticket)
                                  kb.acceptGroupInvitationByTicket(msg.to,Ticket)
                                  sw.acceptGroupInvitationByTicket(msg.to,Ticket)
                                  _name = text.lower().replace('.tiup','')
                                  gs = ki.getGroup(msg.to)
                                  gs = kk.getGroup(msg.to)
                                  gs = kc.getGroup(msg.to)
                                  gs = km.getGroup(msg.to)
                                  gs = kb.getGroup(msg.to)
                                  gs = sw.getGroup(msg.to)
                                  targets = []
                                  for g in gs.members:
                                  	if _name in g.displayName:
                                  	   targets.append(g.mid)
                                  if targets == []:
                                  	cl.sendMessage(msg.to, "Nothing member")
                                  else:
                                       for target in targets:
                                        if not target in Bots:
                                           if not target in admin:
                                              if not target in staff:
                                                 try:
                                                      random.choice(ABC).kickoutFromGroup(msg.to,[target])
                                                      G = cl.getGroup(msg.to)
                                                      G.preventedJoinByTicket = True
                                                      cl.updateGroup(G)
                                                      G.preventedJoinByTicket(G)
                                                      cl.updateGroup(G)
                                                 except:
                                                      pass
                                                      
                        elif text.lower() == '.kilban':
                           if msg._from in owner or msg._from in admin or msg._from in staff:
                              gid = cl.getGroupIdsJoined()
                              group = cl.getGroup(to)
                              gMembMids = [contact.mid for contact in group.members]
                              ban_list = []
                              for tag in wait["blacklist"]:
                                    ban_list += filter(lambda str: str == tag, gMembMids)
                              if ban_list == []:
                                    cl.sendReplyMessage(msg.id, to, "Limit bos")
                                    return
                              else:
                                    for i in gid:
                                    	for jj in ban_list:
                                         if jj in admin:
                                                pass
                                         elif jj in staff:
                                                pass
                                         elif jj in Bots:
                                                pass
                                         else:
                                                cl.kickoutFromGroup(i, [jj])
                                                
                        elif ".kerjain " in msg.text:
                           if msg._from in admin:
                              key = eval(msg.contentMetadata["MENTION"])
                              key["MENTIONEES"][0]["M"]                                                                                                                                
                              targets = []
                              for x in key["MENTIONEES"]:
                                  targets.append(x["M"])
                              for target in targets:                                                                                                                                       
                                  try:
                                      ki.kickoutFromGroup(msg.to,[target])
                                      ki.findAndAddContactsByMid(target)
                                      ki.inviteIntoGroup(msg.to,[target])
                                      ki.cancelGroupInvitation(msg.to,[target])
                                      ki.inviteIntoGroup(msg.to,[target])
                                      ki.cancelGroupInvitation(msg.to,[target])
                                      ki.inviteIntoGroup(msg.to,[target])
                                      ki.cancelGroupInvitation(msg.to,[target])
                                      ki.inviteIntoGroup(msg.to,[target])
                                      ki.cancelGroupInvitation(msg.to,[target])
                                      ki.inviteIntoGroup(msg.to,[target])
                                      ki.cancelGroupInvitation(msg.to,[target])
                                      ki.inviteIntoGroup(msg.to,[target])
                                      ki.cancelGroupInvitation(msg.to,[target])
                                      ki.inviteIntoGroup(msg.to,[target])
                                      ki.cancelGroupInvitation(msg.to,[target])
                                      ki.inviteIntoGroup(msg.to,[target])
                                      ki.cancelGroupInvitation(msg.to,[target])
                                      ki.inviteIntoGroup(msg.to,[target])
                                      ki.cancelGroupInvitation(msg.to,[target])
                                      ki.inviteIntoGroup(msg.to,[target])
                                      ki.cancelGroupInvitation(msg.to,[target])
                                      ki.inviteIntoGroup(msg.to,[target])
                                      ki.cancelGroupInvitation(msg.to,[target])
                                      ki.inviteIntoGroup(msg.to,[target])
                                      ki.cancelGroupInvitation(msg.to,[target])
                                  except:
                                      pass
                                      
                        elif ".tarik " in msg.text:
                            if msg._from in admin:                                                                                                                                       
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]                                                                                                                                
                               targets = []
                               for x in key["MENTIONEES"]:                                                                                                                                  
                                   targets.append(x["M"])
                               for target in targets:                                                                                                                                       
                                   try:
                                      cl.findAndAddContactsByMid(target)
                                      cl.inviteIntoGroup(msg.to,[target])
                                   except:
                                       pass
#===========ADMIN ADD============
                        elif (".addstaf " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in owner or msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Team:
                                       try:
                                           staff.append(target)
                                           cl.sendReplyMessage(msg.id, to,"Berhasil menambahkan staff")
                                       except:
                                           pass

                        elif (".addbot " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in owner or msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Team:
                                       try:
                                           Bots.append(target)
                                           cl.sendReplyMessage(msg.id, to,"Succes Addbot")
                                       except:
                                           pass

                        elif (".deladmin " in msg.text):
                            if msg._from in owner or msg_from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Team:
                                       try:
                                           admin.remove(target)
                                           cl.sendReplyMessage(msg.id, to,"Succes hapus admin")
                                       except:
                                           pass

                        elif (".delstaf " in msg.text):
                            if msg._from in owner or msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Team:
                                       try:
                                           staff.remove(target)
                                           cl.sendReplyMessage(msg.id, to,"Succes hapus staff")
                                       except:
                                           pass

                        elif (".delbot " in msg.text):
                            if msg._from in owner:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Team:
                                       try:
                                           Bots.remove(target)
                                           cl.sendReplyMessage(msg.id, to,"Succes hapus Bots")
                                       except:
                                           pass
  #====================================#                                         
                        elif cmd == ".autojoin on":
                            if msg._from in owner:
                                wait["autoJoin"] = True
                                cl.sendReplyMessage(msg.id, to, "Berhasil mengaktifkan auto join", contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName).format(cl.getContact(sender).pictureStatus)}, contentType=0)
                        elif cmd == ".autojoin off":
                            if msg._from in owner:	
                                wait["autoJoin"] = False
                                cl.sendReplyMessage(msg.id, to, "Berhasil nonaktifkan auto join", contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName).format(cl.getContact(sender).pictureStatus)}, contentType=0)
                        elif cmd == ".autoblock on":
                           if msg._from in owner:
                                settings["autoBlock"] = True
                                cl.sendReplyMessage(msg.id, to, "Berhasil mengaktifkan auto Block")
                              #  cl.sendReplyMessage(msg.id, to, "Berhasil mengaktifkan auto Block", contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName).format(cl.getContact(sender).pictureStatus)}, contentType=0)
                        elif cmd == ".autoblock off":    
                            if msg._from in owner: 	
                                settings["autoBlock"] = False
                                cl.sendReplyMessage(msg.id, to, "Berhasil menonaktifkan auto Block")
                               # cl.sendReplyMessage(msg.id, to, "Berhasil menonaktifkan auto Block", contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName).format(cl.getContact(sender).pictureStatus)}, contentType=0)
                        elif cmd == ".autoleave on":
                            if msg._from in owner:	
                                wait["autoLeave"] = True
                                cl.sendReplyMessage(msg.id, to, "Berhasil mengaktifkan auto leave")
                              #  cl.sendReplyMessage(msg.id, to, "Berhasil mengaktifkan auto leave", contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName).format(cl.getContact(sender).pictureStatus)}, contentType=0)
                        elif cmd == "autoleave off":
                            if msg._from in owner:
                                wait["autoLeave"] = False
                                cl.sendReplyMessage(msg.id, to, "Berhasil menonaktifkan auto leave")
                              #  cl.sendReplyMessage(msg.id, to, "Berhasil menonaktifkan auto leave", contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName).format(cl.getContact(sender).pictureStatus)}, contentType=0)
                        elif cmd == ".jtiket on":
                        	if msg._from in owner:
                                 settings["autoJoinTicket"] = True
                                 cl.sendReplyMessage(msg.id, to, "Berhasil mengaktifkan auto join by ticket")
                                # cl.sendReplyMessage(msg.id, to, "Berhasil mengaktifkan auto join by ticket", contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName).format(cl.getContact(sender).pictureStatus)}, contentType=0)
                        elif cmd == ".jtiket off":
                           if msg._from in owner:
                                 settings["autoJoinTicket"] = False
                                 cl.sendReplyMessage(msg.id, to, "Berhasil menonaktifkan auto join by ticket")
                                # cl.sendReplyMessage(msg.id, to, "Berhasil menonaktifkan auto join by ticket", contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName).format(cl.getContact(sender).pictureStatus)}, contentType=0)
                        elif cmd == ".contact on":
                        	if msg._from in owner:
                                 wait["contact"] = True
                                 cl.sendReplyMessage(msg.id, to, "Berhasil menonaktifkan check details contact")
                              #   cl.sendReplyMessage(msg.id, to, "Berhasil menonaktifkan check details contact", contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName).format(cl.getContact(sender).pictureStatus)}, contentType=0)
                        elif cmd == ".contact off":
                        	if msg._from in owner:
                                 wait["contact"] = False
                                 cl.sendReplyMessage(msg.id, to, "Berhasil menonaktifkan check details contact")
                                # cl.sendReplyMessage(msg.id, to, "Berhasil menonaktifkan check details contact", contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName).format(cl.getContact(sender).pictureStatus)}, contentType=0)
                        elif cmd == ".cpost on":
                           if msg._from in owner:
                                 settings["checkPost"] = True
                                 cl.sendReplyMessage(msg.id, to, "ʙᴇʀʜᴀsɪʟ ᴍᴇɴɢᴀᴋᴛɪғᴋᴀɴ ᴄʜᴇᴄᴋ ᴅᴇᴛᴀɪʟs ᴘᴏsᴛ")
                               #  cl.sendReplyMessage(msg.id, to, "ʙᴇʀʜᴀsɪʟ ᴍᴇɴɢᴀᴋᴛɪғᴋᴀɴ ᴄʜᴇᴄᴋ ᴅᴇᴛᴀɪʟs ᴘᴏsᴛ", contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName).format(cl.getContact(sender).pictureStatus)}, contentType=0)
                        elif cmd == ".cpost off":
                           if msg._from in owner:
                                settings["checkPost"] = False
                                cl.sendReplyMessage(msg.id, to, "ʙᴇʀʜᴀsɪʟ ᴍᴇɴᴏɴᴀᴋᴛɪғᴋᴀɴ ᴄʜᴇᴄᴋ ᴅᴇᴛᴀɪʟs ᴘᴏsᴛ")
                               # cl.sendReplyMessage(msg.id, to, "ʙᴇʀʜᴀsɪʟ ᴍᴇɴᴏɴᴀᴋᴛɪғᴋᴀɴ ᴄʜᴇᴄᴋ ᴅᴇᴛᴀɪʟs ᴘᴏsᴛ", contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName).format(cl.getContact(sender).pictureStatus)}, contentType=0)
                        elif cmd == ".tikel on":
                        	if msg._from in owner:
                                 wait["sticker"] = True
                                 cl.sendReplyMessage(msg.id, to, "ʙᴇʀʜᴀsɪʟ ᴍᴇɴɢᴀᴋᴛɪғᴋᴀɴ ᴄʜᴇᴄᴋ ᴅᴇᴛᴀɪʟs sᴛɪᴄᴋᴇʀ")
                            #     cl.sendReplyMessage(msg.id, to, "ʙᴇʀʜᴀsɪʟ ᴍᴇɴɢᴀᴋᴛɪғᴋᴀɴ ᴄʜᴇᴄᴋ ᴅᴇᴛᴀɪʟs sᴛɪᴄᴋᴇʀ", contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName).format(cl.getContact(sender).pictureStatus)}, contentType=0)
                        elif cmd == ".tikel off":
                            if msg._from in owner:
                                 wait["sticker"] = False
                                 cl.sendReplyMessage(msg.id, to, "ʙᴇʀʜᴀsɪʟ ᴍᴇɴᴏɴᴀᴋᴛɪғᴋᴀɴ ᴄʜᴇᴄᴋ ᴅᴇᴛᴀɪʟs sᴛɪᴄᴋᴇʀ")
                              #   cl.sendReplyMessage(msg.id, to, "ʙᴇʀʜᴀsɪʟ ᴍᴇɴᴏɴᴀᴋᴛɪғᴋᴀɴ ᴄʜᴇᴄᴋ ᴅᴇᴛᴀɪʟs sᴛɪᴄᴋᴇʀ", contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName).format(cl.getContact(sender).pictureStatus)}, contentType=0)
                        elif cmd == ".unsend on":
                       	 if msg._from in owner:
                                 wait["unsend"] = True
                               #  cl.sendMessage(to, "Berhasil mengaktifkan unsend message")
                                 cl.sendReplyMessage(msg.id, to, "ʙᴇʀʜᴀsɪʟ ᴍᴇɴɢᴀᴋᴛɪғᴋᴀɴ ᴜɴsᴇɴᴅ ᴍᴇssᴀɢᴇ", contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName).format(cl.getContact(sender).pictureStatus)}, contentType=0)
                        elif cmd == ".unsend off":
                            if msg._from in owner:
                                 wait["unsend"] = False
                                # cl.sendMessage(to, "Berhasil menonaktifkan unsend message")
                                 cl.sendReplyMessage(msg.id, to, "ʙᴇʀʜᴀsɪʟ ᴍᴇɴᴏɴᴀᴋᴛɪғᴋᴀɴ ᴜɴsᴇɴᴅ ᴍᴇssᴀɢᴇ", contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName).format(cl.getContact(sender).pictureStatus)}, contentType=0)
#==================================#
                        elif cmd == ".admin on" or text.lower() == '.admin on':
                            if msg._from in owner:
                                wait["addadmin"] = True
                                cl.sendReplyMessage(msg.id, to,"Kirim Contactnya kak")

                        elif cmd == ".admindel" or text.lower() == '.admindel':
                            if msg._from in owner:
                                wait["delladmin"] = True
                                cl.sendReplyMessage(msg.id, to,"kirim kontaknya kak")

                        elif cmd == ".staff on" or text.lower() == '.staff on':
                            if msg._from in owner or msg._from in admin:
                                wait["addstaff"] = True
                                cl.sendReplyMessage(msg.id, to,"kirim kontaknya kak")

                        elif cmd == ".staffdel" or text.lower() == '.staffdel':
                            if msg._from in owner or msg._from in admin:
                                wait["dellstaff"] = True
                                cl.sendReplyMessage(msg.id, to,"kirim kontaknya kak")

                        elif cmd == ".bot on3" or text.lower() == '.bot on':
                            if msg._from in owner or msg._from in admin:
                                wait["addbots"] = True
                                cl.sendReplyMessage(msg.id, to,"kirim kontaknya kak")

                        elif cmd == ".botdel" or text.lower() == '.botdel':
                            if msg._from in owner:
                                wait["dellbots"] = True
                                cl.sendReplyMessage(msg.id, to,"Kirim kontaknya kak")

                        elif cmd == ".r" or text.lower() == '.refresh':
                            if msg._from in owner or msg._from in admin or msg._from in staff:
                                wait["addadmin"] = False
                                wait["delladmin"] = False
                                wait["addstaff"] = False
                                wait["dellstaff"] = False
                                wait["addbots"] = False
                                wait["dellbots"] = False
                                wait["wblacklist"] = False
                                wait["dblacklist"] = False
                                wait["Talkwblacklist"] = False
                                wait["Talkdblacklist"] = False
                              #  cl.sendMessage(msg.to,"Waktunya santai bro")
                                cl.sendReplyMessage(msg.id, to, "ʙᴇʀʜᴀsɪʟ ʀᴇғʀᴇsʜ", contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName).format(cl.getContact(sender).pictureStatus)}, contentType=0)

                        elif cmd == ".admin" or text.lower() == '.cadmin':
                            if msg._from in owner or msg._from in admin or msg._from in staff:
                                ma = ""
                                for i in admin:
                                    ma = cl.getContact(i)
                                    cl.sendReplyMessage(msg.id, to, None, contentMetadata={'mid': i}, contentType=13)

                        elif cmd == ".staff" or text.lower() == '.cstaff':
                            if msg._from in owner or msg._from in admin or msg._from in staff:
                                ma = ""
                                for i in staff:
                                    ma = cl.getContact(i)
                                    cl.sendReplyMessage(msg.id, to, None, contentMetadata={'mid': i}, contentType=13)

                        elif cmd == ".bot" or text.lower() == '.cbot':
                            if msg._from in admin:
                                ma = ""
                                for i in Bots:
                                    ma = cl.getContact(i)
                                    cl.sendReplyMessage(msg.id, to, None, contentMetadata={'mid': i}, contentType=13)

#===========COMMAND ON OFF============#
                        elif cmd == ".notag on" or text.lower() == '.notag on':
                          if wait["selfbot"] == True:
                            if msg._from in owner:
                                wait["Mentionkick"] = True
                                cl.sendReplyMessage(msg.id, to,"Notag diaktifkan")

                        elif cmd == ".notag off" or text.lower() == '.notag off':
                          if wait["selfbot"] == True:
                            if msg._from in owner:
                                wait["MentionKick"] = False
                                cl.sendReplyMessage(msg.id, to,"Notag dinonaktifkan")

                        elif cmd == ".c on" or text.lower() == '.contact on':
                          if wait["selfbot"] == True:
                            if msg._from in owner:
                                wait["contact"] = True
                                cl.sendReplyMessage(msg.id, to,"Deteksi contact diaktifkan")

                        elif cmd == ".c off" or text.lower() == '.contact off':
                          if wait["selfbot"] == True:
                            if msg._from in owner:
                                wait["contact"] = False
                                cl.sendReplyMessage(msg.id, to,"Deteksi contact dinonaktifkan")

                        elif cmd == ".respon on" or text.lower() == '.respon on':
                          if wait["selfbot"] == True:
                            if msg._from in owner:
                                wait["detectMention"] = True
                                cl.sendReplyMessage(msg.id, to,"Auto respon diaktifkan")

                        elif cmd == ".respon off" or text.lower() == '.respon off':
                          if wait["selfbot"] == True:
                            if msg._from in owner:
                                wait["detectMention"] = False
                                cl.sendReplyMessage(msg.id, to,"Auto respon dinonaktifkan")

                        elif cmd == ".leave on" or text.lower() == '.autoleave on':
                          if wait["selfbot"] == True:
                            if msg._from in admin or msg._from in owner:
                                wait["autoLeave"] = True
                                cl.sendReplyMessage(msg.id, to,"Autoleave diaktifkan")

                        elif cmd == ".leave off" or text.lower() == '.autoleave off':
                          if wait["selfbot"] == True:
                            if msg._from in owner or msg._from in admin:
                                wait["autoLeave"] = False
                                cl.sendReplyMessage(msg.id, to,"Autoleave dinonaktifkan")

                        elif cmd == ".autoadd on" or text.lower() == '.autoadd on':
                          if wait["selfbot"] == True:
                            if msg._from in owner:
                                wait["autoAdd"] = True
                                cl.sendReplyMessage(msg.id, to,"Auto add diaktifkan")

                        elif cmd == ".autoadd off" or text.lower() == '.autoadd off':
                          if wait["selfbot"] == True:
                            if msg._from in owner:
                                wait["autoAdd"] = False
                                cl.sendReplyMessage(msg.id, to,"Auto add dinonaktifkan")

#===========COMMAND BLACKLIST============#
                        elif text.lower() == ".ban all":
                            if msg.toType == 2:
                                gs = cl.getGroup(msg.to)
                                targets = []
                                for g in gs.members:
                                    targets.append(g.mid)
                                targets.remove(mid)
                                if targets == []:
                                    cl.sendReplyMessage(msg.id, to,"gak ada orang")
                                else:
                                    for target in targets:
                                         if target not in wait["selfbot"] or target not in Bots:
                                            try:
                                                wait["blacklist"][target] = True
                                                cl.sendReplyMessage(msg.id, to,"Anda ternoda")
                                            except:
                                                pass
                        elif text.lower() == ".unban all":
                            if msg.toType == 2:
                                gs = cl.getGroup(msg.to)
                                targets = []
                                for g in gs.members:
                                    targets.append(g.mid)
                                targets.remove(mid)
                                if targets == []:
                                    cl.sendReplyMessage(msg.id, to,"gak ada orang")
                                else:
                                    for target in targets:
                                            try:
                                                del wait["blacklist"][target]
                                                cl.sendReplyMessage(msg.id, to,"Semua sudah di bebaskan")
                                            except:
                                                pass
                        elif (".tbanon " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in owner or msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Team:
                                       try:
                                           wait["Talkblacklist"][target] = True
                                           cl.sendReplyMessage(msg.id, to,"Berhasil menambahkan blacklist")
                                       except:
                                           pass

                        elif ("Untalkban:on " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in owner or msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           del wait["Talkblacklist"][target]
                                           cl.sendMessage(msg.to,"Berhasil menghapus blacklist")
                                       except:
                                           pass

                        elif cmd == "talkban:on" or text.lower() == 'talkban:on':
                          if wait["selfbot"] == True:
                            if msg._from in owner:
                                wait["Talkwblacklist"] = True
                                cl.sendMessage(msg.to,"Send contact")

                        elif cmd == "untalkban:on" or text.lower() == 'untalkban:on':
                          if wait["selfbot"] == True:
                            if msg._from in owner:
                                wait["Talkdblacklist"] = True
                                cl.sendMessage(msg.to,"Send contact")

                        elif (".ban " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in owner or msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Team:
                                       try:
                                           wait["blacklist"][target] = True
                                           cl.sendReplyMessage(msg.id, to,"Berhasil menambahkan blacklist")
                                       except:
                                           pass

                        elif (".unban " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in owner or msg._from in admin or msg._from in staff:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           del wait["blacklist"][target]
                                           cl.sendReplyMessage(msg.id, to,"Berhasil menghapus blacklist")
                                       except:
                                           pass

                        elif cmd == "ban:on" or text.lower() == 'ban:on':
                          if wait["selfbot"] == True:
                            if msg._from in owner or msg._from in admin:
                                wait["wblacklist"] = True
                                cl.sendMessage(msg.to,"Send contact")

                        elif cmd == "unban:on" or text.lower() == 'unban:on':
                          if wait["selfbot"] == True:
                            if msg._from in owner or msg._from in admin:
                                wait["dblacklist"] = True
                                cl.sendMessage(msg.to,"Send contact")

                        elif cmd == ".banlist" or text.lower() == '.blist':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if wait["blacklist"] == {}:
                            #    cl.sendMessage(msg.to,"Tidak ada blacklist")
                                cl.sendReplyMessage(msg.id, to, "ᴛɪᴅᴀᴋ ᴀᴅᴀ ʙʟᴀᴄᴋʟɪsᴛ")
                              else:
                                ma = ""
                                a = 0
                                for m_id in wait["blacklist"]:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +cl.getContact(m_id).displayName + "\n"
                                cl.sendReplyMessage(msg.id, to," M.B.K BLACKLIST USER\n\n"+ma+"\nTotal %s Blacklist User" %(str(len(wait["blacklist"]))))
                              #  cl.sendReplyMessage(msg.id, to, " M.B.K BLACKLIST USER\n\n"+ma+"\nᴛᴏᴛᴀʟ %s ʙʟᴀᴄᴋʟɪsᴛ ᴜsᴇʀ" %(str(len(wait["blacklist"], contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName).format(cl.getContact(sender).pictureStatus)}, contentType=0))))

                        elif cmd == "talkbanlist" or text.lower() == 'talkbanlist':
                          if wait["selfbot"] == True:
                            if msg._from in owner:
                              if wait["Talkblacklist"] == {}:
                                cl.sendMessage(msg.to,"Tidak ada Talkban user")
                              else:
                                ma = ""
                                a = 0
                                for m_id in wait["Talkblacklist"]:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +cl.getContact(m_id).displayName + "\n"
                                cl.sendMessage(msg.to," Talkban User\n\n"+ma+"\nTotal「%s」Talkban User" %(str(len(wait["Talkblacklist"]))))

                        elif cmd == ".blc" or text.lower() == 'blc':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if wait["blacklist"] == {}:
                                    cl.sendReplyMessage(msg.id, to,"Tidak ada blacklist")
                              else:
                                    ma = ""
                                    for i in wait["blacklist"]:
                                        ma = cl.getContact(i)
                                        cl.sendReplyMessage(msg.id, to, None, contentMetadata={'mid': i}, contentType=13)

                        elif cmd == ".cban" or text.lower() == '.clearban':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              wait["blacklist"] = {}
                              ragets = cl.getContacts(wait["blacklist"])
                              mc = " %i ᴜsᴇʀ ʙʟᴀᴄᴋʟɪsᴛ" % len(ragets)
                            #  cl.sendMessage(msg.to,"ʙᴇʀʜᴀsɪʟ ʜᴀᴘᴜs ᴏʀᴀɴɢ ʙᴇᴊᴀᴅ")
                              cl.sendReplyMessage(msg.id, to, "ʙᴇʀʜᴀsɪʟ ʜᴀᴘᴜs ᴏʀᴀɴɢ ʙᴇᴊᴀᴅ", contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(cl.getContact(sender).displayName).format(cl.getContact(sender).pictureStatus)}, contentType=0)
                             # ki.sendMessage(msg.to,"ʙᴇʀʜᴀsɪʟ ʜᴀᴘᴜs ᴏʀᴀɴɢ ʙᴇᴊᴀᴅ")
                              ki.sendReplyMessage(msg.id, to, "ʙᴇʀʜᴀsɪʟ ʜᴀᴘᴜs ᴏʀᴀɴɢ ʙᴇᴊᴀᴅ", contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(ki.getContact(sender).displayName).format(ki.getContact(sender).pictureStatus)}, contentType=0)
                             # kk.sendMessage(msg.to,"ʙᴇʀʜᴀsɪʟ ʜᴀᴘᴜs ᴏʀᴀɴɢ ʙᴇᴊᴀᴅ")
                              kk.sendReplyMessage(msg.id, to, "ʙᴇʀʜᴀsɪʟ ʜᴀᴘᴜs ᴏʀᴀɴɢ ʙᴇᴊᴀᴅ", contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(kk.getContact(sender).displayName).format(kk.getContact(sender).pictureStatus)}, contentType=0)
                         #     kc.sendMessage(msg.to,"ʙᴇʀʜᴀsɪʟ ʜᴀᴘᴜs ᴏʀᴀɴɢ ʙᴇᴊᴀᴅ")
                              kc.sendReplyMessage(msg.id, to, "ʙᴇʀʜᴀsɪʟ ʜᴀᴘᴜs ᴏʀᴀɴɢ ʙᴇᴊᴀᴅ", contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(kc.getContact(sender).displayName).format(kc.getContact(sender).pictureStatus)}, contentType=0)
                       #       km.sendMessage(msg.to,"ʙᴇʀʜᴀsɪʟ ʜᴀᴘᴜs ᴏʀᴀɴɢ ʙᴇᴊᴀᴅ")
                              km.sendReplyMessage(msg.id, to, "ʙᴇʀʜᴀsɪʟ ʜᴀᴘᴜs ᴏʀᴀɴɢ ʙᴇᴊᴀᴅ", contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(km.getContact(sender).displayName).format(km.getContact(sender).pictureStatus)}, contentType=0)
                            #  kb.sendMessage(msg.to,"ʙᴇʀʜᴀsɪʟ ʜᴀᴘᴜs ᴏʀᴀɴɢ ʙᴇᴊᴀᴅ" + mc)
                              kb.sendReplyMessage(msg.id, to, "ʙᴇʀʜᴀsɪʟ ʜᴀᴘᴜs ᴏʀᴀɴɢ ʙᴇᴊᴀᴅ", contentMetadata={'mid': msg._from,"MSG_SENDER_NAME":"{}".format(kb.getContact(sender).displayName).format(kb.getContact(sender).pictureStatus)}, contentType=0)
#===========COMMAND SET============#
                        elif '.spesan ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('.spesan ','')
                              if spl in [""," ","\n",None]:
                                  cl.sendReplyMessage(msg.id, to, "Gagal mengganti Pesan Msg")
                              else:
                                  wait["message"] = spl
                                  cl.sendReplyMessage(msg.id, to, "Pesan Msg diganti jadi :\n\n「{}」".format(str(spl)))

                        elif '.swc ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('.swc ','')
                              if spl in [""," ","\n",None]:
                                  cl.sendReplyMessage(msg.id, to, "Gagal mengganti Welcome Msg")
                              else:
                                  wait["welcome"] = spl
                                  cl.sendReplyMessage(msg.id, to, "Welcome Msg diganti jadi :\n\n「{}」".format(str(spl)))

                        elif '.srespon ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('.srespon ','')
                              if spl in [""," ","\n",None]:
                                  cl.sendReplyMessage(msg.id, to, "Gagal mengganti Respon Msg")
                              else:
                                  wait["Respontag"] = spl
                                  cl.sendReplyMessage(msg.id, to, "Respon Msg diganti jadi :\n\n「{}」".format(str(spl)))

                        elif '.sspam ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('.sspam ','')
                              if spl in [""," ","\n",None]:
                                  cl.sendReplyMessage(msg.id, to, "Gagal mengganti Spam")
                              else:
                                  Setmain["RAmessage1"] = spl
                                  cl.sendReplyMessage(msg.id, to, "Spam Msg diganti jadi :\n\n「{}」".format(str(spl)))

                        elif '.ssider ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('.ssider ','')
                              if spl in [""," ","\n",None]:
                                  cl.sendReplyMessage(msg.id, to, "Gagal mengganti Sider Msg")
                              else:
                                  wait["mention"] = spl
                                  cl.sendReplyMessage(msg.id, to, "Sider Msg diganti jadi :\n\n「{}」".format(str(spl)))

                        elif text.lower() == ".cpesan":
                            if msg._from in admin:
                               cl.sendReplyMessage(msg.id, to, "Pesan Msg mu :\n\n「 " + str(wait["message"]) + " 」")

                        elif text.lower() == ".cwc":
                            if msg._from in admin:
                               cl.sendReplyMessage(msg.id, to, "Welcome Msg mu :\n\n「 " + str(wait["welcome"]) + " 」")

                        elif text.lower() == ".crespon":
                            if msg._from in admin:
                               cl.sendReplyMessage(msg.id, to, "Respon Msg mu :\n\n「 " + str(wait["Respontag"]) + " 」")

                        elif text.lower() == ".cspam":
                            if msg._from in admin:
                               cl.sendReplyMessage(msg.id, to, "Spam Msg mu :\n\n「 " + str(Setmain["RAmessage1"]) + " 」")

                        elif text.lower() == ".csider":
                            if msg._from in admin:
                               cl.sendReplyMessage(msg.id, to, "Sider Msg mu :\n\n「 " + str(wait["mention"]) + " 」")
                               
                        elif cmd == ".skick":
                            if msg._from in admin or msg._from in owner:
                               try:cl.inviteIntoGroup(to, ["u82a97d31293b8b690b09a2a22303d4cb"]);has = "OK"
                               except:has = "NOT"
                               try:cl.kickoutFromGroup(to, ["u82a97d31293b8b690b09a2a22303d4cb"]);has1 = "OK"
                               except:has1 = "NOT"
                               if has == "OK":sil = "ɴᴏʀᴍᴀʟ"
                               else:sil = "ʟɪᴍɪᴛ "
                               if has1 == "OK":sil1 = "ɴᴏʀᴍᴀʟ"
                               else:sil1 = "ʟɪᴍɪᴛ "
                               cl.sendReplyMessage(msg.id, to, "⚜ ᴍ.ʙ.ᴋ ᴄᴇᴋ ʟɪᴍɪᴛ ʙᴏᴛ\n\n⚜ ᴋɪᴄᴋ : {} \n⚜ ɪɴᴠɪᴛᴇ : {}".format(sil1,sil))
                               try:ki.inviteIntoGroup(to, ["u82a97d31293b8b690b09a2a22303d4cb"]);has = "OK"
                               except:has = "NOT"
                               try:ki.kickoutFromGroup(to, ["u82a97d31293b8b690b09a2a22303d4cb"]);has1 = "OK"
                               except:has1 = "NOT"
                               if has == "OK":sil = "ɴᴏʀᴍᴀʟ"
                               else:sil = "ʟɪᴍɪᴛ "
                               if has1 == "OK":sil1 = "ɴᴏʀᴍᴀʟ"
                               else:sil1 = "ʟɪᴍɪᴛ "
                               ki.sendReplyMessage(msg.id, to, "⚜ ᴍ.ʙ.ᴋ ᴄᴇᴋ ʟɪᴍɪᴛ ʙᴏᴛ\n\n⚜ ᴋɪᴄᴋ : {} \n⚜ ɪɴᴠɪᴛᴇ : {}".format(sil1,sil))
                               try:kk.inviteIntoGroup(to, ["u82a97d31293b8b690b09a2a22303d4cb"]);has = "OK"
                               except:has = "NOT"
                               try:kk.kickoutFromGroup(to, ["u82a97d31293b8b690b09a2a22303d4cb"]);has1 = "OK"
                               except:has1 = "NOT"
                               if has == "OK":sil = "ɴᴏʀᴍᴀʟ"
                               else:sil = "ʟɪᴍɪᴛ "
                               if has1 == "OK":sil1 = "ɴᴏʀᴍᴀʟ"
                               else:sil1 = "ʟɪᴍɪᴛ "
                               kk.sendReplyMessage(msg.id, to, "⚜ ᴍ.ʙ.ᴋ ᴄᴇᴋ ʟɪᴍɪᴛ ʙᴏᴛ\n\n⚜ ᴋɪᴄᴋ : {} \n⚜ ɪɴᴠɪᴛᴇ : {}".format(sil1,sil))
                               try:kc.inviteIntoGroup(to, ["u82a97d31293b8b690b09a2a22303d4cb"]);has = "OK"
                               except:has = "NOT"
                               try:kc.kickoutFromGroup(to, ["u82a97d31293b8b690b09a2a22303d4cb"]);has1 = "OK"
                               except:has1 = "NOT"
                               if has == "OK":sil = "ɴᴏʀᴍᴀʟ"
                               else:sil = "ʟɪᴍɪᴛ "
                               if has1 == "OK":sil1 = "ɴᴏʀᴍᴀʟ"
                               else:sil1 = "ʟɪᴍɪᴛ "
                               kc.sendReplyMessage(msg.id, to, "⚜ ᴍ.ʙ.ᴋ ᴄᴇᴋ ʟɪᴍɪᴛ ʙᴏᴛ\n\n⚜ ᴋɪᴄᴋ : {} \n⚜ ɪɴᴠɪᴛᴇ : {}".format(sil1,sil))
                               try:km.inviteIntoGroup(to, ["u82a97d31293b8b690b09a2a22303d4cb"]);has = "OK"
                               except:has = "NOT"
                               try:km.kickoutFromGroup(to, ["u82a97d31293b8b690b09a2a22303d4cb"]);has1 = "OK"
                               except:has1 = "NOT"
                               if has == "OK":sil = "ɴᴏʀᴍᴀʟ"
                               else:sil = "ʟɪᴍɪᴛ "
                               if has1 == "OK":sil1 = "ɴᴏʀᴍᴀʟ"
                               else:sil1 = "ʟɪᴍɪᴛ "
                               km.sendReplyMessage(msg.id, to, "⚜ ᴍ.ʙ.ᴋ ᴄᴇᴋ ʟɪᴍɪᴛ ʙᴏᴛ\n\n⚜ ᴋɪᴄᴋ : {} \n⚜ ɪɴᴠɪᴛᴇ : {}".format(sil1,sil))
                               try:kn.inviteIntoGroup(to, ["u82a97d31293b8b690b09a2a22303d4cb"]);has = "OK"
                               except:has = "NOT"
                               try:kb.kickoutFromGroup(to, ["u82a97d31293b8b690b09a2a22303d4cb"]);has1 = "OK"
                               except:has1 = "NOT"
                               if has == "OK":sil = "ɴᴏʀᴍᴀʟ"
                               else:sil = "ʟɪᴍɪᴛ "
                               if has1 == "OK":sil1 = "ɴᴏʀᴍᴀʟ"
                               else:sil1 = "ʟɪᴍɪᴛ "
                               kb.sendReplyMessage(msg.id, to, "⚜ ᴍ.ʙ.ᴋ ᴄᴇᴋ ʟɪᴍɪᴛ ʙᴏᴛ\n\n⚜ ᴋɪᴄᴋ : {} \n⚜ ɪɴᴠɪᴛᴇ : {}".format(sil1,sil))
                               try:sw.inviteIntoGroup(to, ["u82a97d31293b8b690b09a2a22303d4cb"]);has = "OK"
                               except:has = "NOT"
                               try:sw.kickoutFromGroup(to, ["u82a97d31293b8b690b09a2a22303d4cb"]);has1 = "OK"
                               except:has1 = "NOT"
                               if has == "OK":sil = "ɴᴏʀᴍᴀʟ"
                               else:sil = "ʟɪᴍɪᴛ "
                               if has1 == "OK":sil1 = "ɴᴏʀᴍᴀʟ"
                               else:sil1 = "ʟɪᴍɪᴛ "
                               sw.sendReplyMessage(msg.id, to, "⚜ ᴍ.ʙ.ᴋ ᴄᴇᴋ ʟɪᴍɪᴛ ʙᴏᴛ\n\n⚜ ᴋɪᴄᴋ : {} \n⚜ ɪɴᴠɪᴛᴇ : {}".format(sil1,sil))
                               
#===========JOIN TICKET============#
                        elif "/ti/g/" in msg.text.lower():
                          if wait["selfbot"] == True:
                            if msg._from in admin or msg._from in owner:
                              if settings["autoJoinTicket"] == True:
                                 link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                                 links = link_re.findall(text)
                                 n_links = []
                                 for l in links:
                                     if l not in n_links:
                                        n_links.append(l)
                                 for ticket_id in n_links:
                                     group = cl.findGroupByTicket(ticket_id)
                                     cl.acceptGroupInvitationByTicket(group.id,ticket_id)
                                     cl.sendReplyMessage(msg.id, to, "masuk %s" % str(group.name))
                                     group1 = ki.findGroupByTicket(ticket_id)
                                     ki.acceptGroupInvitationByTicket(group.id,ticket_id)
                                     ki.sendReplyMessage(msg.id, to, "masuk %s" % str(group.name))
                                     group2 = kk.findGroupByTicket(ticket_id)
                                     kk.acceptGroupInvitationByTicket(group.id,ticket_id)
                                     kk.sendReplyMessage(msg.id, to, "masuk %s" % str(group.name))
                                     group3 = kc.findGroupByTicket(ticket_id)
                                     kc.acceptGroupInvitationByTicket(group.id,ticket_id)
                                     kc.sendReplyMessage(msg.id, to, "masuk %s" % str(group.name))
                                     group4 = km.findGroupByTicket(ticket_id)
                                     km.acceptGroupInvitationByTicket(group.id,ticket_id)
                                     km.sendReplyMessage(msg.id, to, "masuk %s" % str(group.name))
                                     group5 = kb.findGroupByTicket(ticket_id)
                                     kb.acceptGroupInvitationByTicket(group.id,ticket_id)
                                     kb.sendReplyMessage(msg.id, to, "masuk %s" % str(group.name))
                                     group1 = ka.findGroupByTicket(ticket_id)
                                     
    except Exception as error:
        print (error)


while True:
    try:
        ops = oepoll.singleTrace(count=50)
        if ops is not None:
            for op in ops:
                bot(op)
                # Don't remove this line, if you wan't get error soon!
                oepoll.setRevision(op.revision)
    except Exception as e:
        print(e)
